try:
    from src.vmx_ppo.config.config_parser import ConfigParser
    from src.vmx_ppo.config.argument_parser import ArgumentParser
    from src.vmx_ppo.utils.logging import setup_logging_config
except:
    from .config.config_parser import ConfigParser
    from .config.argument_parser import ArgumentParser
    from .utils.logging import setup_logging_config
import logging
import runpy


def main():
    args = ArgumentParser()
    print("**************", args.env)
    cfg = ConfigParser(
        env=args.env,
        brand=args.brand,
        month=args.month,
        version=args.version,
        booster=args.booster,
        reducer=args.reducer,
        segments=args.segments,
    )
    logger = logging.getLogger(__name__)

    # Setting up the logging
    setup_logging_config(cfg)

    logger.info("Successfully updated the logging configuration!")

    run_version = args.version
    logger.info(f"Running version: {run_version}")

    # exec all pipelines if not specified
    pipelines = (
        ["segmentation", "unconstrained_demand"] if not args.pipeline else args.pipeline
    )
    for p in pipelines:
        if not args.nodes:  # if not specified, run all
            nodes = ["preprocess", "modeling", "recommendation", "reporting", "deploy"]
        else:
            nodes = args.nodes
        runpy.run_module(
            mod_name=f"src.vmx_ppo.{p}",
            init_globals={"nodes": nodes, "run_version": run_version, "env": args.env},
        )


if __name__ == "__main__":
    main()
