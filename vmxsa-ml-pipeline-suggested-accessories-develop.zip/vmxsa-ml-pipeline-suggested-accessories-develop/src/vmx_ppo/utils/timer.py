from time import time
import datetime


def timer_func(func):
    """This function shows the execution time of the function object passed"""

    def wrap_func(*args, **kwargs):
        start_time = time()
        result = func(*args, **kwargs)
        end_time = time()
        print(
            f"\n********************"
            f"Function {func.__name__!r} executed in {str(datetime.timedelta(seconds=(end_time - start_time)))}s"
            f"********************\n"
        )
        return result

    return wrap_func
