import datetime as dt
from typing import Tuple
from dateutil.relativedelta import relativedelta


def get_historical_range(target_month: int, duration: int) -> Tuple[int, int]:
    """
    Get historical start, end date before target month in int format.
    """
    target_month_dt = dt.datetime.strptime(str(target_month), "%Y%m")

    start_month_dt = target_month_dt - relativedelta(months=duration)
    end_month_dt = target_month_dt - relativedelta(months=1)

    start_month_str = start_month_dt.strftime("%Y%m")
    end_month_str = end_month_dt.strftime("%Y%m")
    return int(start_month_str), int(end_month_str)
