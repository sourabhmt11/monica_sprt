import logging
import logging.config


def setup_logging_config(cfg):
    logging.config.dictConfig(cfg.logging)
