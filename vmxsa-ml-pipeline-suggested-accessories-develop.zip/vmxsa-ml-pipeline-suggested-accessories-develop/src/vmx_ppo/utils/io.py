import pandas as pd
import dask.dataframe as dd
from typing import Dict, List, Union
import logging
import os
import pickle
from sklearn.base import BaseEstimator
import matplotlib.pyplot as plt
import seaborn as sns
import io
import boto3
import tempfile
import multiprocessing
from src.vmx_ppo.config.argument_parser import ArgumentParser

logger = logging.getLogger("io")
lock = multiprocessing.Lock()
s3_prefix = "s3a://"
jpeg_image_type = "image/jpeg"


def _get_file_path(file_path: str, param_dict: Dict = None) -> str:
    """
    Replace parameters in file path with values from param_dict.

    Args:
        file_path (str): file path from catalog
        param_dict (Dict, optional): dictionary of parameters to replace filepath vars with. Defaults to None.

    Returns:
        str: file path with parameters replaced
    """

    args = ArgumentParser()
    # If param_dict is None or empty, initialize it as an empty dictionary
    param_dict = param_dict or {}
    # Update param_dict with the "de_user" key-value pair
    param_dict.update({"de_user": args.de_user, "brand": args.brand})
    # Format the file_path string using the updated param_dict
    file_path = file_path.format(**param_dict)
    # Return the formatted file_path
    return file_path


def load_model(catalog_entry: Dict, param_dict: Dict = None, **kwargs) -> object:
    def s3_to_model(file_path: str, format: str):
        s3_path = file_path.replace("s3://", "").replace(s3_prefix, "")
        bucket = s3_path.split("/")[0]
        key = s3_path.split("/", 1)[1]

        s3 = boto3.resource("s3")
        obj = s3.Object(bucket, key)

        model = None
        if format == "pickle":
            body = obj.get()["Body"].read()
            model = pickle.loads(body)
        else:
            logger.error("Unsupported s3 type to model object.")

        return model

    file_type = catalog_entry["file_type"]
    file_path = _get_file_path(catalog_entry["file_path"], param_dict)

    logger.info(f"Reading {file_path}")
    if file_type == "pickle":
        if file_path[:2] == "s3":
            return s3_to_model(file_path, file_type)
        else:
            return pickle.load(open(file_path, "rb"))
    else:
        logger.error(f"File type {file_type} not supported")


def load_data(catalog_entry: Dict, param_dict: Dict = None, **kwargs) -> pd.DataFrame:
    def s3_to_dataframe(file_path: str, format: str):
        s3_path = file_path.replace("s3://", "").replace(s3_prefix, "")
        bucket = s3_path.split("/")[0]
        key = s3_path.split("/", 1)[1]

        s3 = boto3.resource("s3")
        obj = s3.Object(bucket, key)

        if format == "csv":
            with io.BytesIO(obj.get()["Body"].read()) as bio:
                df = pd.read_csv(bio)
        elif format == "parquet":
            with io.BytesIO(obj.get()["Body"].read()) as bio:
                df = pd.read_parquet(bio)
        else:
            logger.error("Unsupported s3 type to dataframe.")

        return df

    file_type = catalog_entry["file_type"]
    load_engine = (
        catalog_entry["load_engine"] if "load_engine" in catalog_entry else None
    )
    file_path = _get_file_path(catalog_entry["file_path"], param_dict)

    # Merging the passed kwargs with loaded kwargs.
    kwargs = {**catalog_entry.get("load_args", {}), **kwargs}

    logger.info(f"Reading {file_path}")
    if file_type == "csv":
        # add workaround so accessory-code NA will not be read as NaN
        na_values = [
            "",
            "#N/A",
            "#N/A N/A",
            "#NA",
            "-1.#IND",
            "-1.#QNAN",
            "-NaN",
            "-nan",
            "1.#IND",
            "1.#QNAN",
            "<NA>",
            "N/A",
            "NULL",
            "NaN",
            "n/a",
            "nan",
            "null",
        ]

        if file_path[:2] == "s3":
            return s3_to_dataframe(file_path, file_type)
        else:
            return pd.read_csv(
                file_path,
                na_values=na_values,
                keep_default_na=False,
                low_memory=False,
                **kwargs,
            )
    elif file_type == "parquet" and load_engine == "dask":
        return dd.read_parquet(file_path, engine="pyarrow", **kwargs)
    elif file_type == "parquet":
        if file_path[:2] == "s3":
            return s3_to_dataframe(file_path, file_type)
        else:
            return pd.read_parquet(file_path, **kwargs)
    elif file_type == "json":
        return pd.read_json(file_path, **kwargs)
    else:
        logger.error(f"File type {file_type} not supported")


def save_data(
    catalog_entry: Dict,
    df: Union[pd.DataFrame, BaseEstimator, dd.core.DataFrame],
    param_dict: Dict = None,
    **kwargs,
) -> None:
    def dataframe_to_s3(input_dataframe, file_path, format, mode=None):
        with lock:
            s3_path = file_path.replace("s3://", "").replace(s3_prefix, "")
            bucket = s3_path.split("/")[0]
            key = s3_path.split("/", 1)[1]
            s3 = boto3.resource("s3")

            if format == "parquet":
                out_buffer = io.BytesIO()
                input_dataframe.to_parquet(out_buffer, index=False)

            elif format == "csv":
                if mode == "a":  # append mode
                    # Read the existing file from S3 into a dataframe
                    obj = s3.Object(bucket, key)
                    file_content = obj.get()["Body"].read().decode("utf-8")
                    existing_dataframe = pd.read_csv(io.StringIO(file_content))
                    combined_dataframe = pd.concat(
                        [existing_dataframe, input_dataframe], ignore_index=True
                    )
                    out_buffer = io.StringIO()
                    combined_dataframe.to_csv(out_buffer, index=False)
                else:
                    out_buffer = io.StringIO()
                    input_dataframe.to_csv(out_buffer, index=False)
            else:
                logger.error("Unsupported dataframe to s3 type.")

            s3.Bucket(bucket).put_object(Key=key, Body=out_buffer.getvalue())

    def s3_sklearn_model_upload(model, path: str) -> None:
        """Saves model to memory and uploads model as pickle file to S3 via boto3"""
        s3_path = path.replace("s3://", "").replace(s3_prefix, "")
        bucket = s3_path.split("/")[0]
        key = s3_path.split("/", 1)[1]

        try:
            # write as tempfile in memory then push to S3
            with tempfile.TemporaryFile() as fp:
                pickle.dump(model, fp)
                fp.seek(0)
                boto3.resource("s3").Bucket(bucket).put_object(Key=key, Body=fp.read())
                logger.info(f"{key.split('/')[-1]} has been successfully saved in s3!")
        except Exception as err:
            logger.error("Failed to write sklearn model to S3.")
            logger.error(err)

    file_type = catalog_entry["file_type"]
    file_path = _get_file_path(catalog_entry["file_path"], param_dict)
    # Merging the passed kwargs with loaded kwargs.
    kwargs = {**catalog_entry.get("save_args", {}), **kwargs}
    mode = kwargs["mode"] if kwargs else None
    logger.info(f"Saving {file_path}")

    # if path is unavailable, create new folder
    folder_path = os.path.dirname(file_path)
    os.makedirs(folder_path, exist_ok=True)

    if file_type == "csv" and isinstance(df, dd.core.DataFrame):
        df = df.compute()
        if file_path[:2] == "s3":
            dataframe_to_s3(df, file_path, "csv", mode)
        else:
            df.to_csv(file_path, index=False, **kwargs)
    elif file_type == "csv" and isinstance(df, pd.DataFrame):
        if file_path[:2] == "s3":
            dataframe_to_s3(df, file_path, "csv", mode)
        else:
            df.to_csv(file_path, index=False, **kwargs)
    elif file_type == "parquet" and isinstance(df, dd.core.DataFrame):
        df = df.compute()
        if file_path[:2] == "s3":
            dataframe_to_s3(df, file_path, "parquet")
        else:
            df.to_parquet(file_path, index=False, **kwargs)
    elif file_type == "parquet" and isinstance(df, pd.DataFrame):
        if file_path[:2] == "s3":
            dataframe_to_s3(df, file_path, "parquet")
        else:
            df.to_parquet(file_path, index=False, **kwargs)
    elif file_type == "pickle":
        if file_path[:2] == "s3":
            s3_sklearn_model_upload(df, file_path)
        else:
            with open(file_path, "wb") as f:
                pickle.dump(df, f)
    elif file_type == "json":
        df.to_json(file_path)
    else:
        logger.error(f"File type {file_type} not supported")


def plot_save_figure(
    catalog_entry: Dict, data: Union[pd.Series, List], param_dict: Dict = None
) -> None:
    def s3_content_type(file_type: str) -> str:
        """Maps image file types to S3 content types"""
        mapping = {
            "png": "image/png",
            "jfif": jpeg_image_type,
            "jpeg": jpeg_image_type,
            "jpg": jpeg_image_type,
            "gif": "image/gif",
            "bm": "image/bmp",
            "bmp": "image/bmp",
        }

        return mapping[file_type]

    def s3_file_upload(file_data: io.BytesIO, path: str) -> None:
        """Uploads file_data saved in memory to S3 via boto3"""
        file_type = path.split("/")[-1].split(".")[-1].lower()
        try:
            content_type = s3_content_type(file_type)
        except:
            logger.error(
                f"Do not support the current input type of {file_type}! (Try updating the s3_content_type mapping)"
            )
        s3_path = path.replace("s3://", "").replace(s3_prefix, "")
        bucket = s3_path.split("/")[0]
        key = s3_path.split("/", 1)[1]

        try:
            boto3.resource("s3").Bucket(bucket).put_object(
                Key=key, Body=file_data, ContentType=content_type
            )
            logger.info(f"{key.split('/')[-1]} has been successfully saved in s3!")
        except Exception as err:
            logger.error("Failed to write file to S3.")
            logger.error(err)

    plot_type = catalog_entry["plot_type"]
    file_path = _get_file_path(catalog_entry["file_path"], param_dict)
    logger.info(f"Saving {file_path}")

    # if path is unavailable, create new folder
    folder_path = os.path.dirname(file_path)
    os.makedirs(folder_path, exist_ok=True)

    if plot_type == "histogram":
        # plot histogram with boxplot using mpl
        # https://stackoverflow.com/a/33382314
        f, (ax_box, ax_hist) = plt.subplots(
            2, sharex=True, gridspec_kw={"height_ratios": (0.15, 0.85)}
        )

        sns.boxplot(data, orient="h", ax=ax_box)
        sns.histplot(data, bins=30, kde=True, ax=ax_hist)

        ax_box.set(yticks=[])
        sns.despine(ax=ax_hist)
        sns.despine(ax=ax_box, left=True)

        if file_path[:2] == "s3":
            # Save the image in memory:
            img_data = io.BytesIO()
            plt.savefig(img_data, format="png")
            img_data.seek(0)
            # Save the in-memory image data in S3:
            s3_file_upload(img_data, file_path)
        else:
            plt.savefig(file_path)
    elif plot_type == "line":
        x_vals = range(1, len(data) + 1)
        plt.plot(x_vals, data)
        plt.xticks(x_vals)
        plt.grid()
        if file_path[:2] == "s3":
            # Save the image in memory:
            img_data = io.BytesIO()
            plt.savefig(img_data, format="png")
            img_data.seek(0)
            # Save the in-memory image data in S3:
            s3_file_upload(img_data, file_path)
        else:
            plt.savefig(file_path)
    else:
        logger.error(f"Image type {plot_type} not supported")


def filter_by_columns(df: pd.DataFrame, col_list: List) -> pd.DataFrame:
    """Select specific columns from dataframe based on list; drops duplicates after subsetting.

    Args:
        df (pd.DataFrame): raw dataframe
        col_list (List): list of columns to keep

    Returns:
        pd.DataFrame: filtered dataframe
    """
    df_filtered = df[col_list].drop_duplicates().copy(deep=True)
    return df_filtered
