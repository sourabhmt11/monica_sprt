# utils/enums.py

from enum import Enum


class AggregationLevel(Enum):
    DEALER_GRAIN_SEGMENT_CORR_QUARTILE = "dealer-grain-segment-corr-quartile"
    DISTRICT_GRAIN_SEGMENT_CORR_QUARTILE = "district-grain-segment-corr-quartile"
    DISTRICT_GRAIN_SEGMENT_CORR = "district-grain-segment-corr"
    DISTRICT_GRAIN_SEGMENT = "district-grain-segment"
    DISTRICT_GRAIN = "district-grain"

    @classmethod
    def is_valid(cls, level: str) -> bool:
        return level in (item.value for item in cls)

    @classmethod
    def get(cls, level: str) -> "Optional[AggregationLevel]":
        return cls.__members__.get(level)
