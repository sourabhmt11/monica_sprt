from typing import Dict, List
import json
import yaml
import os
import sys
import cerberus
import collections

from jinja2 import Environment, FileSystemLoader, StrictUndefined


class ConfigParser:
    """
    Parsing the configuration provided in conf file.
    """

    CONFIG_FOLDER = "/conf/"
    CONFIG_VALIDATION_FOLDER = ".validation/"
    CONFIG_GLOBALS = "globals"

    def __init__(
        self,
        path: str = None,
        env: str = None,
        brand: str = None,
        month: List[int] = None,
        version: str = None,
        booster: float = None,
        reducer: float = None,
        segments: int = 0,
    ):
        """Config files path."""
        self.wd = os.path.abspath(
            sys.modules[self.__module__].__file__ + "/../../../../"
        )
        print("wd**************", self.wd)
        if path:
            self.conf = path
        else:
            self.conf = self.wd + "/conf/"

        # validation schemas for the yaml files
        self.conf_validation = self.conf + self.CONFIG_VALIDATION_FOLDER

        # Loading the environment
        self.env = env
        self.brand = brand
        self.month = month
        self.version = version
        self.booster = booster
        self.reducer = reducer
        self.segments = segments

        # Loading the configuration
        self._load_config()

    def _get_priority(self) -> List:
        """
        Get the priority list for loading the configurations
        Returns:
        A list of folder name with "default" being read first.
        """
        priority_list = ["default", "dev", "prod", "local", "test"]

        # return the default priority_list in case env variable not found.
        if not self.env:
            return [f"{x}/" for x in priority_list]

        if self.env not in priority_list:
            raise ValueError(f"Invalid env specified: {self.env}")

        # return list containing default + env specified
        if self.env == priority_list[0]:
            return [f"{self.env}/"]
        else:
            return [f"{priority_list[0]}/", f"{self.env}/"]

    def _get_file_priority(self) -> List:
        """
        Prioritizing the file reading sequence, last one will be highest priority.
        TODO: Make the function dynamic
        Returns:
        A list of file names with "globals" being read first.
        """
        return [
            "globals",
            "catalog",
            "credentials",
            "parameters",
            "logging",
        ]

    def _load_config(self) -> None:
        """Loading the configuration files"""
        files = self._get_file_priority()
        priorities = self._get_priority()

        for f in files:
            for folder in priorities:
                self._set_config_attr(f, folder)

    def _read_schema(self, name: str) -> Dict:
        """
        Read the JSON schema for validation of yml config files
        Args:
            name (str): Name of the file like, globals, catalog etc. Allowed names:
                "globals",
                "catalog",
                "credentials",
                "parameters",
                "logging"
        Returns (Dict):
            A dictionary of schema file for yaml
        """
        if not os.path.isfile(self.conf_validation + f"{name}.json"):
            return {}

        with open(self.conf_validation + f"{name}.json", "r") as f:
            schema = json.loads(f.read())

        return schema

    def _validate_yaml(self, name: str, data: dict) -> bool:
        """
        Validate yaml file data with loaded schema
        Args:
            name (str): name of ythe configuration type
            data (dict): config data that was read
        Returns (dict):
           A boolan confirming validity
        Raises (cerberus.DocumentError):
            In case yaml is not valid an error is raised
        """
        schema = self._read_schema(name)
        v = cerberus.Validator({"v": schema})
        is_valid = v.validate({"v": data})
        if not is_valid:
            raise cerberus.DocumentError(
                f"Invalid yaml format for {name}.yml. \n {v.errors['v']}"
            )
        return data

    def _read_yaml(self, name: str, folder_path: str) -> Dict:
        """
        Reading the passed yaml file.
        Args:
            name (str): Name of the file being read.
            file_path (str): File path for yaml file to be read.
        Retuns (Dict):
            Loaded configuration.
        """
        if not os.path.isfile(self.conf + folder_path + f"{name}.yml"):
            return {}

        with open(self.conf + folder_path + f"{name}.yml", "r") as stream:
            try:
                if name != self.CONFIG_GLOBALS:
                    stream = self._populate_global_variables(
                        folder_path + f"{name}.yml"
                    )

                config = yaml.safe_load(stream) or {}

                # Validating if configured not to validate
                self._validate_yaml(name, config)
                return config
            except yaml.YAMLError as exc:
                raise yaml.YAMLError(
                    f"Please check you configuration file at {folder_path + f'{name}.yml'}"
                )
            except cerberus.DocumentError as e:
                raise ValueError(e)

    def _populate_global_variables(self, file_path: str) -> str:
        """
        Updating the templates with global configuration values.
        Args:
            file_path: File path for yaml file to be rendered.
        Retuns:
            Rendered templates
        """
        env = Environment(loader=FileSystemLoader(self.conf), undefined=StrictUndefined)
        rendered = env.get_template(file_path).render(self.globals)

        return rendered.encode("utf-8")

    def _set_config_attr(self, name: str, folder_path: str) -> None:
        """
        Settting the configuration attributes to get the object access.
        Args:
            file_name: name of the file ex. globals
            folder_path: folder in which the file resides
        """
        config = getattr(self, name, {})
        config = self.__deep_update(config, self._read_yaml(name, folder_path))
        if name == self.CONFIG_GLOBALS:
            config.update(dict({k.lower(): v for k, v in os.environ.items()}))
        setattr(self, name, config)

    def __deep_update(self, source, overrides):
        """
        Update a nested dictionary or similar mapping.
        Modify ``source`` in place.
        """
        for key, value in overrides.items():
            if isinstance(value, collections.abc.Mapping) and value:
                returned = self.__deep_update(source.get(key, {}), value)
                source[key] = returned
            else:
                source[key] = overrides[key]
        return source
