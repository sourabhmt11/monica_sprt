import argparse
from datetime import datetime


def validate_brand(brand):
    """Validate the brand parameter to be either toyota or lexus."""
    valid_brands = {"toyota", "lexus"}
    brand = brand.lower()
    if brand not in valid_brands:
        raise argparse.ArgumentTypeError(
            f"Invalid brand: {brand}. Valid options are {', '.join(valid_brands)}."
        )
    return brand


def validate_month(month):
    """Validate the date parameter in YYYYMM format."""
    try:
        datetime.strptime(month, "%Y%m")
    except ValueError:
        raise ValueError(f"Invalid date format: {month}. Expected YYYYMM.")

    return int(month)


class ArgumentParser:
    def __init__(self):
        """Parse via argparse and set as attributes."""
        parser = argparse.ArgumentParser(
            description="Run vmx_ppo pipelines.",
            usage="python -m vmx_ppo --p <pipeline(s)> --n <node(s)> --e <env> --b <brand> --m <month(s)> --v <run "
            "version> --c <number of clusters>",
        )
        parser.add_argument(
            "--pipeline",
            metavar="p",
            type=str,
            nargs="+",
            default=None,
            help="Specify pipeline to run. Either 'unconstrained_demand' or 'segmentation'.",
        )
        parser.add_argument(
            "--nodes",
            metavar="n",
            type=str,
            nargs="+",
            default=None,
            help="Specify node(s) to run: valid options are pipeline dependent. For 'unconstrained_demand': 'preprocess', 'modeling', 'recommendation', 'reporting'. For 'segmentation': 'preprocess', 'modeling', 'reporting'.",
        )
        parser.add_argument(
            "--env",
            metavar="e",
            type=str,
            default=None,
            help="Specify environment(s) to run: valid options are 'default', 'dev', 'prod', 'local'",
        )
        parser.add_argument(
            "--b",
            "--brand",
            metavar="b",
            dest="brand",
            type=validate_brand,
            default=None,
            help="Specify the brand to run. Valid options are 'toyota' or 'lexus'. Default is None.",
        )
        parser.add_argument(
            "--month",
            metavar="m",
            type=validate_month,
            nargs="+",
            default=None,
            help="Specify the recommendation month(s) separated by spaces. Each month should be in YYYYMM format. Example usage: 202302 202303 202304. Default is None.",
        )
        parser.add_argument(
            "--segments",
            metavar="s",
            type=int,
            default=-1,
            help="Specify the number of segmentation clusters",
        )
        parser.add_argument(
            "--de_user",
            type=str,
            default=None,
            help="Specify the de user to run. Default is None",
        )
        parser.add_argument(
            "--version",
            metavar="v",
            type=str,
            default="default",
            help="Specify the run version. Default is 'default'",
        )
        parser.add_argument(
            "--booster",
            type=float,
            default=None,
            help="Specify the Q4 booster: example usage 0.20 for a 20% boost",
        )
        parser.add_argument(
            "--reducer",
            type=float,
            default=None,
            help="Specify the Q1 reducer: example usage 0.05 for a 5% reduction",
        )
        args = parser.parse_args()
        if args.segments == -1 and args.pipeline and args.pipeline[0] == "segmentation":
            raise argparse.ArgumentError(
                "Invalid Combination: Segmentation pipeline requires number of segments as input."
            )
        self.pipeline = args.pipeline
        self.nodes = args.nodes
        self.env = args.env
        self.brand = args.brand
        self.month = args.month
        self.segments = args.segments
        self.version = args.version
        self.de_user = args.de_user
        self.booster = args.booster
        self.reducer = args.reducer
