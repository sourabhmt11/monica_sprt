import logging

import dask.dataframe as dd
import pandas as pd
from sklearn.preprocessing import power_transform
from typing import Dict
import numpy as np
from src.vmx_ppo.utils.io import load_data, save_data, filter_by_columns

logger = logging.getLogger("vmx_ppo.segmentation.preprocess")


def preprocess_segmentation_data(
    segmentation_df: dd.core.DataFrame, brand: str
) -> pd.DataFrame:
    """Preprocess segmentation data: subset columns and normalization

    Args:
        segmentation_df (dd.core.DataFrame): segmentation data with all cleaned features
        brand (str): Toyota or Lexus brand

    Returns:
        pd.DataFrame: segmentation data with selected features and normalized
    """
    if brand in ("toyota", "lexus"):
        selected_columns = [
            "dealer_number_latest",
            "AGE_young_perc",
            "AGE_middle_aged_perc",
            "AGE_seniors_perc",
            "INCOME_rich_perc",
            "INCOME_upper_middle_perc",
            "INCOME_lower_middle_perc",
            "LOC_urban_perc",
            "LOC_sub_urban_perc",
            "weather_tavg_ab_32",
            "weather_tavg_bl_0",
            "weather_snow_day",
            "weather_rain_day",
            "drivetrain_4WD_perc",
            "lease_pct",
            "apr_pct",
            "none_pct",
        ]
    else:
        logger.exception(f"Invalid brand passed to segmentation: {brand}")
        raise Exception(f"Invalid brand passed to segmentation: {brand}")

    segmentation_df = segmentation_df.compute()
    segmentation_df = filter_by_columns(segmentation_df, selected_columns)

    # normalization
    segmentation_scaled = power_transform(
        segmentation_df.iloc[:, 1:].replace("null", np.nan).fillna(0),
        method="yeo-johnson",
    )
    segmentation_scaled_df = pd.DataFrame(
        segmentation_scaled, columns=segmentation_df.iloc[:, 1:].columns
    )
    segmentation_model_input = pd.concat(
        [segmentation_df.iloc[:, :1], segmentation_scaled_df], axis=1
    )

    return segmentation_model_input


def run(base_parameters: Dict, data_catalog: Dict, run_version: str) -> None:
    logger.info(f"Run version: {run_version}")
    ######################################################################################################
    # Load data
    ######################################################################################################

    brand = base_parameters["brand"]
    io_dict = {"run_version": run_version, "brand": brand}
    segmentation_raw_df = load_data(
        data_catalog["segmentation_features_selected"], param_dict=io_dict
    )

    # TODO: Remove this lex_toy_ind nonsense and replace with brand
    # map DE names to clearer naming conventions
    segmentation_raw_df = segmentation_raw_df.rename(columns={"lex_toy_ind": "brand"})
    lex_toy_ind_map = {"L": "lexus", "T": "toyota"}
    segmentation_raw_df["brand"] = segmentation_raw_df["brand"].map(lex_toy_ind_map)

    segmentation_raw_df = segmentation_raw_df.loc[
        segmentation_raw_df["brand"] == brand
    ].reset_index(drop=True)

    segmentation_input_df = preprocess_segmentation_data(segmentation_raw_df, brand)

    ######################################################################################################
    # Save data
    ######################################################################################################
    save_data(
        data_catalog[f"segmentation_model_input"],
        segmentation_input_df,
        param_dict=io_dict,
    )
