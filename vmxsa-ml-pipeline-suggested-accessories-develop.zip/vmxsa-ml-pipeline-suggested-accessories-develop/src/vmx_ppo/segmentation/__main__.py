from src.vmx_ppo.config.argument_parser import ArgumentParser
from src.vmx_ppo.config.config_parser import ConfigParser
import src.vmx_ppo.segmentation.preprocess as preprocess
import src.vmx_ppo.segmentation.modeling as modeling
import src.vmx_ppo.segmentation.reporting as reporting
import logging


def main():
    args = ArgumentParser()
    cfg = ConfigParser(env=env)

    # import parameters and catalog
    parameters = cfg.parameters
    catalog = cfg.catalog

    data_catalog = catalog["segmentation"]
    params = parameters["segmentation"]
    params.update(
        {"brand": args.brand, "run_version": args.version, "n_clusters": args.segments}
    )

    if "preprocess" in nodes:
        logging.info("Running segmentation.preprocess node")
        preprocess.run(params, data_catalog, run_version)
    if "modeling" in nodes:
        logging.info("Running segmentation.modeling node")
        modeling.run(params, data_catalog, run_version)
    if "reporting" in nodes:
        logging.info("Running segmentation.reporting node")
        reporting.run(params, data_catalog, run_version)


if "__main__" in __name__:
    main()
