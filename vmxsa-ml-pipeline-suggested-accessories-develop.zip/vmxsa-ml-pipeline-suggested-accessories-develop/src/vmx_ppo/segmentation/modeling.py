from src.vmx_ppo.utils.io import load_data, save_data
import logging
from typing import Tuple, Dict
from sklearn.cluster import KMeans
import pandas as pd


logger = logging.getLogger("vmx_ppo.segmentation.modeling")


def train_segmentation_model(
    segmentation_df: pd.DataFrame, param_dict: Dict
) -> Tuple[pd.DataFrame, KMeans]:
    """
    Train segmentation model and return model output DataFrame.

    Args:
        segmentation_df (pd.DataFrame): segmentation data with selected features and normalized
        param_dict (Dict): parameter dictionary

    Returns:
        pd.DataFrame: segmentation data with cluster labels attached
        KMeans: sklearn model object for saving
    """
    n_clusters = param_dict["n_clusters"]
    logger.info(f"Training segmentation model on {n_clusters} clusters")
    random_state = param_dict["random_state"]
    # make kmeans deterministic
    kmeans = KMeans(n_clusters=n_clusters, random_state=random_state)
    kmeans.fit(segmentation_df.iloc[:, 1:])
    logger.info("Segmentation model trained")
    segmentation_df["label"] = kmeans.labels_
    return segmentation_df, kmeans


def extract_dealer_code_and_labels(segmentation_model_output_df: pd.DataFrame):
    dealer_number_and_labels_df = segmentation_model_output_df[
        ["dealer_number_latest", "label"]
    ]
    dealer_code_and_labels_df = dealer_number_and_labels_df.rename(
        columns={"dealer_number_latest": "dealer_code"}
    )
    return dealer_code_and_labels_df


def run(base_parameters: Dict, data_catalog: Dict, run_version: str) -> None:
    logger.info(f"Run version: {run_version}")
    ######################################################################################################
    # Load data
    ######################################################################################################

    brand = base_parameters["brand"]
    io_dict = {"run_version": run_version, "brand": brand}
    segmentation_model_input_df = load_data(
        data_catalog[f"segmentation_model_input"], param_dict=io_dict
    )

    ######################################################################################################
    # Train segmentation model
    ######################################################################################################

    segmentation_model_output_df, segmentation_model = train_segmentation_model(
        segmentation_model_input_df, base_parameters
    )

    dealer_code_and_labels_df = extract_dealer_code_and_labels(
        segmentation_model_output_df
    )

    ######################################################################################################
    # Save data
    ######################################################################################################

    save_data(
        data_catalog[f"segmentation_model_output"],
        dealer_code_and_labels_df,
        param_dict=io_dict,
    )
    save_data(
        data_catalog[f"segmentation_model_output_backup"],
        dealer_code_and_labels_df,
        param_dict=io_dict,
    )
    save_data(
        data_catalog[f"segmentation_model_output_all_features"],
        segmentation_model_output_df,
        param_dict=io_dict,
    )
    save_data(
        data_catalog[f"segmentation_model"],
        segmentation_model,
        param_dict=io_dict,
    )
