from src.vmx_ppo.utils.io import load_data, plot_save_figure, save_data
import logging
from typing import List, Dict
import numpy as np
import pandas as pd
from statistics import mean
from sklearn.cluster import KMeans
from scipy.spatial.distance import pdist, cdist


logger = logging.getLogger("vmx_ppo.segmentation.modeling")


def inter_metrics(data: pd.DataFrame, num_clusters: int) -> Dict:
    """Fetches intercluster distance metrics.

    Args:
        data (pd.DataFrame): segmentation data
        num_clusters (int): number of clusters

    Returns:
        dict: intercluster distance metrics
    """

    def single_linkage_distance() -> Dict:
        """the closest distance between two objects in 2 clusters"""

        metrics = {
            (i, j): None
            for i in range(num_clusters)
            for j in range(i, num_clusters)
            if i != j
        }

        for i in range(num_clusters):
            for j in range(i, num_clusters):
                if i == j:
                    continue
                cluster_i = data.loc[data["label"] == i].iloc[:, :-1]
                cluster_j = data.loc[data["label"] == j].iloc[:, :-1]
                metrics[(i, j)] = round(np.min(cdist(cluster_i, cluster_j)), 2)

        return metrics

    def complete_maximum_linkage_distance() -> Dict:
        """the farthest distance between two objects in 2 clusters"""

        metrics = {
            (i, j): None
            for i in range(num_clusters)
            for j in range(i, num_clusters)
            if i != j
        }

        for i in range(num_clusters):
            for j in range(i, num_clusters):
                if i == j:
                    continue
                cluster_i = data.loc[data["label"] == i].iloc[:, :-1]
                cluster_j = data.loc[data["label"] == j].iloc[:, :-1]
                metrics[(i, j)] = round(np.max(cdist(cluster_i, cluster_j)), 2)

        return metrics

    inter_metrics_data = {
        "single_linkage_distance": single_linkage_distance(),
        "complete_maximum_linkage_distance": complete_maximum_linkage_distance(),
    }

    return inter_metrics_data


def intra_metrics(
    data: pd.DataFrame, num_clusters: int, cluster_centers: np.ndarray
) -> Dict:
    """
    Fetches intracluster distance metrics.

    Args:
        data (pd.DataFrame): segmentation data
        num_clusters (int): number of clusters
        cluster_centers (ndarray of shape (n_clusters, n_features)): center of each cluster in order

    Returns:
        dict: intercluster distance metrics
    """

    def complete_diameter_distance() -> Dict:
        """the farthest distance between two points in a cluster"""

        metrics = {k: None for k in range(num_clusters)}
        for k in range(num_clusters):
            cluster = data.loc[data["label"] == k].iloc[:, :-1]
            metrics[k] = round(max(pdist(cluster.loc[list(cluster.index)])), 2)
        return metrics

    def average_diameter_distance() -> Dict:
        """the average distance between all points in a cluster"""

        metrics = {k: None for k in range(num_clusters)}
        for k in range(num_clusters):
            cluster = data.loc[data["label"] == k].iloc[:, :-1]
            metrics[k] = round(mean(pdist(cluster.loc[list(cluster.index)])), 2)
        return metrics

    def centroid_diameter_distance() -> Dict:
        """the double of average distance between points and the center of a cluster"""

        metrics = {k: None for k in range(num_clusters)}
        for k in range(num_clusters):
            cluster = data.loc[data["label"] == k].iloc[:, :-1]
            metrics[k] = round(
                2
                * mean(
                    np.linalg.norm(
                        cluster.loc[list(cluster.index)].sub(
                            np.array(cluster_centers[k])
                        ),
                        axis=1,
                    )
                ),
                2,
            )
        return metrics

    inter_metrics_data = {
        "complete_diameter_distance": complete_diameter_distance(),
        "average_diameter_distance": average_diameter_distance(),
        "centroid_diameter_distance": centroid_diameter_distance(),
    }

    return inter_metrics_data


def generate_cluster_metrics(
    segmentation_model_input_df: pd.DataFrame, param_dict: Dict
) -> Dict:
    """
    Train Kmeans with n_clusters from 4 to 11 and return inter/intra distances for each value.

    Args:
        segmentation_model_input_df (pd.DataFrame): data to train segmentation model on
        param_dict (Dict): dict of run parameters

    Returns:
        Dict: inter/intra distances for each run
    """
    kmeans_kwargs = {
        "init": "random",
        "n_init": 10,
        "max_iter": 300,
        "random_state": param_dict["random_state"],
    }

    cluster_range = range(4, 11)
    cluster_metrics_dict = {k: {} for k in cluster_range}
    for k in cluster_range:
        cluster_k_metrics_dict = cluster_metrics_dict[k]
        kmeans = KMeans(n_clusters=k, **kmeans_kwargs)
        kmeans.fit(segmentation_model_input_df.iloc[:, 1:])
        segmentation_model_input_df["label"] = kmeans.labels_
        cluster_k_metrics_dict["intra_metrics_data"] = intra_metrics(
            segmentation_model_input_df.iloc[:, 1:], k, kmeans.cluster_centers_
        )
        cluster_k_metrics_dict["inter_metrics_data"] = inter_metrics(
            segmentation_model_input_df.iloc[:, 1:], k
        )
        segmentation_model_input_df = segmentation_model_input_df.iloc[:, :-1]
    return cluster_metrics_dict


def generate_elbow_plot(
    segmentation_model_input_df: pd.DataFrame, param_dict: Dict
) -> List:
    """
    Train Kmeans with n_clusters from 1 to 25 and return sum of squared Euclidean distances for each value.

    Args:
        segmentation_model_input_df (pd.DataFrame): data to train segmentation model on
        param_dict (Dict): dict of run parameters

    Returns:
        List: sum of squared Euclidean distances for each run
    """
    kmeans_kwargs = {
        "init": "random",
        "n_init": 10,
        "max_iter": 300,
        "random_state": param_dict["random_state"],
    }

    # A list holds the SSE values for each k
    sse = []
    for k in range(1, 25):
        kmeans = KMeans(n_clusters=k, **kmeans_kwargs)
        kmeans.fit(segmentation_model_input_df.iloc[:, 1:])
        sse.append(kmeans.inertia_)
    return sse


def run(base_parameters: Dict, data_catalog: Dict, run_version: str) -> None:
    logger.info(f"Run version: {run_version}")
    ######################################################################################################
    # Load data
    ######################################################################################################

    brand = base_parameters["brand"]
    io_dict = {"run_version": run_version, "brand": brand}
    segmentation_model_input_df = load_data(
        data_catalog[f"segmentation_model_input"], param_dict=io_dict
    )
    ######################################################################################################
    # Generate elbow plot
    ######################################################################################################
    sse = generate_elbow_plot(segmentation_model_input_df, base_parameters)
    ######################################################################################################
    # Save data
    ######################################################################################################
    plot_save_figure(data_catalog[f"elbow_plot"], sse, param_dict=io_dict)

    ######################################################################################################
    # Generate cluster metrics
    ######################################################################################################
    cluster_metrics_dict = generate_cluster_metrics(
        segmentation_model_input_df, base_parameters
    )
    ######################################################################################################
    # Save cluster metric data
    ######################################################################################################
    save_data(
        data_catalog[f"cluster_metrics"],
        pd.DataFrame.from_dict(cluster_metrics_dict),
        param_dict=io_dict,
    )
