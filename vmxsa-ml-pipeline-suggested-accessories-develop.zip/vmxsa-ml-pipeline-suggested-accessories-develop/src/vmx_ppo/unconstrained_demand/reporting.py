import numpy as np
import pandas as pd
import logging
from typing import List, Dict, Tuple
from src.vmx_ppo.utils.io import load_data, save_data
from src.vmx_ppo.utils.date import get_historical_range
from src.vmx_ppo.utils.timer import timer_func
import concurrent.futures
from concurrent.futures import wait

logger = logging.getLogger("src.vmx_ppo.unconstrained_demand.reporting")


def add_historical_month_ppo_cols(
    df_rules_result_final: pd.DataFrame,
    df_sale_ppo_historical: pd.DataFrame,
    df_sale_grain_historical: pd.DataFrame,
    aggregation_level: str,
    param_dict: Dict,
) -> pd.DataFrame:
    """Obtain the historical ppo install rates and historical quantity sold at grain/ppo level

    Args:
        df_rules_result_final (pd.DataFrame): rule base recommendation
        df_sale_ppo_historical (pd.DataFrame): historical ppo sales quantity
        df_sale_grain_historical (pd.DataFrame): historical grain sales quantity
        aggregation_level (str): grain
        param_dict (Dict): Run parameters

    Returns:
        pd.DataFrame: dataframe with both recommended IR and historical IR, quantity sold
    """
    # No cars allocated in the month
    if df_rules_result_final.empty:
        return df_rules_result_final

    # only keep historical grain-dealer pair that has regional allocation
    agg_cols = ["series_name", "dealer_number_latest"]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]
    df_sale_ppo_historical = pd.merge(
        df_sale_ppo_historical,
        df_rules_result_final[agg_cols].drop_duplicates(),
        how="inner",
    )

    # fill edge case col for debugging purpose
    df_rules_result_final["edge_case"] = "Base recommendation"

    # check no duplication
    assert (
        df_rules_result_final.shape[0]
        == df_rules_result_final[agg_cols + ["accessory_code"]]
        .drop_duplicates()
        .shape[0]
    )
    # Add in grain-dealer-ppo pair that has history but no recommendation
    df_rules_result_final_with_ppo = pd.merge(
        df_rules_result_final[agg_cols + ["accessory_code"]].drop_duplicates(),
        df_sale_ppo_historical[agg_cols + ["accessory_code"]].drop_duplicates(),
        how="outer",
    )
    assert (
        df_rules_result_final_with_ppo.shape[0]
        == df_rules_result_final_with_ppo[agg_cols + ["accessory_code"]]
        .drop_duplicates()
        .shape[0]
    )

    # map in dealer-grain info & grain correlation
    dealer_grain_cols = [
        "dealer_number_latest",
        param_dict["cluster_col"],
        "business_month",
        "quartile",
        "no_quartile_new_grain",
        "no_model_history_quartile_segment",
    ]
    grain_cols = [param_dict["cluster_col"], "correlation_category", "correl"]
    if aggregation_level in ("model", "grade"):
        dealer_grain_cols += ["model_number"]
        grain_cols += ["model_number"]

    # get dealer-grain info mapping
    dealer_quartile_map = df_rules_result_final[dealer_grain_cols].drop_duplicates()
    # get correlation mapping
    dealer_corr_map = df_rules_result_final[grain_cols].drop_duplicates()

    # map in dealer-grain info
    df_rules_result_final_with_ppo = pd.merge(
        df_rules_result_final_with_ppo,
        dealer_quartile_map,
        how="left",
    )
    assert (
        df_rules_result_final_with_ppo.shape[0]
        == df_rules_result_final_with_ppo[agg_cols + ["accessory_code"]]
        .drop_duplicates()
        .shape[0]
    )
    # map in correlation
    dealer_corr_map.loc[:, "correlation_category_agg"] = dealer_corr_map[
        "correlation_category"
    ].apply(lambda x: "None/Positive" if x in ["None", "Positive"] else "Negative")
    df_rules_result_final_with_ppo = pd.merge(
        df_rules_result_final_with_ppo,
        dealer_corr_map,
        how="left",
    )
    assert (
        df_rules_result_final_with_ppo.shape[0]
        == df_rules_result_final_with_ppo[agg_cols + ["accessory_code"]]
        .drop_duplicates()
        .shape[0]
    )

    # map in recommended rules info
    df_rules_result_final_with_ppo = pd.merge(
        df_rules_result_final_with_ppo,
        df_sale_ppo_historical[
            agg_cols + ["accessory_code", "quantity_retail_ppo"]
        ].drop_duplicates(),
        how="left",
    )
    assert (
        df_rules_result_final_with_ppo.shape[0]
        == df_rules_result_final_with_ppo[agg_cols + ["accessory_code"]]
        .drop_duplicates()
        .shape[0]
    )
    # fill historical quantity retail ppo as 0 and rename
    df_rules_result_final_with_ppo[
        ["quantity_retail_ppo"]
    ] = df_rules_result_final_with_ppo[["quantity_retail_ppo"]].fillna(0)
    df_rules_result_final_with_ppo.rename(
        {"quantity_retail_ppo": "quantity_retail_ppo_historical"}, axis=1, inplace=True
    )

    # map in recommended rules info
    df_rules_result_final_with_ppo = pd.merge(
        df_rules_result_final_with_ppo,
        df_rules_result_final[
            agg_cols
            + [
                "accessory_code",
                "rec_retail_installation_rate",
                "rule_agg_level",
                "quantity_retail_group",
                "edge_case",
            ]
        ].drop_duplicates(),
        how="left",
    )
    assert (
        df_rules_result_final_with_ppo.shape[0]
        == df_rules_result_final_with_ppo[agg_cols + ["accessory_code"]]
        .drop_duplicates()
        .shape[0]
    )
    # update edge_case for with history no recommendation cases
    df_rules_result_final_with_ppo[["edge_case"]] = df_rules_result_final_with_ppo[
        ["edge_case"]
    ].fillna("With history no recommendation")

    # map in historical quantity retail grain
    df_rules_result_final_with_ppo_grain = pd.merge(
        df_rules_result_final_with_ppo,
        df_sale_grain_historical[agg_cols + ["quantity_retail_grain"]],
        how="left",
    )
    assert (
        df_rules_result_final_with_ppo_grain.shape[0]
        == df_rules_result_final_with_ppo_grain[agg_cols + ["accessory_code"]]
        .drop_duplicates()
        .shape[0]
    )
    df_rules_result_final_with_ppo_grain[
        ["quantity_retail_grain"]
    ] = df_rules_result_final_with_ppo_grain[["quantity_retail_grain"]].fillna(0)
    df_rules_result_final_with_ppo_grain.rename(
        {"quantity_retail_grain": "quantity_retail_grain_historical"},
        axis=1,
        inplace=True,
    )

    assert df_rules_result_final_with_ppo_grain["quartile"].isna().sum() == 0
    assert (
        df_rules_result_final_with_ppo_grain["correlation_category"].isna().sum() == 0
    )

    return df_rules_result_final_with_ppo_grain


def concatenate_dataframes(dataframe_list: List[pd.DataFrame]) -> pd.DataFrame:
    """Concatenate list of dataframes into single df.

    Args:
        dataframe_list (List[pd.DataFrame]): list of dataframes

    Returns:
        pd.DataFrame: concatenated dataframe

    """
    concat_df = pd.concat(dataframe_list)
    return concat_df


def aggregate_impact_results(
    concat_df: pd.DataFrame,
    param_dict: Dict,
) -> pd.DataFrame:
    """Compute aggregated impact for a series and rule mode.

    Args:
        concat_df (pd.DataFrame): concatenated dataframe
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: aggregated summary

    """
    aggregation_level = param_dict["aggregation_level"]

    # 1.1 Calculate impact columns
    concat_df["baseline"] = (
        concat_df["msrp_ppo"]
        * concat_df["original_retail_install_rate_historical"]
        * concat_df["quantity_retail_grain_historical"]
        / param_dict["rules_len_historical_months"]
    )
    concat_df["lift"] = (
        concat_df["msrp_ppo"]
        * concat_df["lift_in_retail_install_rate"]
        * concat_df["quantity_retail_grain_historical"]
        / param_dict["rules_len_historical_months"]
    )

    dedupe_cols = ["series_name", "dealer_number_latest", "business_month"]
    if aggregation_level == "model":
        dedupe_cols.append("model_number")
    # Remove duplicates
    concat_df_deduped = concat_df.drop_duplicates(subset=dedupe_cols)

    # Calculate sum of 'quantity_retail_grain_historical'
    concat_df_deduped_agg = (
        concat_df_deduped.groupby(["business_month", "region_code"])
        .agg(
            {
                "quantity_retail_grain_historical": "sum",
            }
        )
        .reset_index()
    )

    concat_df_deduped_agg["quantity_retail_grain_historical"] = (
        concat_df_deduped_agg["quantity_retail_grain_historical"]
        / param_dict["rules_len_historical_months"]
    )

    concat_df_agg = (
        concat_df.groupby(["business_month", "region_code"])
        .agg(
            {
                "baseline": "sum",
                "lift": "sum",
                "msrp_ppo": "mean",
                "original_retail_install_rate_historical": "mean",
                "lift_in_retail_install_rate": "mean",
            }
        )
        .reset_index()
    )

    concat_df_agg = concat_df_agg.merge(
        concat_df_deduped_agg[
            ["business_month", "region_code", "quantity_retail_grain_historical"]
        ],
        on=["business_month", "region_code"],
        how="left",
    )

    return concat_df_agg


def aggregate_impact_across_series(
    series_list: List, mode: str, data_catalog: Dict, run_version: str
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Aggregate impact summary across series.

    Args:
        series_list (List): series list
        mode (str): lite/maxi ppo recommendation mode
        data_catalog (Dict): catalog entries
        run_version (str): run version stamp in data pth

    Returns:
        pd.DataFrame: aggregated impact summary output across series
        pd.DataFrame: aggregated filtered column impact summary output across series
        pd.DataFrame: aggregated lift summary across series

    """
    # aggregate impact summary across series
    df_impact_result_all_series = pd.DataFrame()
    for series in series_list:
        io_dict = {
            "series": series,
            "mode": mode,
            "run_version": run_version,
        }
        # TODO: load data within run function
        impact_series = load_data(
            data_catalog["consolidated_impact"], param_dict=io_dict
        )
        df_impact_result_all_series = df_impact_result_all_series.append(impact_series)
    df_impact_result_all_series["mode"] = mode
    df_impact_result_all_series = df_impact_result_all_series.reset_index(drop=True)

    # filtered col version
    df_impact_result_all_series_filter = df_impact_result_all_series.drop(columns=[])
    # aggregate impact across series
    df_result_all_series_agg = pd.DataFrame()
    for series in series_list:
        io_dict = {
            "series": series,
            "mode": mode,
            "run_version": run_version,
        }
        # TODO: load data within run function
        impact_agg_series = load_data(
            data_catalog["consolidated_impact_results"], param_dict=io_dict
        )
        impact_agg_series["series_name"] = series
        df_result_all_series_agg = df_result_all_series_agg.append(impact_agg_series)
    df_result_all_series_agg["mode"] = mode

    return (
        df_impact_result_all_series,
        df_impact_result_all_series_filter,
        df_result_all_series_agg,
    )


def add_all_dealer_ppo_combinations(
    result_df: pd.DataFrame, aggregation_level: str
) -> pd.DataFrame:
    """Add in all possible dealer-grain-ppo combinations so a static ppo list can be seen across all dealers.

    Args:
        result_df (pd.DataFrame): impact summary dataframe
        aggregation_level (str): grain

    Returns:
        pd.DataFrame: impact summary with all possible dealer-grain-ppo combinations
    """
    to_agg = ["series_name"]
    if aggregation_level in ("model", "grade"):
        to_agg += ["model_number"]

    grain_ppo_df = result_df[to_agg + ["accessory_code"]].drop_duplicates()
    dealer_grain_df = result_df[to_agg + ["dealer_number_latest"]].drop_duplicates()

    # get all dealer-grain-ppo combinations
    dealer_grain_ppo_df = pd.merge(dealer_grain_df, grain_ppo_df, how="inner")

    # get segment, quartile, correlation_category, and quantity_retail_grain for each dealer-grain-ppo combination
    dealer_grain_level_data = result_df[
        [
            "dealer_number_latest",
            "label",
            "business_month",
            "quartile",
            "correlation_category",
            "correl",
            "quantity_retail_grain_historical",
        ]
        + to_agg
    ].drop_duplicates()
    # make sure no additional rows are being created
    assert dealer_grain_level_data.shape[0] == dealer_grain_df.shape[0]
    dealer_grain_ppo_attr_df = pd.merge(
        dealer_grain_ppo_df, dealer_grain_level_data, how="inner"
    )

    # left join to get all possible dealer-grain-ppo pairs
    df_rules_result_final = pd.merge(dealer_grain_ppo_attr_df, result_df, how="left")
    df_rules_result_final.loc[
        df_rules_result_final["edge_case"].isna(), "edge_case"
    ] = "No history no recommendation"
    return df_rules_result_final


def post_processing_impact_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Post-processing on columns in impact summary for dashboard reporting

    Args:
        df (pd.DataFrame): dataframe before post-processing

    Returns:
        pd.DataFrame: dataframe with post-processing
    """

    # fill quantity_retail_ppo_historical as 0 (meaning in last X month, this dealer did not sell cars with this PPO)
    # fill quantity_retail_grain_historical as 0 (meaning in last X month, this dealer did not sell cars at grain level)
    for col in [
        "quantity_retail_ppo_historical",
        "quantity_retail_grain_historical",
    ]:
        df[col] = df[col].fillna(0)

    # if no quantity_retail_ppo and quantity_retail_model, make original_retail_installation_rate 0
    # if no historical install rate (meaning did not order this PPO in past X month for the dealer), make it 0
    for col in [
        "rec_retail_installation_rate",
        "original_retail_install_rate_historical",
    ]:
        df[col] = df[col].fillna(0)

    # fill original and recommended install rate as 0 if accessory code is No_PPO
    for col in [
        "rec_retail_installation_rate",
        "original_retail_install_rate_historical",
    ]:
        df.loc[df["accessory_code"] == "No_PPO", col] = 0

    # for cases where sale at ppo but not at model level
    # replace installation rate = inf with 0 and cap at 1
    for col in [
        "rec_retail_installation_rate",
        "original_retail_install_rate_historical",
    ]:
        df[col].replace([np.inf, -np.inf], 0, inplace=True)
        df.loc[df[col] > 1, col] = 1

    return df


def calculate_impact_cols(
    df: pd.DataFrame, rules_len_historical_months: int
) -> pd.DataFrame:
    """Create impact columns in impact summary for dashboard reporting

    Args:
        df (pd.DataFrame): dataframe before add in impact columns
        rules_len_historical_months (int): length of history we use for rule generation

    Returns:
        pd.DataFrame: dataframe with impact columns
    """
    # calculate lift in install rate
    df["lift_in_retail_install_rate"] = (
        df["rec_retail_installation_rate"]
        - df["original_retail_install_rate_historical"]
    )

    # calculate $PPO before and after
    df["ppo_amount_before_retail"] = (
        df["msrp_ppo"]
        * df["original_retail_install_rate_historical"]
        * df["quantity_retail_grain_historical"]
        / rules_len_historical_months
    )
    df["ppo_amount_after_retail"] = (
        df["msrp_ppo"]
        * df["rec_retail_installation_rate"]
        * df["quantity_retail_grain_historical"]
        / rules_len_historical_months
    )

    df["ppo_amount_before_pervehicle_retail"] = (
        df["msrp_ppo"] * df["original_retail_install_rate_historical"]
    )
    df["ppo_amount_after_pervehicle"] = (
        df["msrp_ppo"] * df["rec_retail_installation_rate"]
    )
    return df


def weighted_average(
    df: pd.DataFrame, value_col_list: List[str], weight_col: str
) -> pd.Series:
    """Calculate weighted average of value columns, excludes NAs in calculations.

    Args:
        df (pd.DataFrame): dataframe with value columns and weight column
        value_col_list (List[str]): list of value columns
        weight_col (str): weight column

    Returns:
        pd.Series: series with weighted average of value columns
    """
    result_dict = {}
    for value_col in value_col_list:
        # don't include in average if value is null
        df_copy = df[~df[value_col].isna()].copy()
        weighted_value = (
            sum(df_copy[weight_col] * df_copy[value_col]) / sum(df_copy[weight_col])
            if sum(df_copy[weight_col]) > 0
            else np.nan
        )
        result_dict[value_col] = weighted_value
    return pd.Series(result_dict)


def create_msrp_ppo_and_margin(
    df_rules_result: pd.DataFrame,
    df_joined: pd.DataFrame,
    aggregation_level: str,
    target_month_min: int,
    param_dict: Dict,
) -> pd.DataFrame:
    """Calculate average msrp per ppo and dealer_margin_ppo from raw data.

    Args:
        df_rules_result (pd.DataFrame): dataframe of rules recommended
        df_joined (pd.DataFrame): cleaned ppo data with segment and quartile
        aggregation_level (str): aggregation level
        target_month_min (int): target month min
        param_dict (Dict): parameter dictionary

    Returns:
        pd.DataFrame: dataframe of rules recommended with msrp and margin data added
    """
    # filter to length of history for rules
    month_min, month_max = get_historical_range(
        target_month_min, param_dict["rules_len_historical_months"]
    )
    df_joined_rules = df_joined[
        (df_joined["business_month"] >= month_min)
        & (df_joined["business_month"] <= month_max)
    ].copy(deep=True)
    df_msrp_ppo = df_joined_rules[
        [
            "model_number",
            "dealer_number_latest",
            "accessory_code",
            "business_month",
            "series_name",
            param_dict["cluster_col"],
            "msrp_ppo",
            "dealer_margin_ppo",
            "quantity_retail_ppo",
        ]
    ].drop_duplicates()

    agg_cols = ["series_name", "accessory_code"]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]

    # take weighted mean msrp_ppo and dealer_margin_ppo for each dealer
    df_msrp_ppo = df_msrp_ppo.groupby(
        agg_cols + ["dealer_number_latest"],
        as_index=False,
    ).apply(weighted_average, ["msrp_ppo", "dealer_margin_ppo"], "quantity_retail_ppo")

    # merge into rule result df
    df_rules_result_w_msrp_ppo = pd.merge(df_rules_result, df_msrp_ppo, how="left")
    assert df_rules_result.shape[0] == df_rules_result_w_msrp_ppo.shape[0]

    # fill NAs with average across all dealers
    for col in ["msrp_ppo", "dealer_margin_ppo"]:
        df_rules_result_w_msrp_ppo[col] = df_rules_result_w_msrp_ppo[col].fillna(
            df_rules_result_w_msrp_ppo.groupby(agg_cols)[col].transform("mean"),
        )

    # fill NAs with average across models in same series
    for col in ["msrp_ppo", "dealer_margin_ppo"]:
        df_rules_result_w_msrp_ppo[col] = df_rules_result_w_msrp_ppo[col].fillna(
            df_rules_result_w_msrp_ppo.groupby("accessory_code")[col].transform("mean"),
        )

    # fill NAs in dealer_margin_ppo assuming 35% margin
    df_rules_result_w_msrp_ppo.loc[
        df_rules_result_w_msrp_ppo["dealer_margin_ppo"].isna(), "dealer_margin_ppo"
    ] = (
        df_rules_result_w_msrp_ppo.loc[
            df_rules_result_w_msrp_ppo["dealer_margin_ppo"].isna(), "msrp_ppo"
        ]
        * 0.35
    )

    # no data, fill with 0s
    df_rules_result_w_msrp_ppo["msrp_ppo"] = df_rules_result_w_msrp_ppo[
        "msrp_ppo"
    ].fillna(0)
    df_rules_result_w_msrp_ppo["dealer_margin_ppo"] = df_rules_result_w_msrp_ppo[
        "dealer_margin_ppo"
    ].fillna(0)

    return df_rules_result_w_msrp_ppo


def create_est_alloc_qty_column(
    df: pd.DataFrame, aggregation_level: str, procon_df: pd.DataFrame
) -> pd.DataFrame:
    """

    Compute the following:
        - allocation_ratio (qty_sold / total_qty) sold for all dealers
        - est_alloc_qty = round(allocation_ratio * quantity)
    Args:
        df: series level data
        aggregation_level: 'series' or 'model'
        procon_df: series, model, region, quantity

    Returns:
        pd.DataFrame: aggregated output across series with est_est_alloc_qty column

    """

    def round_est_alloc_qty(data: pd.DataFrame, group: list) -> pd.DataFrame:
        """Helper function to round the est_alloc_qty to whole numbers while maintaining correct sum"""

        data["cumsum"] = data.groupby(group)["est_alloc_qty"].cumsum().round()
        data["cumsum_lag"] = data.groupby(group)["cumsum"].shift(1)
        data.fillna(0, inplace=True)
        data["est_alloc_qty"] = data["cumsum"] - data["cumsum_lag"]
        data.drop(["cumsum", "cumsum_lag"], axis=1, inplace=True)

        return data.copy(deep=True)

    sales_cols = [
        "region_code",
        "series_name",
        "grain",
        "dealer_number_latest",
        "quantity_retail_grain_historical",
    ]
    filter_cols = ["region_code", "series_name", "dealer_number_latest"]
    grouping = ["region_code", "series_name"]
    if aggregation_level in ("model", "grade"):
        filter_cols.append("model_number")
        grouping.append("model_number")
        sales_cols.append("model_number")
    elif aggregation_level != "series":
        logger.exception(f"Invalid aggregation_level: {aggregation_level}")
        raise ValueError("Unrecognized aggregation_level")

    regional_alloc_df = procon_df.groupby(grouping)["quantity"].sum().reset_index()
    regional_alloc_df["region_code"] = (
        regional_alloc_df["region_code"].astype(float).astype("Int64")
    )
    if aggregation_level in ("model", "grade"):
        regional_alloc_df["model_number"] = (
            regional_alloc_df["model_number"].astype(float).astype("Int64")
        )

    sales_df = df[sales_cols]
    sales_df.drop_duplicates(subset=filter_cols, inplace=True)
    sales_df["total_grouping_sales"] = sales_df.groupby(grouping)[
        "quantity_retail_grain_historical"
    ].transform(sum)
    sales_df["num_dealers_in_group"] = sales_df.groupby(grouping)[
        "dealer_number_latest"
    ].transform("count")
    sales_df["allocation_ratio"] = (
        sales_df["quantity_retail_grain_historical"] / sales_df["total_grouping_sales"]
    )
    sales_df = pd.merge(sales_df, regional_alloc_df, on=grouping, how="left")
    sales_df["est_alloc_qty"] = sales_df["allocation_ratio"] * sales_df["quantity"]

    # Handle edge-case of no historical sales but vehicles are allocated
    sales_df["est_alloc_qty"].fillna(
        sales_df["quantity"] / sales_df["num_dealers_in_group"],
        inplace=True,
    )

    sales_df = round_est_alloc_qty(sales_df, grouping)

    results_df = pd.merge(
        df, sales_df[filter_cols + ["est_alloc_qty"]], on=filter_cols, how="left"
    )

    return results_df.copy(deep=True)


def create_impact_columns(
    df_rules_result_final2: pd.DataFrame,
    df_region_dealer_data: pd.DataFrame,
    df_results_dealer: pd.DataFrame,
    df_joined: pd.DataFrame,
    df: pd.DataFrame,
    df_segment_description: pd.DataFrame,
    aggregation_level: str,
    target_month_min: int,
    param_dict: Dict,
) -> pd.DataFrame:
    """Creating impact summary.

    Args:
        df_rules_result_final2 (pd.DataFrame): recommended ppo rules data with_model_sales
        df_region_dealer_data (pd.DataFrame):
        df_results_dealer (pd.DataFrame): dealer level S/A ratio, $PPO/vehicle
        df_joined (pd.DataFrame): historical cleaned ppo data with segment
        df (pd.DataFrame): raw input ppo data
        df_segment_description (pd.DataFrame): segmentation description
        aggregation_level (str): grain
        target_month_min (int): month we generate rules for
        param_dict (Dict): parameter dictionary

    Returns:
        pd.DataFrame: impact summary

    """
    # TODO: Don't call something df_rules_result_final2 - either the original df was final or it wasn't
    # No rules were recommended for the month as no cars were allocated
    if df_rules_result_final2.empty:
        return df_rules_result_final2

    df_rules_result_final2["original_retail_install_rate_historical"] = (
        df_rules_result_final2["quantity_retail_ppo_historical"]
        / df_rules_result_final2["quantity_retail_grain_historical"]
    )

    # # add back messages for debugging
    # no quartile, new grain edge case
    df_rules_result_final2.loc[
        df_rules_result_final2["no_quartile_new_grain"] == "Yes", "edge_case"
    ] = "No quartile new grain"
    # no quartile, existing grain edge case
    df_rules_result_final2.loc[
        df_rules_result_final2["quartile"] == "Grain not enough dealer", "edge_case"
    ] = "Grain not enough dealer"
    # no quartile, new grain edge case
    df_rules_result_final2.loc[
        df_rules_result_final2["no_model_history_quartile_segment"] == "Yes",
        "edge_case",
    ] = "No model history quartile segment"

    # ensure ppo list for grain is static across dealers
    df_rules_result_final2 = add_all_dealer_ppo_combinations(
        df_rules_result_final2, aggregation_level
    )

    # Post-processing on fill NA or set equal to 0 for some columns in impact summary
    df_rules_result_final2 = post_processing_impact_summary(df_rules_result_final2)

    df_rules_result_final2["grain"] = aggregation_level
    if aggregation_level == "series":
        df_rules_result_final2["rule_level"] = df_rules_result_final2["series_name"]
    elif aggregation_level in ("model", "grade"):
        df_rules_result_final2["rule_level"] = df_rules_result_final2["model_number"]

    # add segmentation description
    before_merge_shape = df_rules_result_final2.shape[0]
    df_rules_result_final2 = pd.merge(
        df_rules_result_final2, df_segment_description, how="left"
    )
    assert before_merge_shape == df_rules_result_final2.shape[0]

    # merge in msrp ppo
    # get series-model-dealer-PPO code-business month level data
    df_rules_result_final2 = create_msrp_ppo_and_margin(
        df_rules_result_final2,
        df_joined,
        aggregation_level,
        target_month_min,
        param_dict,
    )

    # add in impact cols
    df_rules_result_final2 = calculate_impact_cols(
        df_rules_result_final2, param_dict["rules_len_historical_months"]
    )

    # merge in latest accessory code description
    df_ppo_description = (
        df.sort_values("business_month", ascending=False)
        .groupby("accessory_code", as_index=False)
        .agg({"accessory_description": "first"})
        .drop_duplicates()
    )
    before_merge_shape = df_rules_result_final2.shape[0]
    df_rules_result_final2 = pd.merge(
        df_rules_result_final2, df_ppo_description, how="left"
    )
    assert before_merge_shape == df_rules_result_final2.shape[0]

    # fill accessory description with No_PPO
    df_rules_result_final2.loc[
        df_rules_result_final2["accessory_code"] == "No_PPO", "accessory_description"
    ] = "No_PPO"

    # merge in spec name
    if aggregation_level in ("model", "grade"):
        df_model_spec_name = df[["model_number", "spec_name"]].drop_duplicates()
        before_merge_shape = df_rules_result_final2.shape[0]
        df_rules_result_final2 = pd.merge(
            df_rules_result_final2, df_model_spec_name, how="left"
        )
        assert before_merge_shape == df_rules_result_final2.shape[0]
        # TODO: add assertion back once DE ensures mi will always have spec_name
        # assert (
        #     df_rules_result_final2[df_rules_result_final2["spec_name"].isna()].shape[0]
        #     == 0
        # )

    #  merge in region code and district code
    before_merge_shape = df_rules_result_final2.shape[0]
    df_rules_result_final2 = pd.merge(
        df_rules_result_final2.drop(
            ["region_code", "district_code"], axis=1, errors="ignore"
        ),
        df_region_dealer_data[
            [
                "dealer_number_latest",
                "region_code",
                "district_code",
                "geo_cd_lat",
                "geo_cd_lon",
                "zip_cd",
                "dlrshp_nm",
                "reg_nm",
            ]
        ].drop_duplicates(),
        how="left",
    )
    assert before_merge_shape == df_rules_result_final2.shape[0]
    assert (
        df_rules_result_final2[
            (df_rules_result_final2["dlrshp_nm"].isna())
            | (df_rules_result_final2["region_code"].isna())
            | (df_rules_result_final2["district_code"].isna())
            | (df_rules_result_final2["reg_nm"].isna())
        ].shape[0]
        == 0
    )

    # merge in dealer level info
    before_merge_shape = df_rules_result_final2.shape[0]
    df_rules_result_final2 = pd.merge(
        df_rules_result_final2, df_results_dealer, how="left"
    )
    assert before_merge_shape == df_rules_result_final2.shape[0]
    assert df_rules_result_final2[df_rules_result_final2["reg_nm"].isna()].shape[0] == 0

    return df_rules_result_final2


def log_estimated_lift(
    df_result_all_series_agg: pd.DataFrame, brand: str
) -> pd.DataFrame:
    """Log estimated lift / baseline for each

    Args:
        df_result_all_series_agg (pd.DataFrame): aggregated lift at month, series, region level

    Returns:
        pd.DataFrame: estimated lift/baseline at month, series level

    """
    bpi_log_estimated_lift_df = df_result_all_series_agg.groupby(
        [
            "business_month",
            "series_name",
        ],
        as_index=False,
    ).agg({"baseline": "sum", "lift": "sum", "quantity_retail_grain_historical": "sum"})

    bpi_log_estimated_lift_df.rename(
        columns={
            "quantity_retail_grain_historical": "quantity_retail_grain_historical_average"
        },
        inplace=True,
    )

    bpi_log_estimated_lift_df["brand"] = brand
    return bpi_log_estimated_lift_df


def reporting_series(
    series: str,
    base_parameters: dict,
    iteration_df: pd.DataFrame,
    mode: str,
    run_version: str,
    data_catalog: dict,
    procon_data_df: pd.DataFrame,
) -> None:
    aggregation_level = base_parameters["aggregation_level"][series]
    brand = base_parameters["brand"]
    logger.info(f"{series} part 4 started")
    target_month_list = iteration_df[iteration_df["series_name"] == series][
        "target_month"
    ].tolist()

    # no rules generated for this series
    if not target_month_list:
        return

    for target_month_min in target_month_list:
        io_dict = {
            "series": series,
            "target_month_min": target_month_min,
            "mode": mode,
            "run_version": run_version,
        }

        ######################################################################################################
        # read data
        ######################################################################################################
        # create impact summary for one month
        df_joined = load_data(
            data_catalog["ppo_historical_with_segments"], param_dict=io_dict
        )
        df_region_dealer_data = load_data(
            data_catalog["region_dealer"], param_dict=io_dict
        )
        df_results_dealer = load_data(
            data_catalog["dealer_results"], param_dict=io_dict
        )

        ppo_historical_df = load_data(
            data_catalog["ppo_historical"], param_dict=io_dict
        )

        df_rules_aggregated = load_data(
            data_catalog["rules_recommendation_dmaa"], param_dict=io_dict
        )

        if (brand == "toyota") or (brand == "lexus"):
            df_segment_description = load_data(
                data_catalog[f"segments_description_{brand}"], param_dict=io_dict
            )
        else:
            logger.exception(
                f"Unknown brand ('{brand}') - unable to locate segment descriptions"
            )
            raise Exception(
                f"Unknown brand ({brand}) - unable to locate segment descriptions"
            )

        # load historical ppo installation data
        df_sale_ppo_historical = load_data(
            data_catalog["historical_ppo_qty"], param_dict=io_dict
        )
        df_sale_grain_historical = load_data(
            data_catalog["historical_grain_qty"], param_dict=io_dict
        )

        ######################################################################################################
        # create impact summary for one back-testing month
        ######################################################################################################
        logger.info(
            f"Adding historical month ppo columns for {series}-{target_month_min}"
        )
        df_rules_result_final_wt_model_sales = add_historical_month_ppo_cols(
            df_rules_aggregated,
            df_sale_ppo_historical,
            df_sale_grain_historical,
            aggregation_level,
            base_parameters,
        )
        logger.info(
            f"Successfully added historical month ppo columns for {series}-{target_month_min}"
        )

        logger.info(f"Creating impact columns for {series}-{target_month_min}")
        df_rules_result_final_wt_model_sales_full_info = create_impact_columns(
            df_rules_result_final_wt_model_sales,
            df_region_dealer_data,
            df_results_dealer,
            df_joined,
            ppo_historical_df,
            df_segment_description,
            aggregation_level,
            target_month_min,
            base_parameters,
        )
        logger.info(
            f"Successfully created impact columns for {series}-{target_month_min}"
        )

        target_month_procon = procon_data_df.loc[
            procon_data_df["getsudo_month"] == str(target_month_min)
        ]

        logger.info(
            f"Creating estimated allocation quantity column for {series}-{target_month_min}"
        )
        df_rules_result_final_wt_model_sales_full_info = create_est_alloc_qty_column(
            df_rules_result_final_wt_model_sales_full_info,
            aggregation_level,
            target_month_procon,
        )
        logger.info(
            f"Successfully created estimated allocation quantity column for {series}-{target_month_min}"
        )

        ######################################################################################################
        # save data
        ######################################################################################################
        save_data(
            data_catalog["rules_recommendation_impact"],
            df_rules_result_final_wt_model_sales_full_info,
            param_dict=io_dict,
        )

    ######################################################################################################
    # Aggregate impact summary for each month for a series
    ######################################################################################################
    # Load all created impact summaries
    df_list = []
    for target_month_min in target_month_list:
        io_dict.update({"target_month_min": target_month_min})
        df_list.append(
            load_data(data_catalog["rules_recommendation_impact"], param_dict=io_dict)
        )

    concatenated_impact_data_df = concatenate_dataframes(df_list)

    ######################################################################################################
    # save data
    ######################################################################################################

    save_data(
        data_catalog["consolidated_impact"],
        concatenated_impact_data_df,
        param_dict=io_dict,
    )

    ######################################################################################################
    # compute consolidate_impact_results
    ######################################################################################################

    logger.info(f"Aggregating impact results for {series}")
    consolidated_impact_results_df = aggregate_impact_results(
        concatenated_impact_data_df, base_parameters
    )
    logger.info(f"Successfully aggregated impact results for {series}")

    ######################################################################################################
    # save data
    ######################################################################################################
    io_dict = {
        "series": series,
        "mode": mode,
        "run_version": run_version,
    }
    save_data(
        data_catalog["consolidated_impact_results"],
        consolidated_impact_results_df,
        param_dict=io_dict,
    )
    logger.info(f"{series} part 4 ended")


@timer_func
def run(base_parameters: Dict, data_catalog: Dict, run_version: str) -> None:
    """Aggregate result for multiple back-testing months for each series and combine lite and maxi.

    Args:
        base_parameters (Dict): parameters for run
        data_catalog (Dict): data catalog
        run_version (str): run version with date and random hash
    """
    logger.info(f"Run version: {run_version}")

    mode = base_parameters["mode"]
    brand = base_parameters["brand"]
    procon_data_df = load_data(data_catalog["procon_data"])
    procon_data_df = procon_data_df.compute()

    # TODO: Remove this lex_toy_ind nonsense and replace with brand
    # TODO: Use universal brand filter
    procon_data_df.rename({"lex_toy_ind": "brand"}, axis=1, inplace=True)
    lex_toy_ind_map = {"L": "lexus", "T": "toyota"}
    procon_data_df["brand"] = procon_data_df["brand"].map(lex_toy_ind_map)
    procon_data_df = procon_data_df.loc[procon_data_df["brand"] == brand]

    procon_data_df = procon_data_df[
        ["model_number", "region_code", "quantity", "series_name", "getsudo_month"]
    ]
    iteration_df = load_data(
        data_catalog["run_dict"],
        param_dict={"run_version": run_version, "brand": brand},
    )
    series_list = iteration_df["series_name"].unique().tolist()

    is_parallel_process = base_parameters["parallel_process"]
    if is_parallel_process:
        with concurrent.futures.ProcessPoolExecutor() as executor:
            futures = []
            for series in series_list:
                futures.append(
                    executor.submit(
                        reporting_series,
                        series,
                        base_parameters,
                        iteration_df,
                        mode,
                        run_version,
                        data_catalog,
                        procon_data_df,
                    )
                )
            wait(futures)
    else:
        for series in series_list:
            reporting_series(
                series,
                base_parameters,
                iteration_df,
                mode,
                run_version,
                data_catalog,
                procon_data_df,
            )

    logger.info(f"all series part 4 started")
    ######################################################################################################
    # Aggregate impact summary for all series in one dataframe
    ######################################################################################################

    # Continue only if series available and recommendations are generated (i.e., something in series_list)
    if series_list:
        (
            df_impact_result_all_series,
            df_impact_result_all_series_filter,
            df_result_all_series_agg,
        ) = aggregate_impact_across_series(series_list, mode, data_catalog, run_version)

        # bpi log: estimated lift
        bpi_log_estimated_lift_df = log_estimated_lift(df_result_all_series_agg, brand)

        ######################################################################################################
        # save data
        ######################################################################################################
        io_dict = {
            "mode": mode,
            "run_version": run_version,
            "brand": brand,
        }
        save_data(
            data_catalog["impact_result_all_series"],
            df_impact_result_all_series,
            param_dict=io_dict,
        )
        save_data(
            data_catalog["impact_result_all_series_filtered_col"],
            df_impact_result_all_series_filter,
            param_dict=io_dict,
        )
        save_data(
            data_catalog["result_all_series_agg"],
            df_result_all_series_agg,
            param_dict=io_dict,
        )
        save_data(
            data_catalog["bpi_log_estimated_lift"],
            bpi_log_estimated_lift_df,
            param_dict=io_dict,
        )
        logger.info(f"all series part 4 ended")
