import pandas
import pandas as pd
import logging
import itertools
from typing import Dict, List, Tuple, Union

from pandas import DataFrame

from src.vmx_ppo.utils.date import get_historical_range
from src.vmx_ppo.utils.io import load_model, load_data, save_data, filter_by_columns
from src.vmx_ppo.utils.timer import timer_func
from dateutil.relativedelta import relativedelta
from datetime import datetime
import dask.dataframe as dd
import concurrent.futures


logger = logging.getLogger("src.vmx_ppo.unconstrained_demand.preprocess")


def log_run_params(param_dict: Dict) -> pd.DataFrame:
    """Log run parameters."""
    param_df = pd.DataFrame.from_dict(
        param_dict, orient="index", columns=["value"]
    ).reset_index()
    param_df.rename(columns={"index": "parameter"}, inplace=True)
    return param_df


def log_dealers_without_segments(
    region_dealer_df: pd.DataFrame,
    segments_df: pd.DataFrame,
    brand: str,
) -> pd.DataFrame:
    dealer_number_latest_ps = region_dealer_df["dealer_number_latest"]
    dealer_code_ps = segments_df["dealer_code"]
    dealers_without_segments_df = (
        dealer_number_latest_ps[~dealer_number_latest_ps.isin(dealer_code_ps)]
        .drop_duplicates()
        .to_frame(name="dealer_number")
    )
    dealers_without_segments_df["brand"] = brand
    return dealers_without_segments_df.copy(deep=True)


def log_new_grain_and_not_allocated_models(
    ppo_historical_df: pd.DataFrame,
    getsudo_current: pd.DataFrame,
    agg_level: str,
    target_month_min: int,
    series: str,
    brand: str,
) -> Union[
    tuple[None, DataFrame, list[tuple[str, int]]],
    tuple[DataFrame, None, list[tuple[str, int]]],
]:
    """Log new models, models not allocated in getsudo and new series.

    Args:
        ppo_historical_df (pd.DataFrame): cleaned & filtered historical ppo sales data
        getsudo_current (pd.DataFrame): cleaned & filtered current month getsudo data
        agg_level (str): either "model" or "series", determines what to check for and log
        target_month_min (int): current month recommendations are being generated for
        series (str): series_name being run
        run_list (List[Tuple[str, int]]): stores (series, month) to generate recommendations for

    Returns:
        pd.DataFrame: either stores new model / models in history or new series
        List[Tuple[str, int]]: stores run_list with
    """
    run_list = []
    # if there are no sales in the historical data, log the series and return
    if ppo_historical_df.empty:
        bpi_log_grain_no_history = pd.DataFrame(
            {
                "series_name": [series],
                "business_month": [target_month_min],
                "log_category": ["series in procon but no history"],
                "brand": [brand],
            }
        )
        return None, bpi_log_grain_no_history, run_list

    # if grain is model level, log new models / models in history but are not allocated in ProCon
    if agg_level in ("model", "grade"):
        getsudo_data = getsudo_current.copy(deep=True)

        historical_model_set = set(ppo_historical_df["model_number"].values)
        get_sudo_set = set(getsudo_data["model_number"].values)

        # get new models
        new_model_list = list(get_sudo_set - historical_model_set)
        # get models not allocated in getsudo
        not_allocated_model_list = list(historical_model_set - get_sudo_set)

        bpi_log_grain_no_rules_df_final = pd.DataFrame()

        # if there are new models
        if len(new_model_list) != 0:
            # get series, model, dealer combo
            cols_to_include_new_model = [
                "series_name",
                "model_number",
                "dealer_number_latest",
            ]
            assert (
                getsudo_data.shape[0]
                == getsudo_data[cols_to_include_new_model].drop_duplicates().shape[0]
            )
            new_model_df = getsudo_data[
                getsudo_data["model_number"].isin(new_model_list)
            ][cols_to_include_new_model]
            # assign business month
            new_model_df["business_month"] = target_month_min
            # assign category
            new_model_df["category"] = "new model in ProCon not in history"
            # assign rules created or not
            new_model_df["rules_created"] = "Yes"
            # append to bpi log
            bpi_log_grain_no_rules_df_final = bpi_log_grain_no_rules_df_final.append(
                new_model_df
            )

        # if there are models not allocated
        if len(not_allocated_model_list) != 0:
            # get series, model combo, no need to know the dealers
            cols_to_include_not_allocated = ["series_name", "model_number"]
            not_allocated_model_df = ppo_historical_df[
                ppo_historical_df["model_number"].isin(not_allocated_model_list)
            ][cols_to_include_not_allocated].drop_duplicates()
            # fill dealer_number_latest as NA
            not_allocated_model_df["dealer_number_latest"] = None
            # assign business month
            not_allocated_model_df["business_month"] = target_month_min
            # assign category
            not_allocated_model_df[
                "category"
            ] = "model in history not allocated in ProCon"
            # fill rules_created as NA, not applicable
            not_allocated_model_df["rules_created"] = None
            # append to bpi log
            bpi_log_grain_no_rules_df_final = bpi_log_grain_no_rules_df_final.append(
                not_allocated_model_df
            )
    else:
        bpi_log_grain_no_rules_df_final = pd.DataFrame()

    run_list.append((series, target_month_min))
    bpi_log_grain_no_rules_df_final["brand"] = brand
    return bpi_log_grain_no_rules_df_final, None, run_list


def log_new_series(
    procon_df: pd.DataFrame,
    series_in_mi: List[str],
    series_to_run: List[str],
    months_to_run: List[int],
    brand: str,
    other_brand_series_list: List[str],
) -> Tuple[pd.DataFrame, List[Tuple[str, int]]]:
    """Log new series, series not run and series run with no procon and return run list after including allocation.

    Args:
        procon_df (pd.DataFrame): procon data
        series_in_mi (List[str]): list of series in mi (only if extract_parquet = True)
        series_to_run (List[str]): list of series to run
        months_to_run (List[int]): list of months to run

    Returns:
        pd.DataFrame: dataframe of series to log
        List[Tuple[str, int]]: list of (series, month) to run the recommendations for
    """
    # Get lists of series
    series_in_procon = procon_df["series_name"].unique().tolist()

    run_iter = itertools.product(series_to_run, months_to_run)
    run_iter_list = [x for x in run_iter]
    procon_iter = list(
        procon_df[["series_name", "business_month"]].itertuples(index=False, name=None)
    )

    # Series run, but no procon
    series_run_no_procon = list(set(run_iter_list) - set(procon_iter))

    # Concatenate into df to return
    new_series_log_df = pd.DataFrame(
        series_run_no_procon, columns=["series_name", "business_month"]
    )
    new_series_log_df["log_type"] = "series run with no procon (no recommendations)"

    if series_in_mi:
        # Series with procon but not in model input
        new_series_no_history_list = list(set(series_in_procon) - set(series_in_mi))
        # Series in procon AND model input but not run
        series_in_procon_and_mi = list(set(series_in_procon) & set(series_in_mi))
        series_not_run_list = list(
            set(series_in_procon_and_mi)
            - set(series_to_run)
            - set(other_brand_series_list)
        )
        new_series_log_df = new_series_log_df.append(
            pd.DataFrame(
                {
                    "series_name": new_series_no_history_list,
                    "log_type": "series in procon but not in model input",
                }
            )
        )
        new_series_log_df = new_series_log_df.append(
            pd.DataFrame(
                {
                    "series_name": series_not_run_list,
                    "log_type": "series in procon and model input but not run",
                }
            )
        )
    new_series_log_df["brand"] = brand

    # only run (series, month) combinations in parameters with procon
    to_run_list = list(set(run_iter_list) & set(procon_iter))
    to_run_list.sort()
    return new_series_log_df, to_run_list


def extract_ppo_data(series_df: pd.DataFrame):
    """Filter dataframe based on non-zero quantities.
    Args:
        series_df (pd.DataFrame): raw ppo data for one series
    Returns:
        pd.DataFrame: filtered ppo data
    """
    return series_df[
        (series_df["availability_ppo_list"] != 0)
        | (series_df["quantity_retail_ppo_list"] != 0)
        | (series_df["quantity_wholesales_ppo_list"] != 0)
    ].copy()


def prepare_procon_data(
    procon_data_df: dd.core.DataFrame, target_month_list: List[str]
) -> pd.DataFrame:
    """Prepare procon data for use.

    Args:
        procon_data_df (dd.core.DataFrame): procon data loaded into dask
        target_month_list (List[str]): list of months to run

    Returns:
        pd.DataFrame: cleaned procon data
    """
    # convert to pandas for joins later
    procon_data_df = procon_data_df.compute()

    # Add 1 month to business_month as procon business month is 1 month before production month
    # i.e. procon data for Jan 2022 is for production, allocation & recommendation in Feb 2022
    procon_data_df["business_month"] = procon_data_df["getsudo_month"].apply(
        lambda x: (
            datetime.strptime(str(x), "%Y%m").date() + relativedelta(months=1)
        ).strftime("%Y%m")
    )

    # type conversions
    procon_data_df[["region_code", "business_month", "model_number"]] = procon_data_df[
        ["region_code", "business_month", "model_number"]
    ].apply(pd.to_numeric, axis=1)

    return procon_data_df[
        (procon_data_df["business_month"].isin(target_month_list))
        & (~procon_data_df["series_name"].isna())
    ].copy()


def prepare_ppo_data(
    ppo_df: pd.DataFrame,
    segment_df: pd.DataFrame,
    filter_start_date: int,
    filter_end_date: int,
    series_name: str,
) -> pd.DataFrame:
    """
    Preprocess ppo data by merging segments, filtering by date and removing negative sales & availability values.

    Args:
        ppo_df (pd.DataFrame): raw ppo data
        segment_df (pd.DataFrame): segment data
        filter_start_date (int): start date to filter data by
        filter_end_date (int): end date to filter data by
        series_name (str): name of series

    Returns:
        pd.DataFrame: cleaned ppo data
    """
    # filter dates and remove negative sales and availability values
    clean_ppo_df = clean_ppo_data(ppo_df, filter_start_date, filter_end_date)

    clean_ppo_with_segments_df = pd.merge(
        clean_ppo_df,
        segment_df,
        left_on="dealer_number_latest",
        right_on="dealer_code",
        how="inner",
    )
    # Replace null accessory_code with No_PPO to avoid records being dropped
    clean_ppo_with_segments_df.loc[
        clean_ppo_with_segments_df["accessory_code"].isna(),
        "accessory_code",
    ] = "No_PPO"
    # Replace null ppo expanded_ppo_list with No_PPO to avoid records being dropped
    clean_ppo_with_segments_df.loc[
        clean_ppo_with_segments_df["expanded_ppo_list"].isna(),
        "expanded_ppo_list",
    ] = "No_PPO"
    # Add series name into df
    clean_ppo_with_segments_df["series_name"] = series_name

    subset_cols_list = [
        "region_code",
        "district_code",
        "label",
        "dealer_number_latest",
        "series_name",
        "model_number",
        "expanded_ppo_list",
        "accessory_code",
        "business_month",
        "quantity_retail_model",
        "availability_model",
        "velocity_model",
        "sa_ratio_model",
        "quantity_retail_ppo_list",
        "availability_ppo_list",
        "msrp_ppo_list",
        "velocity_ppo_list",
        "sa_ratio_ppo_list",
        "quantity_retail_ppo",
        "availability_ppo",
        "msrp_ppo",
        "velocity_ppo",
        "sa_ratio_ppo",
        "geo_cd_lat",
        "geo_cd_lon",
        "zip_cd",
        "dlrshp_nm",
        "reg_nm",
        "dealer_margin",
        "grade",
    ]
    clean_ppo_final_df = filter_by_columns(clean_ppo_with_segments_df, subset_cols_list)
    clean_ppo_final_df.rename(
        {"dealer_margin": "dealer_margin_ppo"}, axis=1, inplace=True
    )
    return clean_ppo_final_df


def clean_ppo_data(df: pd.DataFrame, month_min: int, month_max: int):
    """Filter data by date and remove negative sales and availability values.

    Args:
        df (pd.DataFrame): raw dataframe
        month_min (int): start date to filter data by
        month_max (int): end date to filter data by

    Returns:
        pd.DataFrame: filtered dataframe
    """
    # filter data to time range
    df = df[(df["business_month"] >= month_min) & (df["business_month"] <= month_max)]
    logger.info(
        f"Filtering data from {df.business_month.min()} to {df.business_month.max()}"
    )

    # remove sales quantity or availability that are negative
    filtered_df = df[
        (df["quantity_retail_ppo_list"] >= 0)
        & (df["availability_ppo_list"] >= 0)
        & (df["quantity_retail_ppo"] >= 0)
        & (df["availability_ppo"] >= 0)
        & (df["quantity_retail_model"] >= 0)
        & (df["availability_model"] >= 0)
    ].copy()

    if df.shape[0] != 0:
        perc_negative = (df.shape[0] - filtered_df.shape[0]) / df.shape[0]
        logger.info(f"{perc_negative*100:.2f}% sales or availability are negative")

    return filtered_df


def extract_region_dealer_data(ppo_raw_df: pd.DataFrame) -> pd.DataFrame:
    """Extract region and dealer data for rule recommendation and reporting.

    Args:
        ppo_raw_df (pd.DataFrame): raw ppo data

    Returns:
        pd.DataFrame: region, district and dealer data, including names, zipcodes and lat/lon
    """
    ppo_raw_df = ppo_raw_df.astype({"dealer_number_latest": int, "region_code": int})

    return ppo_raw_df[
        [
            "dealer_number_latest",
            "region_code",
            "reg_nm",
            "district_code",
            "geo_cd_lat",
            "geo_cd_lon",
            "zip_cd",
            "dlrshp_nm",
            "lex_toy_ind",
        ]
    ].drop_duplicates()


def get_getsudo_data(
    procon_df: pd.DataFrame,
    target_month: int,
    series_name: str,
    region_dealer_df: pd.DataFrame,
    segments_df: pd.DataFrame,
    aggregation_level: str,
) -> pd.DataFrame:
    """Get getsudo data: region-grain combinations for current month.

    Args:
        procon_df (pd.DataFrame): procon data for current month
        target_month (int): target month to extract procon data for
        series_name (str): series name
        region_dealer_df (pd.DataFrame): region-dealer data mapping each dealer to their region
        segments_df (pd.DataFrame): segment-dealer data from segmentation model
        aggregation_level (str): aggregation level determining grain to get getsudo data for

    Returns:
        pd.DataFrame: getsudo data
    """
    agg_columns = ["region_code", "business_month", "series_name"]
    if aggregation_level in ("model", "grade"):
        agg_columns += ["model_number"]

    # get region-grain combinations for current month & series
    region_grain_df = (
        procon_df.loc[
            (procon_df["business_month"] == target_month)
            & (procon_df["series_name"] == series_name),
            agg_columns,
        ]
        .drop_duplicates()
        .copy()
    )

    # get region-dealer combinations and segments
    region_dealer_df = region_dealer_df[
        ["region_code", "dealer_number_latest"]
    ].drop_duplicates()
    getsudo_df = pd.merge(
        region_grain_df, region_dealer_df, on="region_code", how="left"
    )
    getsudo_df_with_segments = pd.merge(
        getsudo_df,
        segments_df,
        left_on="dealer_number_latest",
        right_on="dealer_code",
        how="left",
    ).drop("dealer_code", axis=1)

    return getsudo_df_with_segments


def update_segments_with_dealer_number_changes(
    segments_df: pd.DataFrame, dealer_code_changes: pd.DataFrame
):
    dealer_code_changes = dealer_code_changes[
        ["dealer_number_latest", "dealer_number_previous"]
    ]

    dealer_code_changes = dealer_code_changes.astype(int)

    # Replace segments_df dealer_number_latest with new dealer_number_latest from dealer_code_changes
    valid_dealer_code_changes = dealer_code_changes[
        dealer_code_changes["dealer_number_previous"].isin(segments_df["dealer_code"])
    ]

    dealer_mapping_dict = dict(
        zip(
            valid_dealer_code_changes["dealer_number_previous"],
            valid_dealer_code_changes["dealer_number_latest"],
        )
    )

    segments_df.replace({"dealer_code": dealer_mapping_dict}, inplace=True)

    return segments_df.copy(deep=True)


def append_segments_with_new_dealer_segments(
    segments_df: pd.DataFrame, new_dealer_segments: pd.DataFrame
):
    new_dealer_numbers_and_labels = new_dealer_segments[
        ["dealer_number_latest", "dealer_number_near_label"]
    ].rename(
        columns={
            "dealer_number_latest": "dealer_code",
            "dealer_number_near_label": "label",
        }
    )

    new_dealer_numbers_and_labels = new_dealer_numbers_and_labels.astype(int)

    is_new_dealer_already_existing = (
        segments_df["dealer_code"]
        .isin(new_dealer_numbers_and_labels["dealer_code"])
        .any()
        .any()
    )

    if is_new_dealer_already_existing:
        is_error_appending_new_dealer = True
        logger.warning("At least one 'new dealer' already exists!")
        return segments_df.copy(deep=True), is_error_appending_new_dealer
    else:
        is_error_appending_new_dealer = False
        segments_df = segments_df.append(
            new_dealer_numbers_and_labels, ignore_index=True
        )
        return segments_df.copy(deep=True), is_error_appending_new_dealer


def preprocess_series_month(
    series: str,
    target_month_min: int,
    io_dict: dict,
    parameters: dict,
    historical_range_months: int,
    data_catalog: dict,
    run_version: str,
    region_dealer_df: pd.DataFrame,
    segments_df: pd.DataFrame,
    procon_cleaned_df: pd.DataFrame,
) -> list:
    # get run params
    agg_level = parameters["aggregation_level"][series]
    brand = parameters["brand"]
    historical_month_min, historical_month_max = get_historical_range(
        target_month_min, historical_range_months
    )
    io_dict["series"] = series
    io_dict["target_month_min"] = target_month_min

    logger.info(f"{series} {target_month_min} part 1 started")

    ######################################################################################################
    # Read data
    ######################################################################################################
    # ppo_historical_df is in region-dealer-series-model-ppo-month level
    # segments_df is at dealer level
    ppo_historical_df = load_data(data_catalog["ppo_historical"], param_dict=io_dict)
    ######################################################################################################
    # Preprocess base historical data
    ######################################################################################################

    logger.info(f"Preparing PPO data for {series} {target_month_min}")
    # filter, clean and merge with segments
    ppo_clean_historical = prepare_ppo_data(
        ppo_historical_df,
        segments_df,
        historical_month_min,
        historical_month_max,
        series,
    )
    logger.info(f"Successfully prepared PPO data for {series} {target_month_min}")

    ######################################################################################################
    # Save data
    ######################################################################################################
    save_data(
        data_catalog["ppo_historical_with_segments"],
        ppo_clean_historical,
        param_dict=io_dict,
    )

    ######################################################################################################
    # Preprocess base allocation data (new month)
    ######################################################################################################

    logger.info(f"Getting getsudo data for {series} {target_month_min}")
    getsudo_current = get_getsudo_data(
        procon_cleaned_df,
        target_month_min,
        series,
        region_dealer_df,
        segments_df,
        agg_level,
    )
    logger.info(f"Successfully got getsudo data for {series} {target_month_min}")

    ######################################################################################################
    # Save data
    ######################################################################################################
    save_data(
        data_catalog["getsudo_new_month"],
        getsudo_current,
        param_dict=io_dict,
    )

    ######################################################################################################
    # BPI - log new models, model not allocated and new series (no history)
    ######################################################################################################

    (
        bpi_log_grain_no_rules_df_final,
        bpi_log_grain_no_history,
        run_list,
    ) = log_new_grain_and_not_allocated_models(
        ppo_clean_historical,
        getsudo_current,
        agg_level,
        target_month_min,
        series,
        brand,
    )
    if (
        bpi_log_grain_no_rules_df_final is not None
        and not bpi_log_grain_no_rules_df_final.empty
    ):
        save_data(
            data_catalog["bpi_log_grain_no_rules"],
            bpi_log_grain_no_rules_df_final,
            param_dict={
                "run_version": run_version,
                "brand": brand,
            },
            mode="a",
            header=False,
        )
    if bpi_log_grain_no_history is not None:
        io_dict["brand"] = brand
        save_data(
            data_catalog["bpi_log_new_series"],
            bpi_log_grain_no_history,
            param_dict=io_dict,
            mode="a",
            header=False,
        )
    return run_list


@timer_func
def run(parameters: Dict, data_catalog: Dict, run_version: str) -> None:
    """.
    Preprocessing data for modeling: filter, clean and merge with segments.

    Args:
        parameters (Dict): parameters for run
        data_catalog (Dict): data catalog
        run_version (str): run version for file path
    """
    logger.info(f"Run version: {run_version}")

    logger.info("Logging run parameters")

    brand = parameters["brand"]

    io_dict = {
        "run_version": run_version,
        "brand": brand,
    }

    run_param_df = log_run_params(parameters)
    save_data(data_catalog["bpi_log_run_parameters"], run_param_df, param_dict=io_dict)

    # create empty bpi log for grain no rules to clean the log in current directory
    save_data(
        data_catalog["bpi_log_grain_no_rules"],
        pd.DataFrame(
            columns=[
                "series_name",
                "model_number",
                "dealer_number_latest",
                "business_month",
                "category",
                "rules_created",
                "brand",
            ]
        ),
        param_dict=io_dict,
    )

    is_parallel_process = parameters["parallel_process"]
    if brand == "toyota":
        series_list = parameters["toyota_series"]
        other_brand_series_list = parameters["lexus_series"]
    elif brand == "lexus":
        series_list = parameters["lexus_series"]
        other_brand_series_list = parameters["toyota_series"]
    else:
        logger.exception(f"Unknown brand ('{brand}')")
        raise Exception(f"Unknown brand ('{brand}')")
    extract_parquet = parameters["extract_parquet"]
    mode = parameters["mode"]
    target_month_list = parameters["target_month_min"]
    q4_booster = parameters["q4_booster"]
    q1_reducer = parameters["q1_reducer"]

    if extract_parquet:
        logger.info("Extracting series data from parquet")
        ppo_raw_df = load_data(data_catalog["ppo_raw"], {"series": "*"})

        logger.info("Extracting region dealer data")
        try:
            # Extract region-dealer data
            region_dealer_df = extract_region_dealer_data(ppo_raw_df)
            save_data(data_catalog["region_dealer"], region_dealer_df)
        except Exception as e:
            logger.exception(f"Failed to extract region dealer data.\n{e}")
        logger.info("Successfully extracted region dealer data")

        series_in_mi = ppo_raw_df["series_name"].unique().compute()
        series_in_mi = series_in_mi.values.tolist()

        # Extract data for series required
        # TODO: Remove once DE filters out 0s in availability_ppo_list, quantity_retail_ppo_list and quantity_wholesales_ppo_list
        for series in series_list:
            ppo_raw_df = load_data(data_catalog["ppo_raw"], {"series": series})
            ppo_raw_series = extract_ppo_data(ppo_raw_df)
            save_data(
                data_catalog["ppo_historical"], ppo_raw_series, {"series": series}
            )
    else:
        series_in_mi = None

    # TODO: Create function to filter brands and apply it universally
    region_dealer_df = load_data(data_catalog["region_dealer"])
    # TODO: Remove this lex_toy_ind nonsense and replace with brand
    # Filter region_dealer data for specific brand set in parameter
    # TODO: Apply brand filter function
    region_dealer_df.rename({"lex_toy_ind": "brand"}, axis=1, inplace=True)
    lex_toy_ind_map = {"L": "lexus", "T": "toyota"}
    region_dealer_df["brand"] = region_dealer_df["brand"].map(lex_toy_ind_map)
    region_dealer_df = region_dealer_df.loc[region_dealer_df["brand"] == brand]

    if brand == "toyota" or brand == "lexus":
        segments_df = load_data(data_catalog[f"segments_{brand}"])
    else:
        logger.exception(f"Unknown brand: '{brand}'")
        raise Exception(f"Unknown brand: '{brand}'")

    dealer_mappings = load_data(
        data_catalog["segment_model_dealer_mapping"], param_dict=io_dict
    )
    # TODO: Remove this lex_toy_ind nonsense and replace with brand
    # Filter dealer_mappings data for specific brand set in parameter
    # TODO: Apply brand filter function
    dealer_mappings.rename({"lex_toy_ind": "brand"}, axis=1, inplace=True)
    lex_toy_ind_map = {"L": "lexus", "T": "toyota"}
    dealer_mappings["brand"] = dealer_mappings["brand"].map(lex_toy_ind_map)
    dealer_mappings = dealer_mappings.loc[dealer_mappings["brand"] == brand]

    dealer_code_changes = dealer_mappings.loc[
        dealer_mappings["Code"] == "Dealer Code Change"
    ]
    new_dealer_segments = dealer_mappings.loc[dealer_mappings["Code"] == "New Dealer"]

    # TODO: New dealers and dealer code changes logic can be modularized
    # TODO: There are many if/then bubbles for creating empty BPI log files so that DE can assume that all files will be present for both Lexus and Toyota. This is because previously we would only create files that were non-empty, but then this caused an inconvenience for DE when merging Toyota and Lexus BPI logs together. Instead of the convoluted if/then logic we should create empty files and fill them as needed.
    if not dealer_code_changes.empty:
        segments_df = update_segments_with_dealer_number_changes(
            segments_df, dealer_code_changes
        )
        save_data(
            data_catalog["bpi_log_dealer_code_changes"],
            dealer_code_changes,
            param_dict={
                "run_version": run_version,
                "brand": brand,
            },
        )
    else:
        save_data(
            data_catalog["bpi_log_dealer_code_changes"],
            pd.DataFrame(columns=list(dealer_code_changes.columns.values)),
            param_dict={
                "run_version": run_version,
                "brand": brand,
            },
        )
    if not new_dealer_segments.empty:
        (
            segments_df,
            is_error_appending_new_dealer,
        ) = append_segments_with_new_dealer_segments(segments_df, new_dealer_segments)
        if is_error_appending_new_dealer:
            save_data(
                data_catalog["bpi_log_erroneous_new_dealer_assigned_to_segments"],
                new_dealer_segments,
                param_dict={
                    "run_version": run_version,
                    "brand": brand,
                },
            )
            save_data(
                data_catalog["bpi_log_new_dealers_assigned_to_segments"],
                pd.DataFrame(columns=list(new_dealer_segments.columns.values)),
                param_dict={
                    "run_version": run_version,
                    "brand": brand,
                },
            )
        else:
            save_data(
                data_catalog["bpi_log_erroneous_new_dealer_assigned_to_segments"],
                pd.DataFrame(columns=list(new_dealer_segments.columns.values)),
                param_dict={
                    "run_version": run_version,
                    "brand": brand,
                },
            )
            save_data(
                data_catalog["bpi_log_new_dealers_assigned_to_segments"],
                new_dealer_segments,
                param_dict={
                    "run_version": run_version,
                    "brand": brand,
                },
            )
    else:
        save_data(
            data_catalog["bpi_log_erroneous_new_dealer_assigned_to_segments"],
            pd.DataFrame(columns=list(new_dealer_segments.columns.values)),
            param_dict={
                "run_version": run_version,
                "brand": brand,
            },
        )
        save_data(
            data_catalog["bpi_log_new_dealers_assigned_to_segments"],
            pd.DataFrame(columns=list(new_dealer_segments.columns.values)),
            param_dict={
                "run_version": run_version,
                "brand": brand,
            },
        )

    if not dealer_code_changes.empty or not new_dealer_segments.empty:
        # Save segmentation changes due to dealer code changes or new dealers added
        if brand == "toyota":
            save_data(
                data_catalog["segments_toyota"],
                segments_df,
                param_dict={
                    "run_version": run_version,
                },
            )
        elif brand == "lexus":
            save_data(
                data_catalog["segments_lexus"],
                segments_df,
                param_dict={
                    "run_version": run_version,
                },
            )
        else:
            logger.exception(f"Unknown brand (`{brand}`)")
            raise Exception(f"Unknown brand (`{brand}`)")

    # Log any leftover dealers within region data that doesn't have a segment
    dealers_without_segments_df = log_dealers_without_segments(
        region_dealer_df, segments_df, brand
    )
    save_data(
        data_catalog["bpi_log_dealers_without_segments"],
        dealers_without_segments_df,
        param_dict={
            "run_version": run_version,
            "brand": brand,
        },
    )

    procon_data_df = load_data(data_catalog["procon_data"])
    procon_cleaned_df = prepare_procon_data(procon_data_df, target_month_list)

    # TODO: Remove this lex_toy_ind nonsense and replace with brand
    procon_cleaned_df.rename({"lex_toy_ind": "brand"}, axis=1, inplace=True)
    # TODO: Apply brand filter function
    lex_toy_ind_map = {"L": "lexus", "T": "toyota"}
    procon_cleaned_df["brand"] = procon_cleaned_df["brand"].map(lex_toy_ind_map)
    procon_cleaned_df = procon_cleaned_df.loc[procon_cleaned_df["brand"] == brand]

    # check for new series & write to bpi log
    new_series_df, iteration_list = log_new_series(
        procon_cleaned_df,
        series_in_mi,
        series_list,
        target_month_list,
        brand,
        other_brand_series_list,
    )
    save_data(data_catalog["bpi_log_new_series"], new_series_df, param_dict=io_dict)

    # pick max of length of historical month for rules and correlation as the length of history to generate
    historical_range_months = max(
        parameters["rules_len_historical_months"],
        parameters["correlation"]["correlation_len_historical_months"],
    )

    logger.info(
        f"Running mode: {mode}, target_months: {target_month_list}, series: {series_list}, booster: {q4_booster:.2f}, reducer: {q1_reducer:.2f}"
    )
    io_dict["mode"] = mode
    run_list = []
    if is_parallel_process:
        with concurrent.futures.ProcessPoolExecutor() as executor:
            futures = []
            for series, target_month_min in iteration_list:
                futures.append(
                    executor.submit(
                        preprocess_series_month,
                        series,
                        target_month_min,
                        io_dict.copy(),
                        parameters,
                        historical_range_months,
                        data_catalog,
                        run_version,
                        region_dealer_df,
                        segments_df,
                        procon_cleaned_df,
                    )
                )
            for future in futures:
                run_list += future.result()
    else:
        for series, target_month_min in iteration_list:
            run_list += preprocess_series_month(
                series,
                target_month_min,
                io_dict.copy(),
                parameters,
                historical_range_months,
                data_catalog,
                run_version,
                region_dealer_df,
                segments_df,
                procon_cleaned_df,
            )
    io_dict["brand"] = brand
    save_data(
        data_catalog["run_dict"],
        pd.DataFrame(run_list, columns=["series_name", "target_month"]),
        param_dict=io_dict,
    )
