from src.vmx_ppo.config.argument_parser import ArgumentParser
from src.vmx_ppo.config.config_parser import ConfigParser
import src.vmx_ppo.unconstrained_demand.preprocess as preprocess
import src.vmx_ppo.unconstrained_demand.modeling as modeling
import src.vmx_ppo.unconstrained_demand.recommendation as recommendation
import src.vmx_ppo.unconstrained_demand.reporting as reporting
import logging


def main():
    args = ArgumentParser()
    cfg = ConfigParser(env=env)

    # import parameters and catalog
    parameters = cfg.parameters
    catalog = cfg.catalog
    credentials = cfg.credentials

    data_catalog = catalog["unconstrained_demand"]
    params = parameters["unconstrained_demand"]

    params.update(
        {
            "brand": args.brand,
            "target_month_min": args.month,
            "run_version": args.version,
        }
    )

    if args.booster is not None:
        params["q4_booster"] = args.booster

    if args.reducer is not None:
        params["q1_reducer"] = args.reducer

    if "preprocess" in nodes:
        logging.info("Running unconstrained_demand.preprocess node")
        preprocess.run(params, data_catalog, run_version)
    if "modeling" in nodes:
        logging.info("Running unconstrained_demand.modeling node")
        modeling.run(params, data_catalog, run_version)
    if "recommendation" in nodes:
        logging.info("Running unconstrained_demand.recommendation node")
        recommendation.run(params, data_catalog, run_version)
    if "reporting" in nodes:
        logging.info("Running unconstrained_demand.reporting node")
        reporting.run(params, data_catalog, run_version)


if "__main__" in __name__:
    main()
