import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import datetime
from dateutil import relativedelta
import concurrent.futures
from concurrent.futures import wait
import dask.dataframe as dd

from src.vmx_ppo.utils.date import get_historical_range
from src.vmx_ppo.utils.timer import timer_func
from statsmodels.stats.weightstats import DescrStatsW
import logging
from typing import Tuple, Dict, List
from src.vmx_ppo.utils.io import load_data, save_data, plot_save_figure


logger = logging.getLogger("src.vmx_ppo.unconstrained_demand.modeling")

INSUFFICIENT_GRAIN_DEALERS = "Grain not enough dealers"


def calculate_weights(
    current_date: datetime.datetime,
    end_of_business_month: datetime.datetime,
    steepness: int,
    clip: int,
) -> float:
    """Calculate the weight for a given date based on the end date, steepness and clip values.

    Args:
        current_date (datetime.datetime): current business month
        end_of_business_month (datetime.datetime): most recent business month considered
        steepness (int): steepness of the weight function
        clip (int): midpoint of the weight function

    Returns:
        float: weight based on logistic function
    """
    # assign weights based on data recency
    # Get the difference in months between two dates
    diff = relativedelta.relativedelta(end_of_business_month, current_date)
    diff_in_months = (diff.months + diff.years * 12) + 1

    # logistic function
    return 1 / (1 + np.exp(-steepness * (clip - diff_in_months)))


def categorize_corr(corr: float, param_dict: Dict) -> str:
    """function to categorize correlation as Positive/Negative/None

    Args:
        corr (float): correlation value
        param_dict (Dict): run parameters

    Returns:
        category (str): Positive/Negative/None
    """
    if corr >= param_dict["correlation"]["positive_corr_threshold"]:
        return "Positive"
    elif corr <= param_dict["correlation"]["negative_corr_threshold"]:
        return "Negative"
    else:
        return "None"


def calculate_dealer_level_sum(
    df_dealer_final: pd.DataFrame,
    aggregation_level: str,
    target_month_min: int,
    param_dict: Dict,
) -> pd.DataFrame:
    """Calculate s/a ratio and PPO PNVW at dealer-grain level across months

    Args:
        df_dealer_final (pd.DataFrame): input dataframe with features created at dealer-grain-month level
        aggregation_level (str): grain
        target_month_min (int): month we create recommendation for
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: cluster-dealer-grain level S/A and PPO PNVW
    """
    # filter to length of history for rules
    month_min, month_max = get_historical_range(
        target_month_min, param_dict["rules_len_historical_months"]
    )
    df_dealer_final_rules = df_dealer_final[
        (df_dealer_final["business_month"] >= month_min)
        & (df_dealer_final["business_month"] <= month_max)
    ].copy(deep=True)

    agg_cols = ["series_name", param_dict["cluster_col"], "dealer_number_latest"]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]
    # get total sales and availablity at dealer level (sum up the months)
    df_dealer_sum = df_dealer_final_rules.groupby(agg_cols, as_index=False).agg(
        {"quantity_retail_dealer_mth": "sum", "availability_dealer_mth": "sum"}
    )
    df_dealer_sum.rename(
        columns={
            "quantity_retail_dealer_mth": "quantity_retail_dealer",
            "availability_dealer_mth": "availability_dealer_weights",
        },
        inplace=True,
    )
    df_dealer_sum["sa_ratio_dealer_weighted"] = (
        df_dealer_sum["quantity_retail_dealer"]
        / df_dealer_sum["availability_dealer_weights"]
    )

    # When sales are nonzero but availability is zero the ratio is infinite;
    # we want to cap the S/A ratio to be 1 in these cases
    df_dealer_sum["sa_ratio_dealer_weighted"].replace(np.inf, 1, inplace=True)

    df_dealer_final_quartile = pd.merge(
        df_dealer_final_rules, df_dealer_sum, how="left"
    )

    # take average across months for each dealer, weighted by volume in the month
    # PPO MSRP
    df_dealer_final_quartile["msrp_ppo_list_dealer"] = (
        df_dealer_final_quartile["msrp_ppo_list_dealer_mth"]
        * df_dealer_final_quartile["quantity_retail_dealer_mth"]
        / df_dealer_final_quartile["quantity_retail_dealer"]
    )

    # check msrp that are NA (sales at model-month and model level are both zero)
    # will not affect final weighted msrp
    logger.info(
        "msrp_ppo_list_dealer is NA:"
        f"{df_dealer_final_quartile[df_dealer_final_quartile['msrp_ppo_list_dealer'].isna()].shape} rows"
    )

    # we only take ppo_list with sales into consideration when
    # calculating average msrp_ppo_list for each month
    df_dealer_final_quartile = df_dealer_final_quartile.groupby(
        agg_cols,
        as_index=False,
    ).agg(
        {
            "msrp_ppo_list_dealer": "sum",
            "sa_ratio_dealer_weighted": "mean",
            "quantity_retail_dealer": "mean",
        }
    )

    return df_dealer_final_quartile


def plot_quartile_distribution(
    df_plotter: pd.DataFrame, bin_labels: List, param_dict: Dict, aggregation_level: str
) -> None:
    """
    Plot the distribution of PPO $ / vehicle and S/A by quartile

    Args:
        df_plotter (pd.DataFrame): dataframe with quartile, PPO PNVW, S/A info
        bin_labels (List): label for quartiles
        param_dict (Dict): run parameters
        aggregation_level (str): grain

    """
    for quartile in bin_labels:
        df_plotter_ss = df_plotter[df_plotter["quartile"] == quartile]
        bins = np.arange(0, 3000 + 250, 250)
        if aggregation_level == "series":
            t_grain = df_plotter_ss.iloc[0]["series_name"]
        elif aggregation_level in ("grade", "model"):
            t_grain = df_plotter_ss.iloc[0]["model_number"]
        t_cluster = df_plotter_ss.iloc[0][param_dict["cluster_col"]]
        avg_ppo = round(df_plotter_ss.msrp_ppo_list_dealer.mean(), 2)
        med_ppo = round(df_plotter_ss.msrp_ppo_list_dealer.median(), 2)
        plt.hist(df_plotter_ss.msrp_ppo_list_dealer, bins=bins)
        plt.title(
            f"Model: {t_grain} | Cluster: {t_cluster} | Quartile: {quartile} \n Avg PPO \${avg_ppo}, Median PPO \${med_ppo}"
        )
        plt.show()

    for quartile in bin_labels:
        df_plotter_ss = df_plotter[df_plotter["quartile"] == quartile]
        bins = np.arange(0, 1 + 0.1, 0.1)
        if aggregation_level == "series":
            t_grain = df_plotter_ss.iloc[0]["series_name"]
        elif aggregation_level in ("grade", "model"):
            t_grain = df_plotter_ss.iloc[0]["model_number"]
        t_cluster = df_plotter_ss.iloc[0][param_dict["cluster_col"]]
        avg_sa = round(df_plotter_ss.sa_ratio_dealer_weighted.mean(), 2)
        med_sa = round(df_plotter_ss.sa_ratio_dealer_weighted.median(), 2)
        plt.hist(df_plotter_ss.sa_ratio_dealer_weighted, bins=bins)
        plt.title(
            f"Model: {t_grain} | Cluster: {t_cluster} | Quartile: {quartile} \n Avg S/A ratio{avg_sa}, Median S/A ratio{med_sa}"
        )
        plt.show()

    return None


def assign_quartile(
    df_dealer_final_quartile: pd.DataFrame, aggregation_level: str, param_dict: Dict
) -> pd.DataFrame:
    """create dealer quartiles for each grain within each segment

    Args:
        df_dealer_final_quartile (pd.DataFrame): cluster-dealer-grain level s/a and PPO PNVW
        aggregation_level (str): grain
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: quartile assigned to dealer at cluster-grain level
    """
    quartiles_dealer_list = list()
    if aggregation_level == "series":
        agg_var = "series_name"
    elif aggregation_level in ("model", "grade"):
        agg_var = "model_number"

    # loop through each cluster
    for cluster in df_dealer_final_quartile[param_dict["cluster_col"]].unique():
        df_cluster = df_dealer_final_quartile[
            df_dealer_final_quartile[param_dict["cluster_col"]] == cluster
        ].copy()

        # within a segment, for each series/model, create quartiles based on MSRP
        for agg in df_cluster[agg_var].unique():
            logger.info(f"Cluster: {cluster}, {aggregation_level}: {agg}")
            df_model = df_cluster[(df_cluster[agg_var] == agg)]
            logger.info(
                f"number of dealers for this {aggregation_level}-cluster: {df_model.dealer_number_latest.nunique()}"
            )

            df_quartiles = df_model.groupby(
                ["dealer_number_latest"], as_index=False
            ).agg(
                {
                    "sa_ratio_dealer_weighted": "mean",
                    "msrp_ppo_list_dealer": "mean",
                }
            )

            # Only assign quartiles if there are at least 4 dealers
            if len(df_quartiles) >= 4:
                # Break the dealers by quartiles based on MSRP

                # If there is same MSRP, we sort by the S/A ratio (higher S/A ratio will be higher quartile)
                # create rank based on MSRP and S/A ratio
                df_quartiles = df_quartiles.sort_values(
                    by=["msrp_ppo_list_dealer", "sa_ratio_dealer_weighted"],
                    ascending=True,
                ).reset_index(drop=True)
                df_quartiles["Rank"] = df_quartiles.index

                df_quartiles["quartile"] = pd.qcut(
                    df_quartiles["Rank"],
                    q=param_dict["qs"],
                    labels=param_dict["bin_labels"],
                )
                x = df_quartiles[["dealer_number_latest", "quartile"]].reset_index(
                    drop=True
                )
                # add back model, cluster info
                x[agg_var] = agg
                x[param_dict["cluster_col"]] = cluster

                # append the results
                quartiles_dealer_list.append(x)

                # Merge the quartiles with the model-series-dealer-ppo_combo level data
                df_plotter = pd.merge(
                    df_model,
                    df_quartiles[["dealer_number_latest", "quartile"]],
                    on="dealer_number_latest",
                )

                if param_dict["display_quartile_plots"]:
                    plot_quartile_distribution(
                        df_plotter,
                        param_dict["bin_labels"],
                        param_dict,
                        aggregation_level,
                    )

    # no quartiles assigned
    if len(quartiles_dealer_list) == 0:
        logger.info("No quartiles assigned")
        return pd.DataFrame()

    # append the results
    df_quartiles_dealer_list = pd.concat(quartiles_dealer_list)
    # convert type from category to str
    df_quartiles_dealer_list["quartile"] = df_quartiles_dealer_list["quartile"].astype(
        str
    )

    return df_quartiles_dealer_list


def catch_no_quartile_existing_grain(
    df_quartiles_dealer_list: pd.DataFrame,
    df_dealer_final_quartile: pd.DataFrame,
    aggregation_level: str,
    param_dict: Dict,
) -> pd.DataFrame:
    """Assign quartile = 'Grain not enough dealers' to the dealers that got the grain where there is less than 4 dealers
    within a segment

    Args:
        df_quartiles_dealer_list (pd.DataFrame): segment-grain-dealer-quartile mapping
        df_dealer_final_quartile (pd.DataFrame): dataframe with information to assign quartiles
        aggregation_level (str): grain level where rules recommendation is based on
        param_dict (Dict): list of parameters for unconstrained demand

    Returns:
        pd.DataFrame: dataframe with quartile = 'Grain not enough dealers' to the dealers that got the grain where
         there is less than 4 dealers within a segment
    """
    df_quartile = df_quartiles_dealer_list.copy(deep=True)

    if aggregation_level == "series":
        agg_cols = [param_dict["cluster_col"], "series_name", "dealer_number_latest"]
    if aggregation_level in ("model", "grade"):
        agg_cols = [param_dict["cluster_col"], "model_number", "dealer_number_latest"]

    # edge case: no quartiles for any dealers
    if df_quartile.empty:
        df_quartile_filled = (
            df_dealer_final_quartile[agg_cols].drop_duplicates().copy(deep=True)
        )
        df_quartile_filled["quartile"] = INSUFFICIENT_GRAIN_DEALERS
    else:
        # get the grain-dealers where there is less than 4 dealers getting a grain
        df_quartile_filled = pd.merge(
            df_dealer_final_quartile[agg_cols].drop_duplicates(),
            df_quartile,
            how="outer",
        )
        df_quartile_filled["quartile"] = df_quartile_filled["quartile"].fillna(
            INSUFFICIENT_GRAIN_DEALERS
        )

    return df_quartile_filled


def calculate_correlation_sa_ratio_msrp_per_vehicle(
    df_dealer_final: pd.DataFrame,
    aggregation_level: str,
    target_month_min: int,
    param_dict: Dict,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """calculate correlation between s/a ratio and PPO PNVW at cluster-grain level

    Args:
        df_dealer_final (pd.DataFrame): input dataframe with S/A ratio and PPO PNVW at cluster-dealer-series-model level
        aggregation_level (str): grain
        target_month_min (int): month we create recommendation for
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: df_dealer_final dataframe with weighted month data
        pd.DataFrame: correlation data for each cluster-grain combination
    """
    iter_corr_df = pd.DataFrame()
    corrs = {}
    correlation_param_dict = param_dict["correlation"]
    df_dealer_final_weighted = pd.DataFrame()

    if aggregation_level == "series":
        agg_var = "series_name"
    elif aggregation_level in ("model", "grade"):
        agg_var = "model_number"

    # filter to length of history for correlation
    month_min, month_max = get_historical_range(
        target_month_min, correlation_param_dict["correlation_len_historical_months"]
    )
    df_dealer_final_correlation = df_dealer_final[
        (df_dealer_final["business_month"] >= month_min)
        & (df_dealer_final["business_month"] <= month_max)
    ].copy(deep=True)
    # loop through each segment, model pair
    for idx, row in (
        df_dealer_final_correlation[[param_dict["cluster_col"], agg_var]]
        .drop_duplicates()
        .iterrows()
    ):
        segment = row[param_dict["cluster_col"]]
        agg = row[agg_var]

        # get all dealer-months
        iter_df = df_dealer_final_correlation[
            (df_dealer_final_correlation[param_dict["cluster_col"]] == segment)
            & (df_dealer_final_correlation[agg_var] == agg)
        ].copy()
        iter_df["date"] = iter_df["business_month"].apply(
            lambda x: datetime.datetime.strptime(str(x), "%Y%m")
        )

        # most recent date
        end_of_business_month = iter_df["business_month"].max()
        latest_date = datetime.datetime.strptime(str(end_of_business_month), "%Y%m")

        # calculate the diff in months from most recent month, assign weight to each month
        iter_df["weights"] = iter_df.apply(
            lambda x: calculate_weights(
                x.date,
                latest_date,
                correlation_param_dict["steepness"],
                correlation_param_dict["clip"],
            ),
            axis=1,
        )
        # TODO: address FutureWarning
        df_dealer_final_weighted = df_dealer_final_weighted.append(iter_df)

        corrs[param_dict["cluster_col"]] = segment
        corrs[agg_var] = agg

        # Weighted correlation

        # calculate correlation on data where there is sales
        num_zero_sales = iter_df[iter_df["quantity_retail_dealer_mth"] == 0].shape[0]
        logger.info(
            f"sales are 0: {num_zero_sales} rows ({num_zero_sales/iter_df.shape[0]*100}%)"
        )

        if iter_df.shape[0] < param_dict["correlation"]["min_corr_data_points"]:
            # if less than 20 data points, say correlation coefficient is 0
            corrs["correl"] = 0
        else:
            corr_coef = DescrStatsW(
                iter_df[["msrp_ppo_list_dealer_mth", "sa_ratio_dealer_mth"]],
                weights=iter_df["weights"],
            ).corrcoef[0][1]

            corrs["correl"] = 0 if math.isnan(corr_coef) else round(corr_coef, 7)

        iter_corr_df = iter_corr_df.append(corrs, ignore_index=True)

    # categorize the correlation into buckets
    # TODO: address FutureWarning
    iter_corr_df["correlation_category"] = iter_corr_df.apply(
        lambda x: categorize_corr(x.correl, param_dict), axis=1
    )

    return df_dealer_final_weighted, iter_corr_df


def calculate_sa_ratio_and_msrp(
    df_joined: pd.DataFrame, aggregation_level: str, param_dict: Dict
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Calculate S/A ratio at cluster-dealer-series-model-month level and
    calculate weighted average PPO PNVW (based on qty retail for quartile) or (availability for correlation)
    at cluster-dealer-series-model-month level

    Args:
        df_joined (pd.DataFrame): cleaned historical sales data
        aggregation_level (str): grain
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: PPO PNVW and S/A ratio for quartile
        pd.DataFrame: PPO PNVW and S/A ratio for correlation
    """

    # get series, model, dealer, PPO combo, business month level data
    df_dealer_raw = df_joined[
        [
            "series_name",
            "model_number",
            param_dict["cluster_col"],
            "dealer_number_latest",
            "expanded_ppo_list",
            "business_month",
            "quantity_retail_ppo_list",
            "availability_ppo_list",
            "msrp_ppo_list",
            "quantity_retail_model",
            "availability_model",
            "sa_ratio_model",
        ]
    ].drop_duplicates()

    agg_cols = [
        "series_name",
        param_dict["cluster_col"],
        "dealer_number_latest",
        "business_month",
    ]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]

    ###################################################################################################################
    # Calculate S/A ratio for each dealer-grain-mth
    ###################################################################################################################
    metric_cols_sa = ["quantity_retail_model", "availability_model"]

    # get sales and availability at dealer-model-mth
    df_dealer = df_dealer_raw.groupby(
        [
            "series_name",
            param_dict["cluster_col"],
            "dealer_number_latest",
            "business_month",
            "model_number",
        ],
        as_index=False,
    )[metric_cols_sa].mean()
    # get sales and availability at dealer-grain-mth
    df_dealer = df_dealer.groupby(agg_cols, as_index=False)[metric_cols_sa].sum()
    df_dealer.rename(
        columns={
            "quantity_retail_model": "quantity_retail_dealer_mth",
            "availability_model": "availability_dealer_mth",
        },
        inplace=True,
    )

    # calculate S/A ratio at segment-series-dealer-grain-month level
    df_dealer["sa_ratio_dealer_mth"] = (
        df_dealer["quantity_retail_dealer_mth"] / df_dealer["availability_dealer_mth"]
    )

    ###################################################################################################################
    # calculate $PPO/vehicle for cars sold for each dealer-grain-mth
    ###################################################################################################################

    # get msrp, sales and availability of ppo_list at dealer-model-mth-ppo_list
    # map in total sales at dealer-grain-mth
    df_dealer_msrp = pd.merge(
        df_dealer_raw,
        df_dealer[
            agg_cols + ["quantity_retail_dealer_mth"] + ["availability_dealer_mth"]
        ],
        how="left",
    )
    # calculate weighted msrp for each dealer-grain-mth
    # use availability/inventory for correlation and sold/quantity for quartile assignment
    # (take into account the cars sold with no PPO where msrp_ppo_list = 0)
    df_dealer_msrp["msrp_ppo_list_dealer_mth"] = (
        df_dealer_msrp["msrp_ppo_list"]
        * df_dealer_msrp["quantity_retail_ppo_list"]
        / df_dealer_msrp["quantity_retail_dealer_mth"]
    )
    df_dealer_msrp_for_correlation = df_dealer_msrp.copy(deep=True)
    df_dealer_msrp_for_correlation["msrp_ppo_list_dealer_mth"] = (
        df_dealer_msrp_for_correlation["msrp_ppo_list"]
        * df_dealer_msrp_for_correlation["availability_ppo_list"]
        / df_dealer_msrp_for_correlation["availability_dealer_mth"]
    )

    # we don't take into account ppo_list with no sales
    df_dealer_msrp = (
        df_dealer_msrp.dropna(subset=["msrp_ppo_list_dealer_mth"])
        .groupby(agg_cols, as_index=False)
        .agg({"msrp_ppo_list_dealer_mth": "sum"})
    )
    # we don't take into account ppo_list with no sales
    df_dealer_msrp_for_correlation = (
        df_dealer_msrp_for_correlation.dropna(subset=["msrp_ppo_list_dealer_mth"])
        .groupby(agg_cols, as_index=False)
        .agg({"msrp_ppo_list_dealer_mth": "sum"})
    )
    ##################################################################################################################
    # merge msrp onto S/A ratio and cleaning for S/A and msrp
    ##################################################################################################################
    df_dealer_for_quartile = pd.merge(df_dealer, df_dealer_msrp, how="left")
    df_dealer_for_correlation = pd.merge(
        df_dealer, df_dealer_msrp_for_correlation, how="left"
    )

    df_dealer_for_quartile = df_dealer_for_quartile[
        # 2.2 exclude msrp inf: ones where model sales is zero but ppo_list sale is nonzero (transfer, etc.)
        (df_dealer_for_quartile["msrp_ppo_list_dealer_mth"] != np.inf)
        # 3.3 when sa ratio is NA, there is no sales and availability
        & (~df_dealer_for_quartile["sa_ratio_dealer_mth"].isna())
    ]
    # When S/A ratio is infinite, sales is nonzero but availability is zero;
    # we want to cap the S/A ratio to be 1 in these cases and assign to a quartile
    df_dealer_for_quartile["sa_ratio_dealer_mth"].replace(np.inf, 1, inplace=True)

    df_dealer_for_correlation = df_dealer_for_correlation[
        # 2.1 exclude S/A ratio inf: ones where sales is nonzero but availability is zero
        (df_dealer_for_correlation["sa_ratio_dealer_mth"] != np.inf)
        # 3.3 when sa ratio is NA, there is no sales and availability
        & (~df_dealer_for_correlation["sa_ratio_dealer_mth"].isna())
    ]

    # fill MSRP with 0 if no sales for the dealer-model-month and dealer-model-month-ppo_list
    df_dealer_for_quartile["msrp_ppo_list_dealer_mth"] = df_dealer_for_quartile[
        "msrp_ppo_list_dealer_mth"
    ].fillna(0)
    # fill MSRP with 0 if no sales for the dealer-model-month and dealer-model-month-ppo_list
    df_dealer_for_correlation["msrp_ppo_list_dealer_mth"] = df_dealer_for_correlation[
        "msrp_ppo_list_dealer_mth"
    ].fillna(0)

    # Cap S/A at 1 if >1
    df_dealer_for_quartile.loc[
        df_dealer["sa_ratio_dealer_mth"] > 1, "sa_ratio_dealer_mth"
    ] = 1
    df_dealer_for_correlation.loc[
        df_dealer["sa_ratio_dealer_mth"] > 1, "sa_ratio_dealer_mth"
    ] = 1

    return df_dealer_for_quartile.copy(deep=True), df_dealer_for_correlation.copy(
        deep=True
    )


def get_dealer_quartile(
    df_joined: pd.DataFrame,
    aggregation_level: str,
    target_month_min: int,
    param_dict: Dict,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Calculate correlation for each segment-grain between S/A and PPO MSRP, assign quartile for each dealer-grain

    Args:
        df_joined (pd.DataFrame): historical sales data
        aggregation_level (str): grain
        target_month_min (int): month we create recommendation for
        param_dict (Dict): run parameters

    Return:
        pd.DataFrame: iter_corr_df contains the correlation category for each segment-grain
        pd.DataFrame: df_dealer_final_weighted contains segment-grain-dealer-mth level features used to calculate
        correlation
        pd.DataFrame: df_quartiles_dealer_list contains the quartile for each dealer-grain
        pd.DataFrame: df_results_dealer contains segment-grain-dealer level features used to calculate
        quartile and quartile correlation results
    """

    ##################################################################################################################
    # Correlation for each grain
    ##################################################################################################################
    # calculate S/A ratio at cluster-dealer-grain-month level
    # calculate weighted average MSRP $PPO/vehicle (based on qty retail) at cluster-dealer-grain-month level
    (
        df_dealer_final_for_quartiles,
        df_dealer_final_for_correlation,
    ) = calculate_sa_ratio_and_msrp(df_joined, aggregation_level, param_dict)

    # Calculate correlation between S/A and MSRP PPO
    # excluded cluster-dealer-grain-months with no sales when calculating correlation
    (
        df_dealer_final_weighted,
        iter_corr_df,
    ) = calculate_correlation_sa_ratio_msrp_per_vehicle(
        df_dealer_final_for_correlation, aggregation_level, target_month_min, param_dict
    )

    ##################################################################################################################
    # Assign quartiles based on MSRP at cluster-series-model level to each dealer
    ##################################################################################################################
    # aggregate across months
    df_dealer_final_quartile = calculate_dealer_level_sum(
        df_dealer_final_for_quartiles, aggregation_level, target_month_min, param_dict
    )
    # assign quartiles
    df_quartiles_dealer_list = assign_quartile(
        df_dealer_final_quartile, aggregation_level, param_dict
    )
    # assign quartile = 'Grain not enough dealers' for grain with less than 4 dealers within a segment
    df_quartiles_dealer_list = catch_no_quartile_existing_grain(
        df_quartiles_dealer_list,
        df_dealer_final_quartile,
        aggregation_level,
        param_dict,
    )

    # Merge quartile to the series-grain-dealer data
    # Some dealers did not get assigned quartiles because the less than 4 dealers sold a grain within a cluster
    if aggregation_level == "series":
        join_cols = ["series_name", param_dict["cluster_col"], "dealer_number_latest"]
    elif aggregation_level in ("model", "grade"):
        join_cols = ["model_number", param_dict["cluster_col"], "dealer_number_latest"]
    df_results_dealer = pd.merge(
        df_dealer_final_quartile,
        df_quartiles_dealer_list,
        on=join_cols,
        how="left",
    )

    # merge correlation to the series-grain-dealer-data
    if aggregation_level == "series":
        join_cols = ["series_name", param_dict["cluster_col"]]
    elif aggregation_level in ("model", "grade"):
        join_cols = ["model_number", param_dict["cluster_col"]]
    df_results_dealer = pd.merge(
        df_results_dealer,
        iter_corr_df,
        on=join_cols,
        how="left",
    )

    return (
        iter_corr_df,
        df_dealer_final_weighted,
        df_quartiles_dealer_list,
        df_results_dealer,
    )


###############################################################################################################
# historical month - rules creation
###############################################################################################################


def prep_data_rules(
    df_joined: pd.DataFrame, aggregation_level: str, param_dict: Dict
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Function to convert raw data to ppo level, grain level and model level if grain = 'series'.

    Args:
        df_joined (pd.DataFrame): raw dataframe at cluster-dealer-series-model-ppo_list-ppo-month level
        aggregation_level (str): grain level
        param_dict (Dict): dictionary of parameters

    Returns:
        df_rules_ppo (pd.DataFrame): dataframe at cluster-dealer-grain-ppo-month level
        df_rules_grain (pd.DataFrame): dataframe at cluster-dealer-grain-month level
        df_sales_model (pd.DataFrame): dataframe at cluster-dealer-series-model-month level
            (only if grain = 'series', else empty)
    """
    agg_cols = [
        "dealer_number_latest",
        "business_month",
        "series_name",
        param_dict["cluster_col"],
    ]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]

    # get grain-dealer-PPO code-business month level data
    df_rules_ppo = (
        df_joined[
            [
                "model_number",
                "dealer_number_latest",
                "accessory_code",
                "business_month",
                "series_name",
                param_dict["cluster_col"],
                "quantity_retail_ppo",
                "availability_ppo",
            ]
        ]
        .drop_duplicates()
        .groupby(agg_cols + ["accessory_code"], as_index=False)
        .agg({"quantity_retail_ppo": "sum", "availability_ppo": "sum"})
    )
    # get grain-dealer-business month level data
    df_rules_grain = (
        df_joined[
            [
                "model_number",
                "dealer_number_latest",
                "business_month",
                "series_name",
                param_dict["cluster_col"],
                "quantity_retail_model",
                "availability_model",
            ]
        ]
        .drop_duplicates()
        .groupby(agg_cols, as_index=False)
        .agg({"quantity_retail_model": "sum", "availability_model": "sum"})
        .rename(
            {
                "quantity_retail_model": "quantity_retail_grain",
                "availabilty_model": "availability_grain",
            },
            axis=1,
        )
    )
    df_rules_grain["aggregation_level"] = aggregation_level

    # create additional model-level qty df for dmaa rule creation if aggregation level is series
    if aggregation_level == "series":
        agg_cols += ["model_number"]
        df_sales_model = (
            df_joined[
                [
                    "model_number",
                    "dealer_number_latest",
                    "business_month",
                    "series_name",
                    param_dict["cluster_col"],
                    "quantity_retail_model",
                ]
            ]
            .drop_duplicates()
            .groupby(agg_cols, as_index=False)
            .agg({"quantity_retail_model": "sum"})
            .rename(
                {
                    "quantity_retail_model": "quantity_retail_grain",
                },
                axis=1,
            )
        )
    else:
        df_sales_model = pd.DataFrame()

    return df_rules_ppo, df_rules_grain, df_sales_model


def merge_quartile_correlation(
    df_rules_model: pd.DataFrame,
    df_rules_ppo: pd.DataFrame,
    df_quartiles_dealer_list: pd.DataFrame,
    iter_corr_df: pd.DataFrame,
    aggregation_level: str,
    param_dict: Dict,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """function to merge quartile and correlation data to rules_model and rules_ppo data

    Args:
        df_rules_model (pd.DataFrame): raw dataframe at cluster-dealer-series-model-month level
        df_rules_ppo (pd.DataFrame): raw dataframe at cluster-dealer-series-model-ppo-month level
        df_quartiles_dealer_list (pd.DataFrame): quartile assigned to dealer at cluster-model level
        iter_corr_df (pd.DataFrame): correlation data for each cluster-model combination
        aggregation_level (str): grain
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: merged dataframe at cluster-dealer-series-model-month level
        pd.DataFrame: merged dataframe at cluster-dealer-series-model-ppo-month level
    """
    # merge quartile and correlation info
    # reduction in rows is because
    #   dealers not assigned quartile
    #   because not enough dealers for the model, or
    #   we filtered out availability is zero when assigning quartiles
    if aggregation_level == "series":
        join_cols = ["series_name", param_dict["cluster_col"]]
    elif aggregation_level in ("model", "grade"):
        join_cols = ["model_number", param_dict["cluster_col"]]
    # only keeping dealer-model-cluster combo that appeared in our quartiles
    df_rules_model_quartile = pd.merge(
        df_rules_model,
        df_quartiles_dealer_list,
        on=join_cols + ["dealer_number_latest"],
        how="inner",
    )

    df_rules_ppo_quartile = pd.merge(
        df_rules_ppo,
        df_quartiles_dealer_list,
        on=join_cols + ["dealer_number_latest"],
        how="inner",
    )

    # merge in correlation for each segment_model pair
    df_rules_model_quartile = pd.merge(
        df_rules_model_quartile,
        iter_corr_df,
        on=join_cols,
        how="inner",
    )

    df_rules_ppo_quartile = pd.merge(
        df_rules_ppo_quartile,
        iter_corr_df,
        on=join_cols,
        how="inner",
    )

    return df_rules_model_quartile, df_rules_ppo_quartile


def merge_quartile_correlation_getsudo(
    getsudo_df: pd.DataFrame,
    df_quartiles_dealer_list: pd.DataFrame,
    iter_corr_df: pd.DataFrame,
    df_results_dealer: pd.DataFrame,
    aggregation_level: str,
    param_dict: Dict,
) -> pd.DataFrame:
    """Merge quartile and correlation data to ProCon data

    Args:
        df_getsudo (pd.DataFrame): region-grain-dealer-segment data, derived from ProCon at region level
        df_quartiles_dealer_list (pd.DataFrame): quartile assigned to dealer at cluster-model level
        iter_corr_df (pd.DataFrame): correlation data for each cluster-model combination
        df_results_dealer (pd.DataFrame): dataframe with quartile and correlation info for each grain-dealer
        aggregation_level (str): grain
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: ProCon data merged with quartile and correlation
    """
    # merge quartile and correlation info
    if aggregation_level == "series":
        join_cols = ["series_name", param_dict["cluster_col"]]
    elif aggregation_level in ("model", "grade"):
        join_cols = ["model_number", param_dict["cluster_col"]]

    # merge in correlation for each segment_model pair
    getsudo_corr_df = pd.merge(
        getsudo_df,
        iter_corr_df,
        on=join_cols,
        how="left",
    )

    # Assign None to correlation if there is no correlation data
    # This happens if segment has not ordered grain in history
    getsudo_corr_df.loc[
        getsudo_corr_df["correlation_category"].isnull(),
        "correlation_category",
    ] = "None"

    # Merge in the quartiles for each segment-grain pair
    getsudo_quartile_corr_df = pd.merge(
        getsudo_corr_df,
        df_quartiles_dealer_list,
        on=join_cols + ["dealer_number_latest"],
        how="left",
    )
    getsudo_quartile_corr_df["no_quartile_new_grain"] = "No"
    getsudo_quartile_corr_df.loc[
        getsudo_quartile_corr_df["quartile"].isna(), "no_quartile_new_grain"
    ] = "Yes"
    # Edge case: Assign quartiles for those dealers with no quartiles, new grain
    getsudo_quartile_corr_df = assign_quartile_new_grain(
        getsudo_quartile_corr_df, df_results_dealer
    )

    return getsudo_quartile_corr_df


def assign_quartile_new_grain(
    getsudo_quartile_corr_df: pd.DataFrame, dealer_results: pd.DataFrame
) -> pd.DataFrame:
    """Assign most common quartile for other grains within the same series to dealers with no quartile, new grain

    Args:
        getsudo_quartile_corr_df (pd.DataFrame): getsudo month dealer-grain combination with quartile and correlation
        dealer_results (pd.DataFarme): dataframe with quartile and correlation info for each grain-dealer

    Returns:
        pd.DataFrame: quartile filled for dealers with no quartiles, new grain
    """
    # loop through each dealer with no quartile because of new grain (have not gotten this grain in last X months)
    for idx, row in getsudo_quartile_corr_df[
        getsudo_quartile_corr_df["quartile"].isna()
    ].iterrows():
        dealer = row["dealer_number_latest"]
        corr_cat = row["correlation_category"]

        # correlation is positive or None
        if corr_cat in (["None", "Positive"]):
            # select the other models the dealers got within same segment-grain,
            # only quartile in lowest, low, medidum
            benchmark_grain = dealer_results[
                (dealer_results["correlation_category"].isin(["None", "Positive"]))
                & (dealer_results["quartile"].isin(["lowest", "low", "medium"]))
                & (dealer_results["dealer_number_latest"] == dealer)
            ].copy()
        elif corr_cat in (["Negative"]):
            # select the other models the dealers got within same segment-grain,
            # only quartile in low, medidum, high
            benchmark_grain = dealer_results[
                (dealer_results["correlation_category"].isin(["Negative"]))
                & (dealer_results["quartile"].isin(["low", "medium", "high"]))
                & (dealer_results["dealer_number_latest"] == dealer)
            ].copy()

        # if no other grain within same series or grain = series
        if benchmark_grain.empty:
            # assign quartile as low
            getsudo_quartile_corr_df.loc[idx, "quartile"] = "low"
        else:
            # find the most common quartile for the other grains, if tie, look for the quartile with more sales
            most_common_quartile = find_most_common_quartile(benchmark_grain, corr_cat)
            getsudo_quartile_corr_df.loc[idx, "quartile"] = most_common_quartile

    return getsudo_quartile_corr_df


def find_most_common_quartile(benchmark_grain: pd.DataFrame, corr_cat: str) -> str:
    """Assign quartile for the dealer-grain based on most common quartile for the other grain the dealer got in same
    correlation category

    Args:
        benchmark_grain (pd.DataFrame): all the other grains within same series as the new grain
        corr_cat (str): correlation category of the new grain

    Returns:
        str: quartile for the other grains and the count
    """
    benchmark_df = benchmark_grain.copy(deep=True)
    # get the quartiles for the other grains and count occurrence and sum sales
    most_common_quartile = (
        benchmark_df.groupby("quartile", as_index=False)
        .agg({"dealer_number_latest": "count", "quantity_retail_dealer": "sum"})
        .rename({"dealer_number_latest": "grain_count"}, axis=1)
    )
    # assign weight for quartile based on correlation category
    if corr_cat in (["None", "Positive"]):
        # if tie, pick highest quartile
        most_common_quartile["weight"] = most_common_quartile["quartile"].map(
            {"high": 4, "medium": 3, "low": 2, "lowest": 1}
        )
    elif corr_cat in (["Negative"]):
        # if tie, pick lowest quartile
        most_common_quartile["weight"] = most_common_quartile["quartile"].map(
            {"high": 1, "medium": 2, "low": 3, "lowest": 4}
        )

    # sort by total sales and then by occurrence, and then by weight
    most_common_quartile_df = most_common_quartile.sort_values(
        by=["quantity_retail_dealer", "grain_count", "weight"], ascending=False
    )
    return most_common_quartile_df["quartile"].values[0]


def sum_sale_availability_for_rules(
    df_rules_ppo_quartile: pd.DataFrame,
    df_rules_model_quartile: pd.DataFrame,
    aggregation_level: str,
    param_dict: Dict,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """function to calculate total PPO and model sales at cluster-quartile-dealer-series-grain-ppo level across months

    Args:
        df_rules_ppo_quartile (pd.DataFrame): merged raw dataframe at cluster-dealer-series-grain-ppo-month level
        df_rules_model_quartile (pd.DataFrame): merged raw dataframe at cluster-dealer-series-grain-month level
        aggregation_level (str): grain
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: total sales at cluster-quartile-dealer-series-grain-ppo level
        pd.DataFrame: total sales at cluster-quartile-dealer-series-grain level
        pd.DataFrame: total sales at cluster-quartile-series-grain-ppo level
        pd.DataFrame: total ppo and model sales at cluster-quartile-dealer-series-grain-ppo level
    """
    # get total sales across history (months)

    agg_cols = ["series_name", param_dict["cluster_col"], "quartile"]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]

    # total sales at cluster-quartile-dealer-series-model-ppo level
    df_sale_ppo = df_rules_ppo_quartile.groupby(
        agg_cols + ["accessory_code", "dealer_number_latest", "correlation_category"],
        as_index=False,
    ).agg({"quantity_retail_ppo": "sum", "correl": "mean"})
    df_sale_ppo["correl"] = df_sale_ppo["correl"].round(7)

    # grain level
    # total sales at cluster-quartile-dealer-series-grain level
    df_sale_model = df_rules_model_quartile.groupby(
        agg_cols + ["dealer_number_latest", "correlation_category"], as_index=False
    ).agg({"quantity_retail_grain": "sum", "correl": "mean"})
    df_sale_model["correl"] = df_sale_model["correl"].round(7)

    # get total sales across dealers groupby quartile for each grain
    # within a quartile, if dealer did not order a code, we still need to sum up their sales
    # cluster-grain-quartile level sales
    # total sales at cluster-quartile-series-grain level
    df_sale_model_quartile = (
        df_sale_model.groupby(agg_cols, as_index=False)
        .agg({f"quantity_retail_grain": "sum"})
        .rename(columns={"quantity_retail_grain": "quantity_retail_grain_quartile"})
    )

    # merge the cluster-grain-quartile level sales onto ppo level
    df_rules_raw = pd.merge(df_sale_ppo, df_sale_model_quartile, how="left")

    return df_sale_ppo, df_sale_model, df_sale_model_quartile, df_rules_raw


def get_recommended_rules_dealer_lvl(
    df_rules_raw: pd.DataFrame,
    df_sale_model: pd.DataFrame,
    quartile_name: str,
    aggregation_level: str,
    param_dict: Dict,
) -> pd.DataFrame:
    """function to prepare rules at dealer level for high and lowest quartile

    Args:
        df_rules_raw (pd.DataFrame): total ppo and model sales at cluster-quartile-dealer-series-grain-ppo level
        df_sale_model(pd.DataFrame): total sales at cluster-quartile-dealer-series-grain level
        quartile_name (str): name of quartile
        aggregation_level (str): grain
        param_dict: run parameters

    Returns:
        pd.DataFrame: rules with recommended retail installation rate at cluster-dealer-series-model-grain level
    """
    agg_cols = [
        "dealer_number_latest",
        "series_name",
        param_dict["cluster_col"],
        "quartile",
        "correlation_category",
        "quantity_retail_grain",
    ]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]
    df_rules_raw_temp = pd.merge(
        df_rules_raw,
        df_sale_model[agg_cols].drop_duplicates(),
        how="left",
    )

    # select out only one quartile
    df_rules_one_quartile = df_rules_raw_temp[
        df_rules_raw_temp["quartile"] == quartile_name
    ].copy()

    # calculate installation and retail installation rate for each dealer within one quartile
    df_rules_one_quartile["rec_retail_installation_rate"] = (
        df_rules_one_quartile["quantity_retail_ppo"]
        / df_rules_one_quartile["quantity_retail_grain"]
    )
    df_rules_one_quartile.rename(
        columns={
            "quantity_retail_ppo": "quartile_quantity_retail_ppo",
            "quantity_retail_grain": "quartile_quantity_retail_grain",
        },
        inplace=True,
    )

    # fill NA or inf as 0
    df_rules_one_quartile["rec_retail_installation_rate"] = df_rules_one_quartile[
        "rec_retail_installation_rate"
    ].fillna(0)
    return df_rules_one_quartile


def get_recommended_rules(
    df_rules_raw: pd.DataFrame,
    quartile_name: str,
    aggregation_level: str,
    param_dict: Dict,
) -> pd.DataFrame:
    """function to prepare rules for all quartiles

    Args:
        df_rules_raw (pd.DataFrame): total ppo and model sales at cluster-quartile-dealer-series-grain-ppo level
        quartile_name (str): name of quartile
        aggregation_level (str): grain
        param_dict (Dict): run parameters

    Returns:
        pd.DataFrame: rules with recommended retail installation rate at cluster-series-grain-ppo level
    """
    agg_cols = ["series_name", param_dict["cluster_col"], "accessory_code"]
    if aggregation_level in ("model", "grade"):
        agg_cols += ["model_number"]

    # select out only one quartile
    df_rules_one_quartile = df_rules_raw[
        df_rules_raw["quartile"] == quartile_name
    ].copy()

    # for each segemnt, series, code, within a quartile, sum across all dealers
    df_rules_one_quartile = df_rules_one_quartile.groupby(agg_cols, as_index=False).agg(
        {
            "quantity_retail_ppo": "sum",
            "quantity_retail_grain_quartile": "mean",
        }
    )
    # calculate installation and retail installation rate for one quartile
    df_rules_one_quartile["rec_retail_installation_rate"] = (
        df_rules_one_quartile["quantity_retail_ppo"]
        / df_rules_one_quartile["quantity_retail_grain_quartile"]
    )

    df_rules_one_quartile.rename(
        columns={
            "quantity_retail_ppo": "quartile_quantity_retail_ppo",
            "quantity_retail_grain_quartile": "quartile_quantity_retail_grain",
        },
        inplace=True,
    )
    df_rules_one_quartile["rec_retail_installation_rate"] = df_rules_one_quartile[
        "rec_retail_installation_rate"
    ].fillna(0)
    return df_rules_one_quartile


def get_historical_rules(
    df_joined: pd.DataFrame,
    df_quartiles_dealer_list: pd.DataFrame,
    iter_corr_df: pd.DataFrame,
    aggregation_level: str,
    target_month_min: int,
    param_dict: Dict,
) -> Tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
]:
    """Create historical rules for each quartile at segment-quartile level and create historical rules for highest
    and lowest quartile on segment-quartile-dealer level

    Args:
        df_joined (pd.DataFrame): cleaned historical sales data
        df_quartiles_dealer_list (pd.DataFrame): grain-dealer quartile mapping
        iter_corr_df (pd.DataFrame): segment-grain correlation category mapping
        aggregation_level (str): grain
        target_month_min (int): month we generate rules for
        param_dict: run parameter

    Returns:
        pd.DataFrame: df_sale_ppo is sales data on dealer-ppo level
        pd.DataFrame: df_sale_grain is sales data on dealer-grain level
        pd.DataFrame: df_rules_raw is sales data on dealer-ppo level with sales quantity at segment-quartile level
        pd.DataFrame: df_sales_model is sales at dealer-model level
        pd.DataFrame: df_rules_high_quartile_dealer_lvl is recommended rules for high quartile at dealer-ppo level
        pd.DataFrame: df_rules_lowest_quartile_dealer_lvl is recommended rules for lowest quartile at dealer-ppo level
        pd.DataFrame: df_rules_no_quartile_dealer_lvl is recommended rules for 'grain not enough dealers' quartile at
        dealer-ppo level
        pd.DataFrame: df_rules_lowest_quartile is recommended rules for lowest quartile at quartile-ppo level
        pd.DataFrame: df_rules_low_quartile is recommended rules for low quartile at quartile-ppo level
        pd.DataFrame: df_rules_medium_quartile is recommended rules for medium quartile at quartile-ppo level
        pd.DataFrame: df_rules_high_quartile is recommended rules for high quartile at quartile-ppo level
    """
    # filter to length of history for rules
    month_min, month_max = get_historical_range(
        target_month_min, param_dict["rules_len_historical_months"]
    )
    df_joined_rules = df_joined[
        (df_joined["business_month"] >= month_min)
        & (df_joined["business_month"] <= month_max)
    ].copy(deep=True)

    # Pre-process data
    # prepare base raw data at cluster-dealer-grain-ppo-month level and cluster-dealer-grain-month level
    df_rules_ppo, df_rules_grain, df_sales_model = prep_data_rules(
        df_joined_rules, aggregation_level, param_dict
    )

    # merge in quartile and correlation info
    df_rules_model_quartile, df_rules_ppo_quartile = merge_quartile_correlation(
        df_rules_grain,
        df_rules_ppo,
        df_quartiles_dealer_list,
        iter_corr_df,
        aggregation_level,
        param_dict,
    )

    # get total sales across the months at ppo/grain level
    # also get total sales for the grain for each quartile
    (
        df_sale_ppo,
        df_sale_grain,
        df_sale_model_quartile,
        df_rules_raw,
    ) = sum_sale_availability_for_rules(
        df_rules_ppo_quartile, df_rules_model_quartile, aggregation_level, param_dict
    )

    # Get recommended rules for each quartile
    df_rules_high_quartile_dealer_lvl = get_recommended_rules_dealer_lvl(
        df_rules_raw, df_sale_grain, "high", aggregation_level, param_dict
    )
    df_rules_lowest_quartile_dealer_lvl = get_recommended_rules_dealer_lvl(
        df_rules_raw, df_sale_grain, "lowest", aggregation_level, param_dict
    )
    df_rules_no_quartile_dealer_lvl = get_recommended_rules_dealer_lvl(
        df_rules_raw,
        df_sale_grain,
        INSUFFICIENT_GRAIN_DEALERS,
        aggregation_level,
        param_dict,
    )

    df_rules_high_quartile = get_recommended_rules(
        df_rules_raw, "high", aggregation_level, param_dict
    )
    df_rules_medium_quartile = get_recommended_rules(
        df_rules_raw, "medium", aggregation_level, param_dict
    )
    df_rules_low_quartile = get_recommended_rules(
        df_rules_raw, "low", aggregation_level, param_dict
    )
    df_rules_lowest_quartile = get_recommended_rules(
        df_rules_raw, "lowest", aggregation_level, param_dict
    )
    return (
        df_sale_ppo,
        df_sale_grain,
        df_rules_raw,
        df_sales_model,
        df_rules_high_quartile_dealer_lvl,
        df_rules_lowest_quartile_dealer_lvl,
        df_rules_no_quartile_dealer_lvl,
        df_rules_lowest_quartile,
        df_rules_low_quartile,
        df_rules_medium_quartile,
        df_rules_high_quartile,
    )


def log_run_statistics(
    iter_corr_df: pd.DataFrame,
    target_month_min: int,
    series: str,
    aggregation_level: str,
    brand: str,
) -> pd.DataFrame:
    """Log number of segment-grain combos for each correlation category

    Args:
        iter_corr_df (pd.DataFrame): segment-grain combo and their correlation category
        target_month_min (int): the business month
        series (str): series name
        aggregation_level (str): grain
        brand (str): brand of current run (either "toyota" or "lexus")

    Returns:
        pd.DataFrame: bpi log with number of segment-grain combos for each correlation category
    """
    bpi_log_run_statistics_df = (
        iter_corr_df.groupby(["correlation_category"])
        .size()
        .reset_index(name="count_of_correlation_category_in_segment_grain")
    )
    bpi_log_run_statistics_df["business_month"] = target_month_min
    bpi_log_run_statistics_df["series_name"] = series
    bpi_log_run_statistics_df["grain"] = aggregation_level
    bpi_log_run_statistics_df["brand"] = brand

    return bpi_log_run_statistics_df


def merge_grade_column(
    df_merge_into: pd.DataFrame, df_merge_from: pd.DataFrame
) -> pd.DataFrame:
    """
    This function merges grade column into a dataframe on series_name and model_number columns using a left join.
    After the merge, it checks for null values in the grade column and raises an error if any nulls are found.

    Args:
        df_merge_into (pd.DataFrame): The dataframe to merge grade into.
        df_merge_from (pd.DataFrame): The dataframe containing grade.

    Returns:
        pd.DataFrame: The merged dataframe.

    Raises:
        ValueError: If there are any null values in the grade after the merge.
    """

    # Merge dataframes
    df_merge_into = pd.merge(
        df_merge_into,
        df_merge_from[["series_name", "model_number", "grade"]],
        on=["series_name", "model_number"],
        how="left",
    )

    # Check if there are any null values in the target column
    if df_merge_into["grade"].isnull().any():
        raise ValueError(f"Some rows didn't get a grade")

    return df_merge_into


def apply_grade_level_recommendation_heuristic(df: pd.DataFrame) -> pd.DataFrame:
    """
    This function applies a heuristic to recommend grade level based on the passed DataFrame.
    It calculates a weighted average of the 'rec_retail_installation_rate' column, weighted by
    the 'quartile_quantity_retail_grain' column, for each group defined by 'series_name', 'grade',
    and 'accessory_code'. It then recombines this with the original DataFrame, ensuring
    that the first instance of certain information is retained for each group of 'series_name',
    'grade', and 'model_number'.

    The resulting DataFrame will have the same columns as the input DataFrame, but with
    'rec_retail_installation_rate' replaced by its weighted average for each group, and with
    rows possibly reordered and/or duplicated rows dropped.

    If the 'dealer_number_latest' column exists in the input DataFrame, it will be included
    in the groups for recombination. Otherwise, it will be ignored.

    Note that the outgoing dataframe may have more rows than the original dataframe coming in.

    Args:
        df : pd.DataFrame
            A DataFrame with at least the following columns:
            - 'series_name'
            - 'grade'
            - 'accessory_code'
            - 'model_number'
            - 'rec_retail_installation_rate'
            - 'quartile_quantity_retail_grain'
            It may optionally also contain the 'dealer_number_latest' column.

    Returns:
        pd.DataFrame
            The input DataFrame with 'rec_retail_installation_rate' replaced by its
            weighted average for each group of 'series_name', 'grade', and 'accessory_code',
            and with rows possibly reordered and/or duplicated rows dropped.

    """

    # Helper function to calculate weighted average
    def calculate_weighted_avg(
        df: pd.DataFrame, value_col: str, weight_col: str
    ) -> pd.Series:
        total_weight = df[weight_col].sum()  # Calculate the sum of weights

        # Check if total_weight is zero to avoid divide by zero errors
        if total_weight == 0:
            return pd.Series({value_col: 0})

        # Calculate the weighted average
        weighted_avg = (df[value_col] * df[weight_col]).sum() / total_weight
        # Handle the case where weighted average is not finite
        res_dict = {value_col: weighted_avg if np.isfinite(weighted_avg) else 0}
        return pd.Series(res_dict)

    # Constants
    VALUE_COL = "rec_retail_installation_rate"
    WEIGHT_COL = "quartile_quantity_retail_grain"

    # To handle whether the input has dealer_number_latest column in it or not since this column is part of the grade logic
    if "dealer_number_latest" in df.columns.to_list():
        DEALER_COL = ["dealer_number_latest"]
    else:
        DEALER_COL = []

    # Added label column to aggregation to make sure each segment(label) is treated separately.
    GRADE_LEVEL_REC_GROUPING_COLS = ["label", "series_name", "grade", "accessory_code"]

    """ 
    Determine the columns to retain for additional information. 
    quartile_quantity_retail_ppo column needs to be handled separately
    """

    RETAINED_INFO_GROUPING_COLS = [
        "label",
        "series_name",
        "grade",
        "model_number",
    ] + DEALER_COL

    # Certain information needs to be preserved and merged back in after the heuristic logic is applied
    RETAINED_INFO_COLS = df.columns.difference(
        RETAINED_INFO_GROUPING_COLS
        + [VALUE_COL, "quartile_quantity_retail_ppo"]
        + DEALER_COL
    )
    # Determine the columns to use after processing
    POSTPROCESSED_GROUPING_COLS = list(
        set(GRADE_LEVEL_REC_GROUPING_COLS).difference({"accessory_code"})
    )

    # Group by RETAINED_INFO_GROUPING_COLS and retain first row of each group in RETAINED_INFO_COLS
    df_retained_info = (
        df.groupby(RETAINED_INFO_GROUPING_COLS)[RETAINED_INFO_COLS]
        .first()
        .reset_index()
    )
    # Handling quartile_quantity_retail_ppo separately because new accessory_code will be introduced after
    # grade heuristics logic is applied.

    df_retained_quartile_quantity_retail_ppo = (
        df.groupby(RETAINED_INFO_GROUPING_COLS + ["accessory_code"])[
            "quartile_quantity_retail_ppo"
        ]
        .first()
        .reset_index()
    )

    # Group by GRADE_LEVEL_REC_GROUPING_COLS and apply weighted average calculation on rec_retail_installation_rate
    df_get_grade_level_rec = (
        df.groupby(GRADE_LEVEL_REC_GROUPING_COLS)
        .apply(calculate_weighted_avg, VALUE_COL, WEIGHT_COL)
        .reset_index()
    )

    # Join original DataFrame with the calculated df_grade_level_recommendation across all models
    df_post_processed = pd.merge(
        df[RETAINED_INFO_GROUPING_COLS],
        df_get_grade_level_rec,
        on=["label", "series_name", "grade"],
        how="left",
    ).drop_duplicates()

    # Join df_post_processed with original information that wasn't used for the grade logic
    df_pre_final = pd.merge(
        df_post_processed,
        df_retained_info[df_retained_info.columns.difference(["accessory_code"])],
        on=RETAINED_INFO_GROUPING_COLS,
        how="left",
    )

    # Join the pre_final result to retrieve quartile_quantity_retail_ppo and fill any null with 0.
    # quartile_quantity_retail_ppo column is specifically tied to each model_number and ppo combination
    # and newly introduced ppos don't have this information previously

    df_final = pd.merge(
        df_pre_final,
        df_retained_quartile_quantity_retail_ppo,
        on=RETAINED_INFO_GROUPING_COLS + ["accessory_code"],
        how="left",
    ).fillna(0)

    return df_final


def run_grade_logic(
    quartiles: List[pd.DataFrame],
    df_joined: pd.DataFrame,
) -> List[pd.DataFrame]:
    # Get table of series, model_number, and grade - to use for grade lookup
    grades_table = df_joined[["series_name", "model_number", "grade"]].drop_duplicates(
        subset=["series_name", "model_number"]
    )

    # Loop over all quartiles and apply grade level recommendation heuristic
    for i in range(len(quartiles)):
        if quartiles[i].empty:
            continue

        # Merge grades into dataframes
        quartiles[i] = merge_grade_column(
            df_merge_into=quartiles[i], df_merge_from=grades_table
        )

        # Apply grade heuristic to dataframes
        quartiles[i] = apply_grade_level_recommendation_heuristic(quartiles[i])

        # Remove grades from dataframes
        quartiles[i] = quartiles[i].drop(["grade"], axis=1)

    return quartiles


def model_series_month(
    series: str,
    target_month_min: int,
    mode: str,
    run_version: str,
    base_parameters: dict,
    data_catalog: dict,
) -> None:
    aggregation_level = base_parameters["aggregation_level"][series]
    brand = base_parameters["brand"]
    io_dict = {
        "series": series,
        "target_month_min": target_month_min,
        "mode": mode,
        "run_version": run_version,
        "brand": brand,
    }

    ######################################################################################################
    # Load data
    ######################################################################################################

    df_joined = load_data(
        data_catalog["ppo_historical_with_segments"], param_dict=io_dict
    )
    getsudo_new_month_df = load_data(
        data_catalog["getsudo_new_month"], param_dict=io_dict
    )
    ######################################################################################################
    # define correlation and quartile
    ######################################################################################################

    logger.info("Assigning quartiles to grain-dealer")
    (
        iter_corr_df,
        df_dealer_final_weighted,
        df_quartiles_dealer_list,
        df_results_dealer,
    ) = get_dealer_quartile(
        df_joined, aggregation_level, target_month_min, base_parameters
    )

    # log count of segment-grain combos for each correlation category
    bpi_log_run_statistics_df = log_run_statistics(
        iter_corr_df, target_month_min, series, aggregation_level, brand
    )

    ######################################################################################################
    # Save data
    ######################################################################################################

    # Plot overall correlation histogram
    plot_save_figure(
        data_catalog["correlation_plot"], iter_corr_df["correl"], param_dict=io_dict
    )

    # Save correlation df for each segment, model
    save_data(data_catalog["correlation"], iter_corr_df, param_dict=io_dict)

    # Save correlation df for each segment, model
    save_data(
        data_catalog["bpi_log_run_statistics"],
        bpi_log_run_statistics_df,
        param_dict=io_dict,
        mode="a",
        header=False,
    )

    # Plot volume for each data point in correlation calculation
    plot_save_figure(
        data_catalog["correlation_volume_plot"],
        df_dealer_final_weighted["quantity_retail_dealer_mth"].values.tolist(),
        param_dict=io_dict,
    )
    # Save correlation df for each segment, model
    save_data(
        data_catalog["correlation_raw"],
        df_dealer_final_weighted,
        param_dict=io_dict,
    )

    save_data(data_catalog["quartiles"], df_quartiles_dealer_list, param_dict=io_dict)

    save_data(data_catalog["dealer_results"], df_results_dealer, param_dict=io_dict)

    ######################################################################################################
    # historical month - rules creation
    ######################################################################################################

    logger.info("Getting historical rules")
    (
        df_sale_ppo,
        df_sale_grain,
        df_rules_raw,
        df_sales_model,
        df_rules_high_quartile_dealer_lvl,
        df_rules_lowest_quartile_dealer_lvl,
        df_rules_no_quartile_dealer_lvl,
        df_rules_lowest_quartile,
        df_rules_low_quartile,
        df_rules_medium_quartile,
        df_rules_high_quartile,
    ) = get_historical_rules(
        df_joined,
        df_quartiles_dealer_list,
        iter_corr_df,
        aggregation_level,
        target_month_min,
        base_parameters,
    )
    logger.info("Successfully got historical rules for: {series}, {target_month_min}")

    if aggregation_level == "grade":
        logger.info(f"Applying grades for: {series}, {target_month_min}")
        (
            df_rules_lowest_quartile,
            df_rules_low_quartile,
            df_rules_medium_quartile,
            df_rules_high_quartile,
            df_rules_high_quartile_dealer_lvl,
            df_rules_lowest_quartile_dealer_lvl,
            df_rules_no_quartile_dealer_lvl,
        ) = run_grade_logic(
            quartiles=[
                df_rules_lowest_quartile,
                df_rules_low_quartile,
                df_rules_medium_quartile,
                df_rules_high_quartile,
                df_rules_high_quartile_dealer_lvl,
                df_rules_lowest_quartile_dealer_lvl,
                df_rules_no_quartile_dealer_lvl,
            ],
            df_joined=df_joined,
        )
        logger.info(
            f"Successfully applied grade logic for: {series}, {target_month_min}"
        )

    ######################################################################################################
    # Save data
    ######################################################################################################

    save_data(data_catalog["historical_ppo_qty"], df_sale_ppo, param_dict=io_dict)
    save_data(data_catalog["historical_grain_qty"], df_sale_grain, param_dict=io_dict)

    save_data(data_catalog["rules_base"], df_rules_raw, param_dict=io_dict)

    if aggregation_level == "series":
        save_data(
            data_catalog["dealer_sales_model"], df_sales_model, param_dict=io_dict
        )

    save_data(
        data_catalog["rules_high_q_dealer"],
        df_rules_high_quartile_dealer_lvl,
        param_dict=io_dict,
    )
    save_data(
        data_catalog["rules_lowest_q_dealer"],
        df_rules_lowest_quartile_dealer_lvl,
        param_dict=io_dict,
    )
    save_data(
        data_catalog["rules_no_q_dealer"],
        df_rules_no_quartile_dealer_lvl,
        param_dict=io_dict,
    )

    save_data(
        data_catalog["rules_lowest_q"], df_rules_lowest_quartile, param_dict=io_dict
    )
    save_data(data_catalog["rules_low_q"], df_rules_low_quartile, param_dict=io_dict)
    save_data(
        data_catalog["rules_medium_q"], df_rules_medium_quartile, param_dict=io_dict
    )
    save_data(data_catalog["rules_high_q"], df_rules_high_quartile, param_dict=io_dict)

    logger.info(
        f"Merging quartile and correlation info for: {series}, {target_month_min}"
    )

    logger.info(
        f"Merging quartile and correlation info for: {series}, {target_month_min}"
    )
    # merge in quartile and correlation info
    dealer_grain_corr_quartile_df = merge_quartile_correlation_getsudo(
        getsudo_new_month_df,
        df_quartiles_dealer_list,
        iter_corr_df,
        df_results_dealer,
        aggregation_level,
        base_parameters,
    )
    logger.info(
        f"Successfully merged quartile and correlation info for: {series}, {target_month_min}"
    )

    ######################################################################################################
    # Save data
    ######################################################################################################

    save_data(
        data_catalog["dealer_grain_corr_quartile_df"],
        dealer_grain_corr_quartile_df,
        param_dict=io_dict,
    )


@timer_func
def run(base_parameters, data_catalog, run_version):
    logger.info(f"Run version: {run_version}")

    # run params
    mode = base_parameters["mode"]
    brand = base_parameters["brand"]
    iteration_list = load_data(
        data_catalog["run_dict"],
        param_dict={"run_version": run_version, "brand": brand},
    ).values

    logger.info(f"Running mode: {mode}, iterations: {iteration_list}")

    # initialize the bpi-log-run-statistics
    save_data(
        data_catalog["bpi_log_run_statistics"],
        pd.DataFrame(
            columns=[
                "correlation_category",
                "count_of_correlation_category_in_segment_grain",
                "business_month",
                "series_name",
                "grain",
                "brand",
            ]
        ),
        param_dict={"run_version": run_version, "brand": brand},
    )

    is_parallel_process = base_parameters["parallel_process"]
    if is_parallel_process:
        with concurrent.futures.ProcessPoolExecutor() as executor:
            futures = []
            for series, target_month_min in iteration_list:
                futures.append(
                    executor.submit(
                        model_series_month,
                        series,
                        target_month_min,
                        mode,
                        run_version,
                        base_parameters.copy(),
                        data_catalog.copy(),
                    )
                )
            wait(futures)
    else:
        for series, target_month_min in iteration_list:
            model_series_month(
                series,
                target_month_min,
                mode,
                run_version,
                base_parameters.copy(),
                data_catalog.copy(),
            )
