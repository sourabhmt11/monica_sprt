import os
import sys
import pytest
import setuptools
from setuptools.command.test import test as TestCommand

with open("README.md", "r") as fh:
    long_description = fh.read()


class PyTestCommand(TestCommand):
    user_options = [("pytest-args=", "a", "Arguments to pass to py.test")]

    def initialize_options(self):
        TestCommand.initialize_options(self)
        # Pass the module to run coverage report, set coverage report format as xml so that TDP Sonarqube can display the result
        self.pytest_args = ["--cov=%s" % ("src/vmx_ppo/"), "--cov-report=xml"]

    def finalize_options(self):
        TestCommand.finalize_options(self)
        self.test_args = []
        self.test_suite = True

    def run_tests(self):
        errno = pytest.main(self.pytest_args)
        sys.exit(errno)


def package_files(directory):
    paths = []
    for path, directories, filenames in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.join("..", path, filename))
    return paths


test_requirements = ["pytest", "pytest-cov"]

# get the dependencies from requirements.txt and install
with open("requirements.txt", "r", encoding="utf-8") as f:
    requires = []
    for line in f:
        req = line.split("#", 1)[0].strip()
        if req and not req.startswith("--"):
            requires.append(req)

setuptools.setup(
    name="vmxsa-ml-pipeline-suggested-accessories",
    version="1.0.0",  # This version will be replaced by TDP CI build number version.
    python_requires=">=3.8",
    author="TMNA VMXSA CICD team",
    author_email=("chandan.kumar@toyota.com"),
    description="",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Toyota-Motor-North-America/vmxsa-ml-pipeline-suggested-accessories",
    packages=setuptools.find_packages(),
    include_package_data=True,
    package_data={"": package_files("conf")},
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    license="OSI Approved",
    platforms=["OS Independent"],
    install_requires=requires,
    setup_requires=["pytest-runner", "pytest-pylint"],
    tests_require=test_requirements,
    extras_require={
        "test": test_requirements,
    },
    cmdclass={
        "test": PyTestCommand
    },  # unit test command implementation to be called with test stage
)
