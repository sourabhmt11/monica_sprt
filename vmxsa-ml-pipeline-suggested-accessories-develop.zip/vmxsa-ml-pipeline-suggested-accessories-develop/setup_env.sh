echo "Setting up environment"

conda create --name vmx_ppo_env python=3.9 -y
source /opt/conda/etc/profile.d/conda.sh
conda activate vmx_ppo_env

pip install -r requirements.txt
