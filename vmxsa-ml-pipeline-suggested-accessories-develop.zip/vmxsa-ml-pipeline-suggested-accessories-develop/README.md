# vmxsa-ml-pipeline-suggested-accessories
Data science pipeline for PPO

## Setup dev env in CLI

### Mac OS
```zsh
# set-up conda env
zsh setup_env.sh
source activate vmx_ppo_env

# set-up pre-commit
brew install pre-commit # if not installed yet
pre-commit install
```

### Sagemaker (Linux) (bash)
```bash
# set-up conda env
bash setup_env.sh
source activate vmx_ppo_env

# set-up pre-commit
pre-commit install
```

## run pipelines
In root directly, run the following:
```bash
# runs all nodes in rule generation pipeline
python -m src.vmx_ppo 
--pipeline unconstrained_demand 
--brand <brand> 
--month <month(s)> 
--version <run_version>
```
```bash
# runs specific node in rule generation pipeline
python -m src.vmx_ppo 
--pipeline unconstrained_demand 
--node preprocess 
--brand <brand> 
--month <month(s)> 
--version <run_version>
```
```bash
# runs specific nodes in rule generation pipeline
python -m src.vmx_ppo 
--pipeline unconstrained_demand 
--node preprocess modeling 
--brand <brand> 
--month <month(s)> 
--version <run_version>
```
```bash
# run all nodes in rule generation pipeline in dev env (reads configs from conf/default, then conf/dev)
python -m src.vmx_ppo 
--pipeline unconstrained_demand 
--env dev 
--brand <brand> 
--month <month(s)> 
--version <run_version> 
--de_user <de user> 
```
```bash
# run all nodes in rule generation pipeline in local env (reads configs from conf/default, then conf/local)
python -m src.vmx_ppo 
--pipeline unconstrained_demand 
--env local 
--brand <brand> 
--month <month(s)> 
--version <run_version>
```
```bash
# Example run for unconstrained demand pipeline in dev env for toyota in September 2023
python -m src.vmx_ppo 
--pipeline unconstrained_demand 
--env dev 
--brand toyota 
--month 202309 
--version 2023_09_v1 
--de_user 'test_ds_pipeline_airflow_09122023'
```
```bash
# Example run for unconstrained demand pipeline in local env for lexus in August 2023,September 2023
python -m src.vmx_ppo 
--pipeline unconstrained_demand 
--env dev 
--brand lexus 
--month 202308 202309 
--version 2023_09_v1
```
```bash
# run all nodes in segmentation pipeline in dev env (reads configs from conf/default, then conf/dev)
python -m src.vmx_ppo 
--pipeline segmentation 
--env dev 
--brand <brand> 
--segments <number of segments> 
--version <run_version> 
--de_user <de user> 
```
```bash
# run all nodes in segmentation pipeline in local env (reads configs from conf/default, then conf/local)
python -m src.vmx_ppo 
--pipeline segmentation 
--env local 
--brand <brand> 
--segments <number of segments> 
--version <run_version>
```
```bash
# Example run for segmentation pipeline in dev env for toyota with 6 segments
python -m src.vmx_ppo 
--pipeline segmentation 
--env dev 
--brand toyota 
--segments 6 
--version 2023_09_v2 
--de_user 'test_cicd_2023_08_09_de_run'
```

## Docstring Specifications
- [Google Style](https://sphinxcontrib-napoleon.readthedocs.io/en/latest/example_google.html)

## Testing
```python
# run all tests in tests/ folder
pytest

# run test coverage report
pytest --cov=vmx_ppo tests/
```
