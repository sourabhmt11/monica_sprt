import pytest
import os
from src.vmx_ppo.config.config_parser import ConfigParser
import shutil


@pytest.fixture(scope="function")
def test_setup():
    # remove test folder if exists
    for data_layer_folder in os.listdir("./tests/integration/data"):
        for run_folder in os.listdir(f"./tests/integration/data/{data_layer_folder}"):
            if run_folder == "test":
                test_folder_path = os.path.join(
                    "./tests/integration/data", data_layer_folder, "test"
                )
                if os.path.exists(test_folder_path):
                    shutil.rmtree(test_folder_path)


@pytest.fixture(scope="function")
def config_setup(request):
    cfg = ConfigParser(env="test")
    run_version = "test"

    # import parameters and catalog
    parameters = cfg.parameters
    catalog = cfg.catalog
    data_catalog = catalog[request.param]
    params = parameters[request.param]

    return data_catalog, params, run_version
