import src.vmx_ppo.unconstrained_demand.preprocess as preprocess
import src.vmx_ppo.unconstrained_demand.modeling as modeling
import src.vmx_ppo.unconstrained_demand.recommendation as recommendation
import src.vmx_ppo.unconstrained_demand.reporting as reporting
from src.vmx_ppo.utils.io import load_data
import pandas as pd
import pytest


@pytest.mark.parametrize(
    "config_setup", [("unconstrained_demand")], indirect=["config_setup"]
)
def test_preprocess(test_setup, config_setup):
    # fetch test setup
    data_catalog, params, run_version = config_setup

    # run pipeline
    preprocess.run(params, data_catalog, run_version)
    modeling.run(params, data_catalog, run_version)
    recommendation.run(params, data_catalog, run_version)
    reporting.run(params, data_catalog, run_version)

    # test outputs
    load_dict = {"run_version": run_version, "mode": "lite"}
    result_df = load_data(data_catalog["impact_result_all_series"], load_dict)
    expected_result_df = load_data(
        data_catalog["expected_impact_result_all_series"], load_dict
    )

    col_sort_order = [
        "dealer_number_latest",
        "series_name",
        "model_number",
        "accessory_code",
    ]
    result_df.sort_values(by=col_sort_order, inplace=True)
    expected_result_df.sort_values(by=col_sort_order, inplace=True)

    result_df["quantity_retail_grain_historical"] = result_df[
        "quantity_retail_grain_historical"
    ].astype("int64")
    result_df["quantity_retail_ppo_historical"] = result_df[
        "quantity_retail_ppo_historical"
    ].astype("int64")
    result_df["msrp_ppo"] = result_df["msrp_ppo"].astype("int64")
    result_df["dealer_margin_ppo"] = result_df["dealer_margin_ppo"].astype("int64")
    result_df["est_alloc_qty"] = result_df["est_alloc_qty"].astype("int64")

    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )
