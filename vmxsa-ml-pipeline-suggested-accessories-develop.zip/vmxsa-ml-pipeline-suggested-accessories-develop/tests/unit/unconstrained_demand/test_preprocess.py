from src.vmx_ppo.unconstrained_demand.preprocess import (
    log_run_params,
    log_new_series,
    extract_ppo_data,
    prepare_procon_data,
    prepare_ppo_data,
    clean_ppo_data,
    extract_region_dealer_data,
    get_getsudo_data,
    log_new_grain_and_not_allocated_models,
    update_segments_with_dealer_number_changes,
    append_segments_with_new_dealer_segments,
)
import pandas as pd
import dask.dataframe as dd
import numpy as np


def test_update_segments_with_dealer_number_changes():
    segments_df = pd.DataFrame.from_dict(
        {
            "dealer_code": [111, 222, 333, 444, 555],
            "label": [0, 1, 2, 3, 4],
        }
    )
    dealer_code_changes_df = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": ["2220", "1110", "5550"],
            "dealer_number_previous": [222, 111, 555],
        }
    )

    segments_df = update_segments_with_dealer_number_changes(
        segments_df, dealer_code_changes_df
    )

    assert segments_df["dealer_code"].tolist() == [
        1110,
        2220,
        333,
        444,
        5550,
    ]
    assert segments_df["label"].tolist() == [0, 1, 2, 3, 4]


def test_append_segments_with_new_dealer_segments():
    """Test when new_dealer already is present - so actually not a new dealer"""

    segments_df = pd.DataFrame.from_dict(
        {
            "dealer_code": [111, 222, 333],
            "label": [0, 1, 2],
        }
    )
    new_dealer_segments = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": ["444", "555"],
            "dealer_number_near_label": [3, 4],
        }
    )

    (
        segments_df,
        is_error_appending_new_dealer,
    ) = append_segments_with_new_dealer_segments(segments_df, new_dealer_segments)

    assert is_error_appending_new_dealer is False
    assert segments_df["dealer_code"].tolist() == [111, 222, 333, 444, 555]
    assert segments_df["label"].tolist() == [0, 1, 2, 3, 4]


def test_append_segments_with_new_dealer_segments_already_exists():
    """Test when new_dealer already is present - so actually not a new dealer"""

    segments_df = pd.DataFrame.from_dict(
        {
            "dealer_code": [111, 222, 333],
            "label": [0, 1, 2],
        }
    )
    new_dealer_segments = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": ["111"],
            "dealer_number_near_label": [3],
        }
    )

    (
        segments_df,
        is_error_appending_new_dealer,
    ) = append_segments_with_new_dealer_segments(segments_df, new_dealer_segments)

    assert is_error_appending_new_dealer is True
    assert segments_df["dealer_code"].tolist() == [111, 222, 333]
    assert segments_df["label"].tolist() == [0, 1, 2]


def test_log_run_params():
    """Test log_run_params function."""

    run_params = {
        "test_int_param": 1,
        "test_str_param": "test string",
        "test_bool_param": True,
    }
    result_df = log_run_params(run_params)

    assert result_df.shape == (3, 2)
    assert result_df["parameter"].tolist() == [
        "test_int_param",
        "test_str_param",
        "test_bool_param",
    ]
    assert result_df["value"].tolist() == [1, "test string", True]


def test_log_new_series():
    """Test log_new_series function."""
    procon_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "B", "A", "C", "D"],
            "business_month": [202201, 202201, 202202, 202202, 202202],
        }
    )
    series_in_mi = ["A", "B", "D"]
    series_to_run = ["A", "B"]
    months_to_run = [202201, 202202]
    other_series_list = ["other_brand_series_1", "other_brand_series_2"]

    result_df, run_list = log_new_series(
        procon_df,
        series_in_mi,
        series_to_run,
        months_to_run,
        "brand",
        other_series_list,
    )
    assert result_df.shape == (3, 4)
    assert result_df["series_name"].tolist() == ["B", "C", "D"]
    assert result_df["brand"].tolist() == ["brand", "brand", "brand"]
    output_business_month = result_df["business_month"].tolist()
    assert (
        (int(output_business_month[0]) == 202202)
        & (np.isnan(output_business_month[1]))
        & (np.isnan(output_business_month[2]))
    )
    assert result_df["log_type"].tolist() == [
        "series run with no procon (no recommendations)",
        "series in procon but not in model input",
        "series in procon and model input but not run",
    ]
    assert run_list == [("A", 202201), ("A", 202202), ("B", 202201)]


def test_extract_ppo_data():
    """Test extract_ppo_data function."""
    ppo_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A"],
            "model_number": ["1", "2", "3", "4", "5", "6"],
            "availability_ppo_list": [2, 1, 0, 2, 3, 1],
            "quantity_retail_ppo_list": [1, 2, 0, 0, 0, 1],
            "quantity_wholesales_ppo_list": [1, 2, 0, 3, 4, 5],
        }
    )
    result_df = extract_ppo_data(ppo_df)
    assert result_df.shape == (5, 5)
    assert (result_df.index == [0, 1, 3, 4, 5]).all()


def test_prepare_procon_data():
    """Test prepare_procon_data function."""
    procon_data_df = dd.from_pandas(
        pd.DataFrame(
            {
                "region_code": ["100", "100", "100"],
                "series_name": ["A", "A", None],
                "model_number": ["9999", "9999", "9999"],
                "getsudo_month": ["202111", "202112", "202201"],
            }
        ),
        npartitions=1,
    )
    months_to_run = [202201, 202202]

    result_df = prepare_procon_data(procon_data_df, months_to_run)
    assert result_df.shape == (1, 5)
    assert result_df["series_name"].tolist() == ["A"]
    assert result_df["region_code"].tolist() == [100]
    assert result_df["business_month"].tolist() == [202201]
    assert result_df["model_number"].tolist() == [9999]


def test_prepare_ppo_data():
    """Test prepare_ppo_data function."""
    subset_cols_list = [
        "region_code",
        "district_code",
        "dealer_number_latest",
        "model_number",
        "expanded_ppo_list",
        "accessory_code",
        "business_month",
        "quantity_retail_model",
        "availability_model",
        "velocity_model",
        "sa_ratio_model",
        "quantity_retail_ppo_list",
        "availability_ppo_list",
        "msrp_ppo_list",
        "velocity_ppo_list",
        "sa_ratio_ppo_list",
        "quantity_retail_ppo",
        "availability_ppo",
        "msrp_ppo",
        "velocity_ppo",
        "sa_ratio_ppo",
        "geo_cd_lat",
        "geo_cd_lon",
        "zip_cd",
        "dlrshp_nm",
        "reg_nm",
        "dealer_margin",
        "grade",
    ]

    addtl_cols_list = [
        "quantity_wholesales_ppo",
        "quantity_wholesales_model",
        "quantity_wholesales_ppo_list",
    ]

    ppo_data_dict = {
        col: [1, 2, 3, 4, 5, 6] for col in subset_cols_list + addtl_cols_list
    }
    ppo_data_dict["dealer_number_latest"] = [123, 234, 345, 456, 567, 678]
    ppo_data_dict["business_month"] = [202201, 202202, 202203, 202204, 202205, 202206]
    ppo_data_dict["accessory_code"] = ["A", "A", "B", None, "C", None]

    ppo_df = pd.DataFrame.from_dict(ppo_data_dict)

    segment_df = pd.DataFrame.from_dict(
        {"dealer_code": [123, 234, 345, 456, 567], "label": [0, 1, 2, 3, 4]}
    )

    historical_result_df = prepare_ppo_data(
        ppo_df, segment_df, 202201, 202206, "series A"
    )
    # dealer with no segment is dropped
    assert historical_result_df.shape == (5, 30)
    # None is replaced with 'No_PPO'
    assert historical_result_df["accessory_code"].tolist() == [
        "A",
        "A",
        "B",
        "No_PPO",
        "C",
    ]
    # Check column names
    left_cols = historical_result_df.columns.tolist()
    right_cols = subset_cols_list + ["label", "series_name"]
    # Expect 'dealer_margin' to become 'dealer_margin_ppo'
    right_cols = list(
        map(lambda x: x.replace("dealer_margin", "dealer_margin_ppo"), right_cols)
    )
    left_cols.sort()
    right_cols.sort()
    assert left_cols == right_cols


def test_clean_ppo_data():
    """Test clean_ppo_data function."""
    ppo_df = pd.DataFrame.from_dict(
        {
            "business_month": [202201, 202202, 202203, 202204, 202205, 202206],
            "quantity_retail_ppo_list": [1, 2, 3, 4, 5, 6],
            "availability_ppo_list": [1, 2, 3, 4, 5, 6],
            "quantity_retail_ppo": [1, 2, 3, 4, 5, 6],
            "availability_ppo": [1, 2, 3, 4, 5, 6],
            "quantity_retail_model": [1, 2, 3, 4, 5, 6],
            "availability_model": [1, 2, 3, 4, 5, 6],
        }
    )

    # filter out months
    result_df_1 = clean_ppo_data(ppo_df, 202201, 202202)
    assert result_df_1.shape == (2, 7)
    assert result_df_1["business_month"].tolist() == [202201, 202202]

    # filter out negative values in each column
    for col in [
        "quantity_retail_ppo_list",
        "availability_ppo_list",
        "quantity_retail_ppo",
        "availability_ppo",
        "quantity_retail_model",
        "availability_model",
    ]:
        ppo_df_copy = ppo_df.copy()
        ppo_df_copy.loc[2, col] = -3
        ppo_df_copy = clean_ppo_data(ppo_df_copy, 202201, 202206)
        assert ppo_df_copy.shape == (5, 7)
        assert ppo_df_copy["business_month"].tolist() == [
            202201,
            202202,
            202204,
            202205,
            202206,
        ]
        assert ppo_df_copy[col].sum() == 18


def test_extract_region_dealer_data():
    """Test extract_region_dealer_data function."""
    dealer_df = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": ["123", "123", "345", "456", "567"],
            "region_code": ["100", "100", "200", "200", "200"],
            "reg_nm": ["A", "A", "B", "B", "B"],
            "district_code": [1, 1, 2, 2, 2],
            "geo_cd_lat": [1, 1, 3, 4, 5],
            "geo_cd_lon": [1, 1, 3, 4, 5],
            "zip_cd": [1, 1, 3, 4, 5],
            "dlrshp_nm": ["A", "A", "C", "D", "E"],
            "extra_col": [1, 2, 3, 4, 5],
            "lex_toy_ind": ["T", "T", "T", "T", "T"],
        }
    )

    result_df = extract_region_dealer_data(dealer_df)
    assert result_df.shape == (4, 9)
    assert result_df["dealer_number_latest"].tolist() == [123, 345, 456, 567]
    assert result_df["region_code"].tolist() == [100, 200, 200, 200]
    assert result_df["reg_nm"].tolist() == ["A", "B", "B", "B"]
    assert result_df["district_code"].tolist() == [1, 2, 2, 2]
    assert result_df["dlrshp_nm"].tolist() == ["A", "C", "D", "E"]
    assert result_df["geo_cd_lat"].tolist() == [1, 3, 4, 5]
    assert result_df["geo_cd_lon"].tolist() == [1, 3, 4, 5]
    assert result_df["zip_cd"].tolist() == [1, 3, 4, 5]
    assert result_df["lex_toy_ind"].tolist() == ["T", "T", "T", "T"]


def test_get_getsudo_data():
    """Test get_getsudo_data function."""
    target_month, series_name, aggregation_level = 202202, "series A", "series"
    procon_df = pd.DataFrame.from_dict(
        {
            "business_month": [
                202201,
                202201,
                202201,
                202202,
                202202,
                202202,
            ],
            "region_code": [100, 200, 300, 100, 200, 300],
            "series_name": [
                "series A",
                "series A",
                "series B",
                "series A",
                "series B",
                "series A",
            ],
            "model_number": ["1000", "1000", "1000", "1000", "1000", "1000"],
        }
    )
    region_dealer_df = pd.DataFrame.from_dict(
        {
            "region_code": [100, 200, 300],
            "dealer_number_latest": [1000, 2000, 3000],
            "additional_columns": [1, 2, 3],
        }
    )
    segments_df = pd.DataFrame.from_dict(
        {
            "dealer_code": [1000, 2000, 3000],
            "label": [0, 1, 2],
        }
    )
    result_df = get_getsudo_data(
        procon_df,
        target_month,
        series_name,
        region_dealer_df,
        segments_df,
        aggregation_level,
    )
    assert result_df.shape == (2, 5)
    assert result_df["region_code"].tolist() == [100, 300]
    assert result_df["business_month"].tolist() == [202202, 202202]
    assert result_df["dealer_number_latest"].tolist() == [1000, 3000]
    assert (
        result_df.columns
        == [
            "region_code",
            "business_month",
            "series_name",
            "dealer_number_latest",
            "label",
        ]
    ).all()


def test_log_new_grain_and_not_allocated_models():
    """Test log_new_grain_and_not_allocated_models function"""
    agg_level, series, target_month_min, brand = "model", "4RUNNER", 202201, "brand"
    ppo_clean_historical = pd.DataFrame.from_dict(
        {
            "series_name": ["4RUNNER", "4RUNNER", "4RUNNER"],
            "model_number": [100, 110, 120],
            "dealer_number_latest": [1000, 2000, 3000],
            "additional_columns": [1, 2, 3],
        }
    )
    getsudo_current = pd.DataFrame.from_dict(
        {
            "series_name": ["4RUNNER", "4RUNNER", "4RUNNER"],
            "business_month": [202201, 202201, 202201],
            "model_number": [100, 200, 200],
            "dealer_number_latest": [1000, 2000, 3000],
            "additional_columns": [1, 2, 3],
        }
    )
    (
        bpi_log_grain_no_rules_df_final,
        bpi_log_grain_no_history,
        run_list,
    ) = log_new_grain_and_not_allocated_models(
        ppo_clean_historical,
        getsudo_current,
        agg_level,
        target_month_min,
        series,
        brand,
    )

    assert bpi_log_grain_no_rules_df_final.shape == (4, 7)
    assert (
        bpi_log_grain_no_rules_df_final.columns
        == [
            "series_name",
            "model_number",
            "dealer_number_latest",
            "business_month",
            "category",
            "rules_created",
            "brand",
        ]
    ).all()
    assert bpi_log_grain_no_rules_df_final[
        bpi_log_grain_no_rules_df_final["category"]
        == "new model in ProCon not in history"
    ]["model_number"].to_list() == [200, 200]
    assert bpi_log_grain_no_rules_df_final[
        bpi_log_grain_no_rules_df_final["category"]
        == "new model in ProCon not in history"
    ]["dealer_number_latest"].to_list() == [2000, 3000]
    assert bpi_log_grain_no_rules_df_final[
        bpi_log_grain_no_rules_df_final["category"]
        == "model in history not allocated in ProCon"
    ]["model_number"].to_list() == [110, 120]
    assert bpi_log_grain_no_rules_df_final["category"].tolist() == [
        "new model in ProCon not in history",
        "new model in ProCon not in history",
        "model in history not allocated in ProCon",
        "model in history not allocated in ProCon",
    ]
    assert bpi_log_grain_no_history is None
    assert run_list == [("4RUNNER", 202201)]

    # test empty sales
    (
        bpi_log_grain_no_rules_df_final,
        bpi_log_grain_no_history,
        run_list,
    ) = log_new_grain_and_not_allocated_models(
        pd.DataFrame(), getsudo_current, agg_level, target_month_min, series, "brand"
    )
    assert bpi_log_grain_no_rules_df_final is None
    assert bpi_log_grain_no_history.shape == (1, 4)
    assert bpi_log_grain_no_history["series_name"].tolist() == ["4RUNNER"]
    assert bpi_log_grain_no_history["business_month"].tolist() == [202201]
    assert bpi_log_grain_no_history["log_category"].tolist() == [
        "series in procon but no history"
    ]
    assert bpi_log_grain_no_history["brand"].tolist() == ["brand"]
    assert run_list == []
