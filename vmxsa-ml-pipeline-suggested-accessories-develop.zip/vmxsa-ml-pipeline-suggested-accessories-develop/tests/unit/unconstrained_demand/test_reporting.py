from src.vmx_ppo.unconstrained_demand.reporting import (
    create_est_alloc_qty_column,
    add_historical_month_ppo_cols,
    create_impact_columns,
    add_all_dealer_ppo_combinations,
    post_processing_impact_summary,
    weighted_average,
    create_msrp_ppo_and_margin,
    calculate_impact_cols,
    concatenate_dataframes,
    aggregate_impact_results,
    log_estimated_lift,
)
import pandas as pd
import numpy as np


def test_create_est_alloc_qty_column_COROLLA():
    columns = [
        "series_name",
        "dealer_number_latest",
        "accessory_code",
        "label",
        "business_month",
        "quantity_retail_grain_historical",
        "grain",
        "rule_level",
        "region_code",
    ]
    data = [
        ["COROLLA", 1, "A0", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 1, "A1", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 1, "A2", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 1, "A3", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 2, "B1", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 2, "B2", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 2, "B3", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 3, "C1", 0, 202201, 100.0, "series", "COROLLA", 1],
        ["COROLLA", 4, "C1", 0, 202201, 20.0, "series", "COROLLA", 2],
    ]
    df = pd.DataFrame(data=data, columns=columns)

    procon_data = [
        {
            "series_name": "COROLLA",
            "model_number": 1,
            "region_code": 1,
            "quantity": 1000,
        },
        {
            "series_name": "COROLLA",
            "model_number": 1,
            "region_code": 2,
            "quantity": 2,
        },
    ]
    procon_df = pd.DataFrame(data=procon_data)

    df = create_est_alloc_qty_column(df, "series", procon_df)

    est_alloc_qty_list = list(df["est_alloc_qty"])
    expected_est_alloc_qty_list = [333, 333, 333, 333, 334, 334, 334, 333, 2]

    assert len(est_alloc_qty_list) == len(expected_est_alloc_qty_list)
    assert est_alloc_qty_list == expected_est_alloc_qty_list


def test_create_est_alloc_qty_column_TUNDRA():
    columns = [
        "series_name",
        "dealer_number_latest",
        "accessory_code",
        "label",
        "business_month",
        "quantity_retail_grain_historical",
        "grain",
        "rule_level",
        "region_code",
    ]
    data = [
        ["TUNDRA", 5, "A0", 0, 202201, 5.0, "series", "TUNDRA", 3],
        ["TUNDRA", 6, "B0", 0, 202201, 5.0, "series", "TUNDRA", 3],
        ["TUNDRA", 6, "B1", 0, 202201, 5.0, "series", "TUNDRA", 3],
        ["TUNDRA", 7, "C0", 0, 202201, 5.0, "series", "TUNDRA", 3],
        ["TUNDRA", 8, "D0", 0, 202201, 5.0, "series", "TUNDRA", 3],
        ["TUNDRA", 9, "A0", 0, 202201, 9.0, "series", "TUNDRA", 4],
        ["TUNDRA", 10, "A0", 0, 202201, 0, "series", "TUNDRA", 4],
    ]
    df = pd.DataFrame(data=data, columns=columns)

    procon_data = [
        {
            "series_name": "TUNDRA",
            "model_number": 1,
            "region_code": 3,
            "quantity": 100,
        },
        {
            "series_name": "TUNDRA",
            "model_number": 1,
            "region_code": 4,
            "quantity": 6,
        },
    ]
    procon_df = pd.DataFrame(data=procon_data)

    df = create_est_alloc_qty_column(df, "series", procon_df)
    est_alloc_qty_list = list(df["est_alloc_qty"])
    expected_est_alloc_qty_list = [25, 25, 25, 25, 25, 6, 0]

    assert len(est_alloc_qty_list) == len(expected_est_alloc_qty_list)
    assert est_alloc_qty_list == expected_est_alloc_qty_list


def test_create_est_alloc_qty_column_CAMRY():
    columns = [
        "series_name",
        "model_number",
        "dealer_number_latest",
        "accessory_code",
        "label",
        "business_month",
        "quantity_retail_grain_historical",
        "grain",
        "rule_level",
        "region_code",
    ]
    data = [
        ["CAMRY", 1, 10, "A0", 0, 202201, 2.0, "model", "CAMRY", 4],
        ["CAMRY", 1, 10, "A1", 0, 202201, 2.0, "model", "CAMRY", 4],
        ["CAMRY", 2, 11, "B0", 0, 202201, 1.0, "model", "CAMRY", 4],
        ["CAMRY", 3, 12, "A0", 0, 202201, 6.0, "model", "CAMRY", 5],
        ["CAMRY", 3, 13, "A0", 0, 202201, 4.0, "model", "CAMRY", 5],
    ]
    df = pd.DataFrame(data=data, columns=columns)

    procon_data = [
        {
            "series_name": "CAMRY",
            "model_number": 1,
            "region_code": 4,
            "quantity": 5,
        },
        {
            "series_name": "CAMRY",
            "model_number": 2,
            "region_code": 4,
            "quantity": 8,
        },
        {
            "series_name": "CAMRY",
            "model_number": 3,
            "region_code": 5,
            "quantity": 10,
        },
    ]
    procon_df = pd.DataFrame(data=procon_data)

    df = create_est_alloc_qty_column(df, "model", procon_df)
    est_alloc_qty_list = list(df["est_alloc_qty"])
    expected_est_alloc_qty_list = [5, 5, 8, 6, 4]

    assert len(est_alloc_qty_list) == len(expected_est_alloc_qty_list)
    assert est_alloc_qty_list == expected_est_alloc_qty_list


def test_create_est_alloc_qty_column_TACOMA():
    columns = [
        "series_name",
        "model_number",
        "dealer_number_latest",
        "accessory_code",
        "label",
        "business_month",
        "quantity_retail_grain_historical",
        "grain",
        "rule_level",
        "region_code",
    ]
    data = [
        ["TACOMA", 4, 14, "A0", 0, 202201, 12.0, "model", "TACOMA", 6],
        ["TACOMA", 4, 15, "A0", 0, 202201, 88.0, "model", "TACOMA", 6],
        ["TACOMA", 5, 16, "A0", 0, 202201, 0, "model", "TACOMA", 7],
        ["TACOMA", 5, 16, "A1", 0, 202201, 0, "model", "TACOMA", 7],
        ["TACOMA", 5, 17, "A0", 0, 202201, 0, "model", "TACOMA", 7],
        ["TACOMA", 6, 18, "A0", 0, 202201, 0, "model", "TACOMA", 8],
    ]
    df = pd.DataFrame(data=data, columns=columns)

    procon_data = [
        {
            "series_name": "TACOMA",
            "model_number": 4,
            "region_code": 6,
            "quantity": 3,
        },
        {
            "series_name": "TACOMA",
            "model_number": 5,
            "region_code": 7,
            "quantity": 50,
        },
        {
            "series_name": "TACOMA",
            "model_number": 6,
            "region_code": 8,
            "quantity": 10,
        },
    ]
    procon_df = pd.DataFrame(data=procon_data)

    df = create_est_alloc_qty_column(df, "model", procon_df)
    est_alloc_qty_list = list(df["est_alloc_qty"])
    expected_est_alloc_qty_list = [0, 3, 25, 25, 25, 10]

    assert len(est_alloc_qty_list) == len(expected_est_alloc_qty_list)
    assert est_alloc_qty_list == expected_est_alloc_qty_list


def test_create_est_alloc_qty_column_HIGHLANDER():
    columns = [
        "series_name",
        "dealer_number_latest",
        "accessory_code",
        "label",
        "business_month",
        "quantity_retail_grain_historical",
        "grain",
        "rule_level",
        "region_code",
    ]
    data = [
        ["HIGHLANDER", 16, "A0", 0, 202201, 100.0, "series", "HIGHLANDER", 7],
        ["HIGHLANDER", 17, "A0", 0, 202201, 0, "series", "HIGHLANDER", 8],
        ["HIGHLANDER", 18, "A0", 0, 202201, 0, "series", "HIGHLANDER", 8],
        ["HIGHLANDER", 19, "A0", 0, 202201, 0, "series", "HIGHLANDER", 8],
        ["HIGHLANDER", 19, "A1", 0, 202201, 0, "series", "HIGHLANDER", 8],
        ["HIGHLANDER", 19, "A2", 0, 202201, 0, "series", "HIGHLANDER", 8],
        ["HIGHLANDER", 20, "A0", 0, 202201, 0, "series", "HIGHLANDER", 9],
        ["HIGHLANDER", 20, "A1", 0, 202201, 0, "series", "HIGHLANDER", 9],
        ["HIGHLANDER", 21, "A2", 0, 202201, 0, "series", "HIGHLANDER", 9],
    ]
    df = pd.DataFrame(data=data, columns=columns)

    procon_data = [
        {
            "series_name": "HIGHLANDER",
            "model_number": 5,
            "region_code": 7,
            "quantity": 0,
        },
        {
            "series_name": "HIGHLANDER",
            "model_number": 6,
            "region_code": 8,
            "quantity": 100,
        },
        {
            "series_name": "HIGHLANDER",
            "model_number": 6,
            "region_code": 9,
            "quantity": 50,
        },
    ]
    procon_df = pd.DataFrame(data=procon_data)

    df = create_est_alloc_qty_column(df, "series", procon_df)
    est_alloc_qty_list = list(df["est_alloc_qty"])
    expected_est_alloc_qty_list = [0, 33, 34, 33, 33, 33, 25, 25, 25]

    assert len(est_alloc_qty_list) == len(expected_est_alloc_qty_list)
    assert est_alloc_qty_list == expected_est_alloc_qty_list


def test_add_historical_month_ppo_cols():
    base_parameters = {"cluster_col": "label"}
    aggregation_level = "model"
    df_rules_aggregated = pd.DataFrame(
        {
            base_parameters["cluster_col"]: [2, 2, 2, 2],
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "accessory_code": ["AA", "AA", "AA", "AA"],
            "no_model_history_quartile_segment": ["No", "No", "No", "No"],
            "dealer_number_latest": [1, 2, 3, 4],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "business_month": [202201, 202201, 202201, 202201],
            "no_quartile_new_grain": ["No", "No", "No", "No"],
            "quantity_retail_dealer": [2, 1, 1, 1],
            "correlation_category_agg": [
                "None/Positive",
                "None/Positive",
                "None/Positive",
                "None/Positive",
            ],
            "region_code": [800, 800, 800, 800],
            "district_code": [7, 7, 7, 7],
            "rec_retail_installation_rate": [0.2, 0.2, 0.2, 0.2],
            "quantity_retail_group": [6, 6, 6, 6],
            "rule_agg_level": [
                "district-grain",
                "district-grain",
                "district-grain",
                "district-grain",
            ],
        }
    )

    df_sale_ppo_historical = pd.DataFrame(
        {
            "series_name": ["A", "A"],
            base_parameters["cluster_col"]: [2, 2],
            "quartile": ["lowest", "lowest"],
            "model_number": [1000, 2000],
            "accessory_code": ["BB", "AA"],
            "dealer_number_latest": [1, 1],
            "correlation_category": ["None", "None"],
            "quantity_retail_ppo": [1, 1],
            "correl": [0.01, 0.05],
        }
    )

    df_sale_grain_historical = pd.DataFrame(
        {
            "series_name": ["A", "A"],
            base_parameters["cluster_col"]: [2, 2],
            "quartile": ["lowest", "lowest"],
            "model_number": [1000, 2000],
            "dealer_number_latest": [1, 1],
            "correlation_category": ["None", "None"],
            "quantity_retail_grain": [1, 1],
            "correl": [0.01, 0.05],
        }
    )

    result_df = add_historical_month_ppo_cols(
        df_rules_aggregated,
        df_sale_ppo_historical,
        df_sale_grain_historical,
        aggregation_level,
        base_parameters,
    )

    expected_result_df1 = pd.DataFrame(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            "dealer_number_latest": [1, 2, 3, 4, 1],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "accessory_code": ["AA", "AA", "AA", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest", "lowest"],
            "no_quartile_new_grain": ["No", "No", "No", "No", "No"],
            "no_model_history_quartile_segment": ["No", "No", "No", "No", "No"],
            "correlation_category": ["None", "None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01, 0.01],
            "correlation_category_agg": [
                "None/Positive",
                "None/Positive",
                "None/Positive",
                "None/Positive",
                "None/Positive",
            ],
            "quantity_retail_ppo_historical": [0.0, 0.0, 0.0, 0.0, 1.0],
            "rec_retail_installation_rate": [0.2, 0.2, 0.2, 0.2, np.nan],
            "rule_agg_level": [
                "district-grain",
                "district-grain",
                "district-grain",
                "district-grain",
                np.nan,
            ],
            "quantity_retail_group": [6, 6, 6, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "Base recommendation",
                "Base recommendation",
                "Base recommendation",
                "With history no recommendation",
            ],
            "quantity_retail_grain_historical": [1.0, 0.0, 0.0, 0.0, 1.0],
        }
    )
    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df1.reset_index(drop=True)
    )


def test_create_impact_columns():
    base_parameters = {"cluster_col": "label", "rules_len_historical_months": 3}
    aggregation_level = "model"
    target_month_min = 202203

    df_rules_result_final_wt_model_sales = pd.DataFrame(
        {
            "series_name": ["A", "A", "A"],
            "dealer_number_latest": [1, 2, 1],
            "model_number": [1000, 1000, 1000],
            "accessory_code": ["AA", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2],
            "business_month": [202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest"],
            "no_quartile_new_grain": ["No", "No", "No"],
            "no_model_history_quartile_segment": ["No", "No", "No"],
            "correlation_category": ["None", "None", "None"],
            "correl": [0.01, 0.01, 0.01],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0],
            "rec_retail_installation_rate": [0.2, 0.2, np.nan],
            "rule_agg_level": ["district-grain", "district-grain", np.nan],
            "quantity_retail_group": [6, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "Base recommendation",
                "With history no recommendation",
            ],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0],
        }
    )

    df_region_dealer_data = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [1, 2],
            "region_code": [800, 800],
            "reg_nm": ["Region 1", "Region 1"],
            "district_code": [1, 1],
            "geo_cd_lat": [36.58167, 36.48167],
            "geo_cd_lon": [-119.63667, -119.53667],
            "zip_cd": [93662, 93562],
            "dlrshp_nm": ["dealer 1", "dealer 2"],
        }
    )
    df_results_dealer = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A"],
            base_parameters["cluster_col"]: [2, 2],
            "dealer_number_latest": [1, 2],
            "model_number": [1000, 1000],
            "msrp_ppo_list_dealer": [100, 200],
            "sa_ratio_dealer_weighted": [1, 1],
            "quantity_retail_dealer": [1, 1],
            "quartile": ["lowest", "lowest"],
            "correl": [0.01, 0.01],
            "correlation_category": ["None", "None"],
        }
    )
    df_joined = pd.DataFrame.from_dict(
        {
            "model_number": [1000, 1000, 1000],
            "dealer_number_latest": [1, 2, 1],
            "accessory_code": ["AA", "AA", "BB"],
            "business_month": [202201, 202201, 202201],
            "series_name": ["A", "A", "A"],
            base_parameters["cluster_col"]: [2, 2, 2],
            "msrp_ppo": [100, 101, 200],
            "dealer_margin_ppo": [30, 31, 80],
            "quantity_retail_ppo": [1, 1, 1],
        }
    )

    ppo_historical_df = pd.DataFrame.from_dict(
        {
            "model_number": [1000, 1000, 2000],
            "dealer_number_latest": [1, 2, 1],
            "accessory_code": ["AA", "AA", "BB"],
            "accessory_description": ["PPO 1", "PPO 1", "PPO 2"],
            "business_month": [202201, 202201, 202201],
            "series_name": ["A", "A", "A"],
            base_parameters["cluster_col"]: [2, 2, 2],
            "msrp_ppo": [100, 101, 200],
            "dealer_margin_ppo": [30, 31, 80],
            "quantity_retail_ppo": [1, 1, 1],
            "spec_name": ["SR5 2WD", "SR5 2WD", "SR5 PREM 4WD"],
        }
    )
    df_segment_description = pd.DataFrame.from_dict(
        {
            base_parameters["cluster_col"]: [2],
            "description": ["Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry"],
        }
    )

    result_df = create_impact_columns(
        df_rules_result_final_wt_model_sales,
        df_region_dealer_data,
        df_results_dealer,
        df_joined,
        ppo_historical_df,
        df_segment_description,
        aggregation_level,
        target_month_min,
        base_parameters,
    )

    expected_result_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, 0.0],
            "rec_retail_installation_rate": [0.2, 0.0, 0.2, 0.0],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, 0.0],
            "grain": ["model", "model", "model", "model"],
            "rule_level": [1000, 1000, 1000, 1000],
            "description": [
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
            ],
            "msrp_ppo": [100.0, 200.0, 101.0, 200.0],
            "dealer_margin_ppo": [30.0, 80.0, 31.0, 80.0],
            "lift_in_retail_install_rate": [-0.8, -1.0, -0.8, 0.0],
            "ppo_amount_before_retail": [100 / 3, 200 / 3, 101 / 3, 0.0],
            "ppo_amount_after_retail": [100 * 0.2 / 3, 0.0, 101 * 0.2 / 3, 0.0],
            "ppo_amount_before_pervehicle_retail": [100.0, 200.0, 101.0, 0.0],
            "ppo_amount_after_pervehicle": [100.0 * 0.2, 0.0, 101.0 * 0.2, 0.0],
            "accessory_description": ["PPO 1", "PPO 2", "PPO 1", "PPO 2"],
            "spec_name": ["SR5 2WD", "SR5 2WD", "SR5 2WD", "SR5 2WD"],
            "region_code": [800, 800, 800, 800],
            "district_code": [1, 1, 1, 1],
            "geo_cd_lat": [36.58167, 36.58167, 36.48167, 36.48167],
            "geo_cd_lon": [-119.63667, -119.63667, -119.53667, -119.53667],
            "zip_cd": [93662, 93662, 93562, 93562],
            "dlrshp_nm": ["dealer 1", "dealer 1", "dealer 2", "dealer 2"],
            "reg_nm": ["Region 1", "Region 1", "Region 1", "Region 1"],
            "msrp_ppo_list_dealer": [100, 100, 200, 200],
            "sa_ratio_dealer_weighted": [1, 1, 1, 1],
            "quantity_retail_dealer": [1, 1, 1, 1],
        }
    )
    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )


def test_add_all_dealer_ppo_combinations():
    base_parameters = {"cluster_col": "label"}
    aggregation_level = "model"
    df_rules_result_final2 = pd.DataFrame(
        {
            "series_name": ["A", "A", "A"],
            "dealer_number_latest": [1, 2, 1],
            "model_number": [1000, 1000, 1000],
            "accessory_code": ["AA", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2],
            "business_month": [202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest"],
            "no_quartile_new_grain": ["No", "No", "No"],
            "no_model_history_quartile_segment": ["No", "No", "No"],
            "correlation_category": ["None", "None", "None"],
            "correl": [0.01, 0.01, 0.01],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0],
            "rec_retail_installation_rate": [0.2, 0.2, np.nan],
            "rule_agg_level": ["district-grain", "district-grain", np.nan],
            "quantity_retail_group": [6, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "Base recommendation",
                "With history no recommendation",
            ],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0],
        }
    )

    result_df = add_all_dealer_ppo_combinations(
        df_rules_result_final2, aggregation_level
    )
    expected_result_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, np.nan],
            "rec_retail_installation_rate": [0.2, np.nan, 0.2, np.nan],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, np.nan],
        }
    )
    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )


def test_post_processing_impact_summary():
    base_parameters = {"cluster_col": "label"}

    df_rules_result_final2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, np.nan],
            "rec_retail_installation_rate": [0.2, np.nan, 0.2, np.nan],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, np.nan],
        }
    )

    result_df = post_processing_impact_summary(df_rules_result_final2)

    expected_result_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, 0.0],
            "rec_retail_installation_rate": [0.2, 0.0, 0.2, 0.0],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, 0.0],
        }
    )

    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )


def test_weighted_average():
    df = pd.DataFrame.from_dict(
        {
            "model_number": [8674, 8674],
            "dealer_number_latest": [2016, 2016],
            "accessory_code": ["1M", "1M"],
            "business_month": [202208, 202206],
            "series_name": ["4RUNNER", "4RUNNER"],
            "label": [0, 0],
            "msrp_ppo": [100.0, 200.0],
            "dealer_margin_ppo": [50.0, 100.0],
            "quantity_retail_ppo": [2.0, 1.0],
        }
    )
    value_col_list = ["msrp_ppo", "dealer_margin_ppo"]
    weight_col = "quantity_retail_ppo"

    result_series = weighted_average(df, value_col_list, weight_col)
    expected_result_series = pd.Series(
        {
            "msrp_ppo": (100 * 2 + 200) / 3,
            "dealer_margin_ppo": (50 * 2 + 100) / 3,
        }
    )
    pd.testing.assert_series_equal(
        expected_result_series, result_series, check_index=False
    )


def test_create_msrp_ppo_and_margin():
    param_dict = {"cluster_col": "label", "rules_len_historical_months": 3}
    aggregation_level = "model"
    target_month_min = 202203

    df_rules_result_final2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            param_dict["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, 0.0],
            "rec_retail_installation_rate": [0.2, 0.0, 0.2, 0.0],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, 0.0],
            "grain": ["model", "model", "model", "model"],
            "rule_level": [1000, 1000, 1000, 1000],
            "description": [
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
            ],
        }
    )
    df_joined = pd.DataFrame.from_dict(
        {
            "model_number": [1000, 1000, 1000],
            "dealer_number_latest": [1, 2, 1],
            "accessory_code": ["AA", "AA", "BB"],
            "business_month": [202201, 202201, 202201],
            "series_name": ["A", "A", "A"],
            param_dict["cluster_col"]: [2, 2, 2],
            "msrp_ppo": [100, 101, 200],
            "dealer_margin_ppo": [30, 31, 80],
            "quantity_retail_ppo": [1, 1, 1],
        }
    )

    result_df = create_msrp_ppo_and_margin(
        df_rules_result_final2,
        df_joined,
        aggregation_level,
        target_month_min,
        param_dict,
    )

    expected_result_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            param_dict["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, 0.0],
            "rec_retail_installation_rate": [0.2, 0.0, 0.2, 0.0],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, 0.0],
            "grain": ["model", "model", "model", "model"],
            "rule_level": [1000, 1000, 1000, 1000],
            "description": [
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
            ],
            "msrp_ppo": [100.0, 200.0, 101.0, 200.0],
            "dealer_margin_ppo": [30.0, 80.0, 31.0, 80.0],
        }
    )

    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )


def test_calculate_impact_cols():
    param_dict = {"cluster_col": "label", "rules_len_historical_months": 3}
    df_rules_result_final2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            param_dict["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, 0.0],
            "rec_retail_installation_rate": [0.2, 0.0, 0.2, 0.0],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, 0.0],
            "grain": ["model", "model", "model", "model"],
            "rule_level": [1000, 1000, 1000, 1000],
            "description": [
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
            ],
            "msrp_ppo": [100.0, 200.0, 101.0, 200.0],
            "dealer_margin_ppo": [30.0, 80.0, 31.0, 80.0],
        }
    )

    result_df = calculate_impact_cols(
        df_rules_result_final2, param_dict["rules_len_historical_months"]
    )
    expected_result_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            param_dict["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, 0.0],
            "rec_retail_installation_rate": [0.2, 0.0, 0.2, 0.0],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, 0.0],
            "grain": ["model", "model", "model", "model"],
            "rule_level": [1000, 1000, 1000, 1000],
            "description": [
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
            ],
            "msrp_ppo": [100.0, 200.0, 101.0, 200.0],
            "dealer_margin_ppo": [30.0, 80.0, 31.0, 80.0],
            "lift_in_retail_install_rate": [-0.8, -1.0, -0.8, 0.0],
            "ppo_amount_before_retail": [100 / 3, 200 / 3, 101 / 3, 0.0],
            "ppo_amount_after_retail": [100 * 0.2 / 3, 0.0, 101 * 0.2 / 3, 0.0],
            "ppo_amount_before_pervehicle_retail": [100.0, 200.0, 101.0, 0.0],
            "ppo_amount_after_pervehicle": [100.0 * 0.2, 0.0, 101.0 * 0.2, 0.0],
        }
    )

    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )


def test_concatenate_dataframes():
    df_list = [
        pd.DataFrame.from_dict({"series_name": ["A", "B"]}),
        pd.DataFrame.from_dict({"series_name": ["C", "D"]}),
    ]
    result_df = concatenate_dataframes(df_list)
    expected_result_df = pd.DataFrame.from_dict({"series_name": ["A", "B", "C", "D"]})

    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )


def test_aggregate_impact_results():
    base_parameters = {
        "cluster_col": "label",
        "rules_len_historical_months": 3,
        "aggregation_level": "model",
    }
    concatenated_impact_data_df = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [1, 1, 2, 2],
            "accessory_code": ["AA", "BB", "AA", "BB"],
            base_parameters["cluster_col"]: [2, 2, 2, 2],
            "business_month": [202201, 202201, 202201, 202201],
            "quartile": ["lowest", "lowest", "lowest", "lowest"],
            "correlation_category": ["None", "None", "None", "None"],
            "correl": [0.01, 0.01, 0.01, 0.01],
            "quantity_retail_grain_historical": [1.0, 1.0, 1.0, 1.0],
            "no_quartile_new_grain": ["No", "No", "No", np.nan],
            "no_model_history_quartile_segment": ["No", "No", "No", np.nan],
            "quantity_retail_ppo_historical": [1.0, 1.0, 1.0, 0.0],
            "rec_retail_installation_rate": [0.2, 0.0, 0.2, 0.0],
            "rule_agg_level": ["district-grain", np.nan, "district-grain", np.nan],
            "quantity_retail_group": [6, np.nan, 6, np.nan],
            "edge_case": [
                "Base recommendation",
                "With history no recommendation",
                "Base recommendation",
                "No history no recommendation",
            ],
            "original_retail_install_rate_historical": [1.0, 1.0, 1.0, 0.0],
            "grain": ["model", "model", "model", "model"],
            "rule_level": [1000, 1000, 1000, 1000],
            "description": [
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
                "Sub-Urban - Upper-middle/High Income - 2WD - Warm & Dry",
            ],
            "msrp_ppo": [100.0, 200.0, 101.0, 200.0],
            "dealer_margin_ppo": [30.0, 80.0, 31.0, 80.0],
            "lift_in_retail_install_rate": [-0.8, -1.0, -0.8, 0.0],
            "ppo_amount_before_retail": [100 / 3, 200 / 3, 101 / 3, 0.0],
            "ppo_amount_after_retail": [100 * 0.2 / 3, 0.0, 101 * 0.2 / 3, 0.0],
            "ppo_amount_before_pervehicle_retail": [100.0, 200.0, 101.0, 0.0],
            "ppo_amount_after_pervehicle": [100.0 * 0.2, 0.0, 101.0 * 0.2, 0.0],
            "accessory_description": ["PPO 1", "PPO 2", "PPO 1", "PPO 2"],
            "spec_name": ["SR5 2WD", "SR5 2WD", "SR5 2WD", "SR5 2WD"],
            "region_code": [800, 800, 800, 800],
            "district_code": [1, 1, 1, 1],
            "geo_cd_lat": [36.58167, 36.58167, 36.48167, 36.48167],
            "geo_cd_lon": [-119.63667, -119.63667, -119.53667, -119.53667],
            "zip_cd": [93662, 93662, 93562, 93562],
            "dlrshp_nm": ["dealer 1", "dealer 1", "dealer 2", "dealer 2"],
            "reg_nm": ["Region 1", "Region 1", "Region 1", "Region 1"],
            "msrp_ppo_list_dealer": [100, 100, 200, 200],
            "sa_ratio_dealer_weighted": [1, 1, 1, 1],
            "quantity_retail_dealer": [1, 1, 1, 1],
        }
    )
    result_df = aggregate_impact_results(concatenated_impact_data_df, base_parameters)
    expected_result_df = pd.DataFrame.from_dict(
        {
            "business_month": [202201],
            "region_code": [800],
            "baseline": [100 / 3 + 200 / 3 + 101 / 3],
            "lift": [100.0 * (-0.8) / 3 + 200.0 * (-1) / 3 + 101.0 * (-0.8) / 3],
            "msrp_ppo": [(100.0 + 200.0 + 101.0 + 200.0) / 4],
            "original_retail_install_rate_historical": [3 / 4],
            "lift_in_retail_install_rate": [(-0.8 - 1 - 0.8) / 4],
            "quantity_retail_grain_historical": [0.66667],
        }
    )

    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )


def test_log_estimated_lift():
    df_result_all_series_agg = pd.DataFrame.from_dict(
        {
            "business_month": [202209, 202209, 202209, 202209],
            "region_code": [110, 120, 110, 120],
            "baseline": [50000, 30000, 20000, 10000],
            "lift": [5000, 3000, 2000, 1000],
            "series_name": ["4RUNNER", "4RUNNER", "CAMRY", "CAMRY"],
            "quantity_retail_grain_historical": [200, 100, 250, 150],
        }
    )

    result_df = log_estimated_lift(df_result_all_series_agg, "brand")
    expected_result_df = pd.DataFrame.from_dict(
        {
            "business_month": [202209, 202209],
            "series_name": ["4RUNNER", "CAMRY"],
            "baseline": [80000, 30000],
            "lift": [8000, 3000],
            "quantity_retail_grain_historical_average": [300, 400],
            "brand": ["brand", "brand"],
        }
    )
    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True), expected_result_df.reset_index(drop=True)
    )
