import numpy as np

from src.vmx_ppo.unconstrained_demand.modeling import (
    categorize_corr,
    calculate_weights,
    calculate_sa_ratio_and_msrp,
    calculate_correlation_sa_ratio_msrp_per_vehicle,
    calculate_dealer_level_sum,
    assign_quartile,
    catch_no_quartile_existing_grain,
    get_dealer_quartile,
    log_run_statistics,
    prep_data_rules,
    merge_quartile_correlation,
    sum_sale_availability_for_rules,
    get_recommended_rules_dealer_lvl,
    get_recommended_rules,
    get_historical_rules,
    merge_quartile_correlation_getsudo,
    assign_quartile_new_grain,
    find_most_common_quartile,
    apply_grade_level_recommendation_heuristic,
)
import pandas as pd
import datetime


def test_categorize_corr():
    """Test categorize_corr function."""
    param_dict = {
        "correlation": {
            "positive_corr_threshold": 0.35,
            "negative_corr_threshold": -0.35,
        }
    }
    assert categorize_corr(0.35, param_dict) == "Positive"
    assert categorize_corr(-0.35, param_dict) == "Negative"
    assert categorize_corr(0.34, param_dict) == "None"


def test_calculate_weights():
    current_date = datetime.datetime.strptime(str(202201), "%Y%m")
    end_of_business_month = datetime.datetime.strptime(str(202203), "%Y%m")
    steepness = 1
    clip = 4
    weight = calculate_weights(
        current_date,
        end_of_business_month,
        steepness,
        clip,
    )
    assert weight == (1 / (1 + np.exp(-steepness * (clip - 3))))


def test_calculate_sa_ratio_and_msrp():
    param_dict = {"cluster_col": "label"}
    # test model level
    aggregation_level = "model"
    df_joined = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"],
            "model_number": [
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                2000,
                2000,
                2000,
                2000,
                2000,
                2000,
            ],
            "business_month": [
                202201,
                202201,
                202201,
                202202,
                202202,
                202202,
                202201,
                202201,
                202201,
                202202,
                202202,
                202202,
            ],
            "dealer_number_latest": [10, 10, 10, 10, 20, 30, 10, 10, 10, 10, 20, 30],
            param_dict["cluster_col"]: [0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1],
            "expanded_ppo_list": [
                "XX, YY",
                "XX",
                "YY",
                np.nan,
                np.nan,
                np.nan,
                "XX, YY",
                "XX",
                np.nan,
                np.nan,
                np.nan,
                np.nan,
            ],
            "quantity_retail_ppo_list": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
            "availability_ppo_list": [2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 0, 1],
            "msrp_ppo_list": [
                300,
                100,
                200,
                np.nan,
                np.nan,
                np.nan,
                300,
                100,
                np.nan,
                np.nan,
                np.nan,
                np.nan,
            ],
            "quantity_retail_model": [3, 3, 3, 1, 1, 1, 3, 3, 3, 1, 1, 0],
            "availability_model": [6, 6, 6, 1, 1, 1, 3, 3, 3, 1, 0, 1],
            "sa_ratio_model": [0.5, 0.5, 0.5, 1, 1, 1, 1, 1, 1, 1, 1, 0],
        }
    )

    (
        df_dealer_final_for_quartiles,
        df_dealer_final_for_correlation,
    ) = calculate_sa_ratio_and_msrp(df_joined, aggregation_level, param_dict)

    expected_result_1 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 1, 1, 1, 1],
            "dealer_number_latest": [10, 10, 10, 10, 20, 20, 30, 30],
            "business_month": [
                202201,
                202201,
                202202,
                202202,
                202202,
                202202,
                202202,
                202202,
            ],
            "model_number": [1000, 2000, 1000, 2000, 1000, 2000, 1000, 2000],
            "quantity_retail_dealer_mth": [3.0, 3.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0],
            "availability_dealer_mth": [6.0, 3.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0],
            "sa_ratio_dealer_mth": [0.5, 1, 1, 1, 1, 1, 1, 0],
            "msrp_ppo_list_dealer_mth": [200.0, 400 / 3, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        }
    )

    pd.testing.assert_frame_equal(
        df_dealer_final_for_quartiles.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    expected_result_2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 1, 1, 1],
            "dealer_number_latest": [10, 10, 10, 10, 20, 30, 30],
            "business_month": [202201, 202201, 202202, 202202, 202202, 202202, 202202],
            "model_number": [1000, 2000, 1000, 2000, 1000, 1000, 2000],
            "quantity_retail_dealer_mth": [3.0, 3.0, 1.0, 1.0, 1.0, 1.0, 0.0],
            "availability_dealer_mth": [6.0, 3.0, 1.0, 1.0, 1.0, 1.0, 1.0],
            "sa_ratio_dealer_mth": [0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0],
            "msrp_ppo_list_dealer_mth": [200.0, 400 / 3, 0.0, 0.0, 0.0, 0.0, 0.0],
        }
    )

    pd.testing.assert_frame_equal(
        df_dealer_final_for_correlation.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )

    # test series level
    aggregation_level = "series"
    (
        df_dealer_final_for_quartiles,
        df_dealer_final_for_correlation,
    ) = calculate_sa_ratio_and_msrp(df_joined, aggregation_level, param_dict)

    expected_result_1 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 1, 1],
            "dealer_number_latest": [10, 10, 20, 30],
            "business_month": [202201, 202202, 202202, 202202],
            "quantity_retail_dealer_mth": [6.0, 2.0, 2.0, 1.0],
            "availability_dealer_mth": [9.0, 2.0, 1.0, 2.0],
            "sa_ratio_dealer_mth": [2 / 3, 1, 1, 0.5],
            "msrp_ppo_list_dealer_mth": [1000 / 6, 0.0, 0.0, 0.0],
        }
    )
    pd.testing.assert_frame_equal(
        df_dealer_final_for_quartiles.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )

    expected_result_2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 1, 1],
            "dealer_number_latest": [10, 10, 20, 30],
            "business_month": [202201, 202202, 202202, 202202],
            "quantity_retail_dealer_mth": [6.0, 2.0, 2.0, 1.0],
            "availability_dealer_mth": [9.0, 2.0, 1.0, 2.0],
            "sa_ratio_dealer_mth": [2 / 3, 1, 1, 0.5],
            "msrp_ppo_list_dealer_mth": [1600 / 9, 0.0, 0.0, 0.0],
        }
    )
    pd.testing.assert_frame_equal(
        df_dealer_final_for_correlation.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )


def test_calculate_correlation_sa_ratio_msrp_per_vehicle():
    param_dict = {
        "cluster_col": "label",
        "correlation": {
            "correlation_len_historical_months": 12,
            "steepness": 1,
            "clip": 4,
            "min_corr_data_points": 3,
            "positive_corr_threshold": 0.35,
            "negative_corr_threshold": -0.35,
        },
    }
    target_month_min = 202203
    aggregation_level = "model"
    df_dealer_final_for_correlation = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "business_month": [202201, 202202, 202201, 202202],
            "dealer_number_latest": [10, 10, 20, 20],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quantity_retail_dealer_mth": [1, 2, 3, 0],
            "availability_dealer_mth": [2, 2, 6, 1],
            "sa_ratio_dealer_mth": [1 / 2, 1, 3 / 6, 0],
            "msrp_ppo_list_dealer_mth": [100, 200, 300, 0],
        }
    )
    (
        df_dealer_final_weighted,
        iter_corr_df,
    ) = calculate_correlation_sa_ratio_msrp_per_vehicle(
        df_dealer_final_for_correlation, aggregation_level, target_month_min, param_dict
    )

    steepness = param_dict["correlation"]["steepness"]
    clip = param_dict["correlation"]["clip"]
    expected_result_1 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "business_month": [202201, 202202, 202201, 202202],
            "dealer_number_latest": [10, 10, 20, 20],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quantity_retail_dealer_mth": [1, 2, 3, 0],
            "availability_dealer_mth": [2, 2, 6, 1],
            "sa_ratio_dealer_mth": [1 / 2, 1, 3 / 6, 0],
            "msrp_ppo_list_dealer_mth": [100, 200, 300, 0],
            "date": [
                datetime.datetime.strptime(str(202201), "%Y%m"),
                datetime.datetime.strptime(str(202202), "%Y%m"),
                datetime.datetime.strptime(str(202201), "%Y%m"),
                datetime.datetime.strptime(str(202202), "%Y%m"),
            ],
            "weights": [
                (1 / (1 + np.exp(-steepness * (clip - 2)))),
                (1 / (1 + np.exp(-steepness * (clip - 1)))),
                (1 / (1 + np.exp(-steepness * (clip - 2)))),
                (1 / (1 + np.exp(-steepness * (clip - 1)))),
            ],
        }
    )

    expected_result_2 = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0.0],
            "model_number": [1000.0],
            "correl": [0.6448159],
            "correlation_category": ["Positive"],
        }
    )
    pd.testing.assert_frame_equal(
        df_dealer_final_weighted.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        iter_corr_df.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )

    # check if there is not enough data points for correlation
    param_dict = {
        "cluster_col": "label",
        "correlation": {
            "correlation_len_historical_months": 12,
            "steepness": 1,
            "clip": 4,
            "min_corr_data_points": 5,
            "positive_corr_threshold": 0.35,
            "negative_corr_threshold": -0.35,
        },
    }
    (
        df_dealer_final_weighted,
        iter_corr_df,
    ) = calculate_correlation_sa_ratio_msrp_per_vehicle(
        df_dealer_final_for_correlation, aggregation_level, target_month_min, param_dict
    )

    expected_result_2 = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0.0],
            "model_number": [1000.0],
            "correl": [0.0],
            "correlation_category": ["None"],
        }
    )

    pd.testing.assert_frame_equal(
        df_dealer_final_weighted.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        iter_corr_df.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )


def test_calculate_dealer_level_sum():
    param_dict = {"cluster_col": "label", "rules_len_historical_months": 3}
    aggregation_level = "model"
    df_dealer_final_for_quartiles = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "business_month": [202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 10, 20, 20],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quantity_retail_dealer_mth": [1, 2, 3, 0],
            "availability_dealer_mth": [2, 2, 6, 1],
            "sa_ratio_dealer_mth": [1 / 2, 1, 3 / 6, 0],
            "msrp_ppo_list_dealer_mth": [100, 200, 300, 0],
        }
    )

    # test no history
    target_month_min = 202209
    df_dealer_final_quartile = calculate_dealer_level_sum(
        df_dealer_final_for_quartiles, aggregation_level, target_month_min, param_dict
    )
    assert df_dealer_final_quartile.empty == True

    target_month_min = 202203
    df_dealer_final_quartile = calculate_dealer_level_sum(
        df_dealer_final_for_quartiles, aggregation_level, target_month_min, param_dict
    )

    expected_result = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A"],
            param_dict["cluster_col"]: [0, 0],
            "dealer_number_latest": [10, 20],
            "model_number": [1000, 1000],
            "msrp_ppo_list_dealer": [100 / 3 + 400 / 3, 300.0],
            "sa_ratio_dealer_weighted": [0.75, 3 / 7],
            "quantity_retail_dealer": [3.0, 3.0],
        }
    )
    pd.testing.assert_frame_equal(
        df_dealer_final_quartile.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_assign_quartile():
    param_dict = {
        "cluster_col": "label",
        "qs": [0, 0.25, 0.5, 0.75, 1],
        "bin_labels": ["lowest", "low", "medium", "high"],
        "display_quartile_plots": False,
    }
    aggregation_level = "model"
    df_dealer_final_quartile = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "msrp_ppo_list_dealer": [100, 200, 300, 400],
            "sa_ratio_dealer_weighted": [1, 1, 1, 1],
        }
    )

    df_quartiles_dealer_list = assign_quartile(
        df_dealer_final_quartile, aggregation_level, param_dict
    )

    expected_result = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [10, 20, 30, 40],
            "quartile": ["lowest", "low", "medium", "high"],
            "model_number": [1000, 1000, 1000, 1000],
            param_dict["cluster_col"]: [0, 0, 0, 0],
        }
    )
    pd.testing.assert_frame_equal(
        df_quartiles_dealer_list.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )

    # test when there is ties
    df_dealer_final_quartile = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "msrp_ppo_list_dealer": [100, 100, 300, 400],
            "sa_ratio_dealer_weighted": [1, 0.5, 1, 1],
        }
    )

    df_quartiles_dealer_list = assign_quartile(
        df_dealer_final_quartile, aggregation_level, param_dict
    )

    expected_result = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [20, 10, 30, 40],
            "quartile": ["lowest", "low", "medium", "high"],
            "model_number": [1000, 1000, 1000, 1000],
            param_dict["cluster_col"]: [0, 0, 0, 0],
        }
    )
    pd.testing.assert_frame_equal(
        df_quartiles_dealer_list.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_catch_no_quartile_existing_grain():
    param_dict = {"cluster_col": "label"}
    aggregation_level = "model"
    df_dealer_final_quartile = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 2000],
            "dealer_number_latest": [10, 20, 30, 40, 10],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "msrp_ppo_list_dealer": [100, 100, 300, 400, 100],
            "sa_ratio_dealer_weighted": [0.5, 1, 1, 1, 1],
        }
    )
    df_quartiles_dealer_list = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [10, 20, 30, 40],
            "quartile": ["lowest", "low", "medium", "high"],
            "model_number": [1000, 1000, 1000, 1000],
            param_dict["cluster_col"]: [0, 0, 0, 0],
        }
    )
    df_quartiles_dealer_list = catch_no_quartile_existing_grain(
        df_quartiles_dealer_list,
        df_dealer_final_quartile,
        aggregation_level,
        param_dict,
    )

    expected_result = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "model_number": [1000, 1000, 1000, 1000, 2000],
            "dealer_number_latest": [10, 20, 30, 40, 10],
            "quartile": ["lowest", "low", "medium", "high", "Grain not enough dealers"],
        }
    )
    pd.testing.assert_frame_equal(
        df_quartiles_dealer_list.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_get_dealer_quartile():
    base_parameters = {
        "cluster_col": "label",
        "correlation": {
            "correlation_len_historical_months": 12,
            "steepness": 1,
            "clip": 4,
            "min_corr_data_points": 3,
            "positive_corr_threshold": 0.35,
            "negative_corr_threshold": -0.35,
        },
        "rules_len_historical_months": 3,
        "qs": [0, 0.25, 0.5, 0.75, 1],
        "bin_labels": ["lowest", "low", "medium", "high"],
        "display_quartile_plots": False,
    }
    target_month_min = 202203
    # test model level
    aggregation_level = "model"
    df_joined = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 2000],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 20, 30, 40, 10],
            base_parameters["cluster_col"]: [0, 0, 0, 0, 0],
            "expanded_ppo_list": [np.nan, "BB", "CC", "DD", "AA"],
            "quantity_retail_ppo_list": [3, 1, 1, 1, 1],
            "availability_ppo_list": [1, 2, 3, 4, 1],
            "msrp_ppo_list": [100, 200, 300, 400, 100],
            "quantity_retail_model": [3, 1, 1, 1, 1],
            "availability_model": [3, 2, 3, 4, 1],
            "sa_ratio_model": [1, 1 / 2, 1 / 3, 1 / 4, 1],
        }
    )

    (
        iter_corr_df,
        df_dealer_final_weighted,
        df_quartiles_dealer_list,
        df_results_dealer,
    ) = get_dealer_quartile(
        df_joined, aggregation_level, target_month_min, base_parameters
    )

    steepness = base_parameters["correlation"]["steepness"]
    clip = base_parameters["correlation"]["clip"]

    expected_result_1 = pd.DataFrame.from_dict(
        {
            base_parameters["cluster_col"]: [0.0, 0.0],
            "model_number": [1000.0, 2000.0],
            "correl": [-0.9696241, 0.0],
            "correlation_category": ["Negative", "None"],
        }
    )
    expected_result_2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            base_parameters["cluster_col"]: [0, 0, 0, 0, 0],
            "dealer_number_latest": [10, 20, 30, 40, 10],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "model_number": [1000, 1000, 1000, 1000, 2000],
            "quantity_retail_dealer_mth": [3.0, 1.0, 1.0, 1.0, 1.0],
            "availability_dealer_mth": [3.0, 2.0, 3.0, 4.0, 1.0],
            "sa_ratio_dealer_mth": [1, 0.5, 1 / 3, 0.25, 1],
            "msrp_ppo_list_dealer_mth": [100 / 3, 200.0, 300.0, 400.0, 100.0],
            "date": [
                datetime.datetime.strptime(str(202201), "%Y%m"),
                datetime.datetime.strptime(str(202201), "%Y%m"),
                datetime.datetime.strptime(str(202201), "%Y%m"),
                datetime.datetime.strptime(str(202201), "%Y%m"),
                datetime.datetime.strptime(str(202201), "%Y%m"),
            ],
            "weights": [
                (1 / (1 + np.exp(-steepness * (clip - 1)))),
                (1 / (1 + np.exp(-steepness * (clip - 1)))),
                (1 / (1 + np.exp(-steepness * (clip - 1)))),
                (1 / (1 + np.exp(-steepness * (clip - 1)))),
                (1 / (1 + np.exp(-steepness * (clip - 1)))),
            ],
        }
    )
    expected_result_3 = pd.DataFrame.from_dict(
        {
            base_parameters["cluster_col"]: [0, 0, 0, 0, 0],
            "model_number": [1000, 2000, 1000, 1000, 1000],
            "dealer_number_latest": [10, 10, 20, 30, 40],
            "quartile": ["lowest", "Grain not enough dealers", "low", "medium", "high"],
        }
    )

    expected_result_4 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            base_parameters["cluster_col"]: [0, 0, 0, 0, 0],
            "dealer_number_latest": [10, 10, 20, 30, 40],
            "model_number": [1000, 2000, 1000, 1000, 1000],
            "msrp_ppo_list_dealer": [100.0, 100.0, 200.0, 300.0, 400.0],
            "sa_ratio_dealer_weighted": [1.0, 1.0, 0.5, 1 / 3, 0.25],
            "quantity_retail_dealer": [3.0, 1.0, 1.0, 1.0, 1.0],
            "quartile": ["lowest", "Grain not enough dealers", "low", "medium", "high"],
            "correl": [-0.9696241, 0.0, -0.9696241, -0.9696241, -0.9696241],
            "correlation_category": [
                "Negative",
                "None",
                "Negative",
                "Negative",
                "Negative",
            ],
        }
    )

    pd.testing.assert_frame_equal(
        iter_corr_df.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_dealer_final_weighted.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_quartiles_dealer_list.reset_index(drop=True),
        expected_result_3.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_results_dealer.reset_index(drop=True),
        expected_result_4.reset_index(drop=True),
    )


def test_log_run_statitscs():
    target_month_min = 202201
    series = "A"
    aggregation_level = "model"
    iter_corr_df = pd.DataFrame.from_dict(
        {
            "model_number": [1000, 2000],
            "label": [0, 1],
            "correl": [0.2, 0.4],
            "correlation_category": ["None", "Positive"],
        }
    )
    bpi_log_run_statistics_df = log_run_statistics(
        iter_corr_df, target_month_min, series, aggregation_level, "brand"
    )

    expected_result = pd.DataFrame.from_dict(
        {
            "correlation_category": ["None", "Positive"],
            "count_of_correlation_category_in_segment_grain": [1, 1],
            "business_month": [202201, 202201],
            "series_name": ["A", "A"],
            "grain": ["model", "model"],
            "brand": ["brand", "brand"],
        }
    )

    pd.testing.assert_frame_equal(
        bpi_log_run_statistics_df.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_prep_data_rules():
    param_dict = {"cluster_col": "label"}
    aggregation_level = "model"
    df_joined_rules = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "quantity_retail_model": [1, 1, 1, 1, 1],
            "availability_model": [1, 1, 1, 1, 1],
            "expanded_ppo_list": ["AA, BB", "AA, BB", "CC", "DD", "EE"],
            "quantity_retail_ppo_list": [1, 1, 1, 1, 1],
            "availability_ppo_list": [1, 1, 1, 1, 1],
            "accessory_code": ["AA", "BB", "CC", "DD", "EE"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "availability_ppo": [1, 1, 1, 1, 1],
        }
    )

    df_rules_ppo, df_rules_grain, df_sales_model = prep_data_rules(
        df_joined_rules, aggregation_level, param_dict
    )

    expected_result_1 = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [10, 10, 20, 30, 40],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "accessory_code": ["AA", "BB", "CC", "DD", "EE"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "availability_ppo": [1, 1, 1, 1, 1],
        }
    )
    expected_result_2 = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [10, 20, 30, 40],
            "business_month": [202201, 202201, 202201, 202201],
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "model_number": [1000, 1000, 1000, 1000],
            "quantity_retail_grain": [1, 1, 1, 1],
            "availability_model": [1, 1, 1, 1],
            "aggregation_level": ["model", "model", "model", "model"],
        }
    )

    pd.testing.assert_frame_equal(
        df_rules_ppo.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_grain.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )
    assert df_sales_model.empty == True

    df_rules_ppo, df_rules_grain, df_sales_model = prep_data_rules(
        df_joined_rules, "series", param_dict
    )

    expected_result_1 = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [10, 10, 20, 30, 40],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "accessory_code": ["AA", "BB", "CC", "DD", "EE"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "availability_ppo": [1, 1, 1, 1, 1],
        }
    )
    expected_result_2 = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [10, 20, 30, 40],
            "business_month": [202201, 202201, 202201, 202201],
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quantity_retail_grain": [1, 1, 1, 1],
            "availability_model": [1, 1, 1, 1],
            "aggregation_level": ["series", "series", "series", "series"],
        }
    )

    expected_result_3 = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [10, 20, 30, 40],
            "business_month": [202201, 202201, 202201, 202201],
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "model_number": [1000, 1000, 1000, 1000],
            "quantity_retail_grain": [1, 1, 1, 1],
        }
    )

    pd.testing.assert_frame_equal(
        df_rules_ppo.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_grain.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_sales_model.reset_index(drop=True),
        expected_result_3.reset_index(drop=True),
    )


def test_merge_quartile_correlation():
    param_dict = {"cluster_col": "label"}
    aggregation_level = "model"

    df_rules_grain = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "business_month": [202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quantity_retail_grain": [1, 1, 1, 1],
            "availability_grain": [1, 1, 1, 1],
        }
    )
    df_rules_ppo = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "accessory_code": ["AA", "BB", "CC", "DD", "EE"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "availability_ppo": [1, 1, 1, 1, 1],
        }
    )

    df_quartiles_dealer_list = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "dealer_number_latest": [10, 20, 30, 40],
            "model_number": [1000, 1000, 1000, 1000],
            "quartile": ["lowest", "low", "medium", "high"],
        }
    )

    iter_corr_df = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0],
            "model_number": [1000],
            "correl": [0.2],
            "correlation_category": ["None"],
        }
    )

    df_rules_model_quartile, df_rules_ppo_quartile = merge_quartile_correlation(
        df_rules_grain,
        df_rules_ppo,
        df_quartiles_dealer_list,
        iter_corr_df,
        aggregation_level,
        param_dict,
    )

    expected_result_1 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000],
            "business_month": [202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quantity_retail_grain": [1, 1, 1, 1],
            "availability_grain": [1, 1, 1, 1],
            "quartile": ["lowest", "low", "medium", "high"],
            "correl": [0.2, 0.2, 0.2, 0.2],
            "correlation_category": ["None", "None", "None", "None"],
        }
    )
    expected_result_2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "accessory_code": ["AA", "BB", "CC", "DD", "EE"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "availability_ppo": [1, 1, 1, 1, 1],
            "quartile": ["lowest", "lowest", "low", "medium", "high"],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": ["None", "None", "None", "None", "None"],
        }
    )

    pd.testing.assert_frame_equal(
        df_rules_model_quartile.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_ppo_quartile.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )


def test_sum_sale_availability_for_rules():
    param_dict = {"cluster_col": "label"}
    aggregation_level = "model"

    df_rules_model_quartile = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000],
            "business_month": [
                202201,
                202201,
                202201,
                202201,
                202202,
                202202,
                202202,
                202202,
            ],
            "dealer_number_latest": [10, 20, 30, 40, 10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0, 0, 0, 0],
            "quantity_retail_grain": [1, 1, 1, 1, 1, 1, 1, 1],
            "availability_grain": [1, 1, 1, 1, 1, 1, 1, 1],
            "quartile": [
                "lowest",
                "low",
                "medium",
                "high",
                "lowest",
                "low",
                "medium",
                "high",
            ],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": [
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
            ],
        }
    )
    df_rules_ppo_quartile = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A", "A", "A", "A"],
            "model_number": [
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
            ],
            "business_month": [
                202201,
                202201,
                202201,
                202201,
                202201,
                202202,
                202202,
                202202,
                202202,
                202202,
            ],
            "dealer_number_latest": [10, 10, 20, 30, 40, 10, 10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            "accessory_code": [
                "AA",
                "BB",
                "CC",
                "DD",
                "EE",
                "AA",
                "BB",
                "CC",
                "DD",
                "EE",
            ],
            "quantity_retail_ppo": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            "availability_ppo": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            "quartile": [
                "lowest",
                "lowest",
                "low",
                "medium",
                "high",
                "lowest",
                "lowest",
                "low",
                "medium",
                "high",
            ],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": [
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
            ],
        }
    )
    (
        df_sale_ppo,
        df_sale_grain,
        df_sale_model_quartile,
        df_rules_raw,
    ) = sum_sale_availability_for_rules(
        df_rules_ppo_quartile, df_rules_model_quartile, aggregation_level, param_dict
    )
    expected_result_1 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "quartile": [
                "high",
                "low",
                "lowest",
                "lowest",
                "medium",
            ],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "accessory_code": ["EE", "CC", "AA", "BB", "DD"],
            "dealer_number_latest": [40, 20, 10, 10, 30],
            "correlation_category": ["None", "None", "None", "None", "None"],
            "quantity_retail_ppo": [2, 2, 2, 2, 2],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
        }
    )
    expected_result_2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quartile": [
                "high",
                "low",
                "lowest",
                "medium",
            ],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [40, 20, 10, 30],
            "correlation_category": ["None", "None", "None", "None"],
            "quantity_retail_grain": [2, 2, 2, 2],
            "correl": [0.2, 0.2, 0.2, 0.2],
        }
    )
    expected_result_3 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quartile": [
                "high",
                "low",
                "lowest",
                "medium",
            ],
            "model_number": [1000, 1000, 1000, 1000],
            "quantity_retail_grain_quartile": [2, 2, 2, 2],
        }
    )
    expected_result_4 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "quartile": [
                "high",
                "low",
                "lowest",
                "lowest",
                "medium",
            ],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "accessory_code": ["EE", "CC", "AA", "BB", "DD"],
            "dealer_number_latest": [40, 20, 10, 10, 30],
            "correlation_category": ["None", "None", "None", "None", "None"],
            "quantity_retail_ppo": [2, 2, 2, 2, 2],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
            "quantity_retail_grain_quartile": [2, 2, 2, 2, 2],
        }
    )
    pd.testing.assert_frame_equal(
        df_sale_ppo.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_sale_grain.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_sale_model_quartile.reset_index(drop=True),
        expected_result_3.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_raw.reset_index(drop=True),
        expected_result_4.reset_index(drop=True),
    )


def test_get_recommended_rules_dealer_lvl():
    param_dict = {"cluster_col": "label"}
    aggregation_level = "model"

    df_sale_grain = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000],
            "dealer_number_latest": [10, 20, 30, 40, 50, 60, 70, 80],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0, 0, 0, 0],
            "quantity_retail_grain": [1, 1, 1, 1, 1, 1, 1, 1],
            "quartile": [
                "lowest",
                "low",
                "medium",
                "high",
                "lowest",
                "low",
                "medium",
                "high",
            ],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": [
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
            ],
        }
    )

    df_rules_raw = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A", "A", "A", "A"],
            "model_number": [
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
            ],
            "dealer_number_latest": [10, 10, 20, 30, 40, 50, 50, 60, 70, 80],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            "accessory_code": [
                "AA",
                "BB",
                "CC",
                "DD",
                "EE",
                "AA",
                "BB",
                "CC",
                "DD",
                "EE",
            ],
            "quantity_retail_ppo": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            "quartile": [
                "lowest",
                "lowest",
                "low",
                "medium",
                "high",
                "lowest",
                "lowest",
                "low",
                "medium",
                "high",
            ],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": [
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
            ],
            "quantity_retail_grain_quartile": [2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        }
    )

    df_rules_high_quartile_dealer_lvl = get_recommended_rules_dealer_lvl(
        df_rules_raw,
        df_sale_grain,
        "high",
        aggregation_level,
        param_dict,
    )
    expected_result = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A"],
            "model_number": [1000, 1000],
            "dealer_number_latest": [40, 80],
            param_dict["cluster_col"]: [0, 0],
            "accessory_code": ["EE", "EE"],
            "quartile_quantity_retail_ppo": [1, 1],
            "quartile": ["high", "high"],
            "correl": [0.2, 0.2],
            "correlation_category": ["None", "None"],
            "quantity_retail_grain_quartile": [2, 2],
            "quartile_quantity_retail_grain": [1, 1],
            "rec_retail_installation_rate": [1.0, 1.0],
        }
    )
    pd.testing.assert_frame_equal(
        df_rules_high_quartile_dealer_lvl.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_get_recommended_rules():
    param_dict = {"cluster_col": "label"}
    aggregation_level = "model"

    df_rules_raw = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A", "A", "A", "A", "A", "A"],
            "model_number": [
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
                1000,
            ],
            "dealer_number_latest": [10, 10, 20, 30, 40, 50, 50, 60, 70, 80],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            "accessory_code": [
                "AA",
                "BB",
                "CC",
                "DD",
                "EE",
                "AA",
                "BB",
                "CC",
                "DD",
                "EE",
            ],
            "quantity_retail_ppo": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            "quartile": [
                "lowest",
                "lowest",
                "low",
                "medium",
                "high",
                "lowest",
                "lowest",
                "low",
                "medium",
                "high",
            ],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": [
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
                "None",
            ],
            "quantity_retail_grain_quartile": [2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        }
    )

    df_rules_high_quartile = get_recommended_rules(
        df_rules_raw, "high", aggregation_level, param_dict
    )
    expected_result = pd.DataFrame.from_dict(
        {
            "series_name": ["A"],
            param_dict["cluster_col"]: [0],
            "accessory_code": ["EE"],
            "model_number": [1000],
            "quartile_quantity_retail_ppo": [2],
            "quartile_quantity_retail_grain": [2.0],
            "rec_retail_installation_rate": [1.0],
        }
    )
    pd.testing.assert_frame_equal(
        df_rules_high_quartile.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_get_historical_rules():
    param_dict = {"cluster_col": "label", "rules_len_historical_months": 3}
    target_month_min = 202203
    aggregation_level = "model"
    df_joined = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "dealer_number_latest": [10, 10, 20, 30, 40],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "quantity_retail_model": [1, 1, 1, 1, 1],
            "availability_model": [1, 1, 1, 1, 1],
            "expanded_ppo_list": ["AA, BB", "AA, BB", "CC", "DD", "EE"],
            "quantity_retail_ppo_list": [1, 1, 1, 1, 1],
            "availability_ppo_list": [1, 1, 1, 1, 1],
            "accessory_code": ["AA", "BB", "CC", "DD", "EE"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "availability_ppo": [1, 1, 1, 1, 1],
        }
    )

    df_quartiles_dealer_list = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "dealer_number_latest": [10, 20, 30, 40],
            "model_number": [1000, 1000, 1000, 1000],
            "quartile": ["lowest", "low", "medium", "high"],
        }
    )

    iter_corr_df = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0],
            "model_number": [1000],
            "correl": [0.2],
            "correlation_category": ["None"],
        }
    )

    (
        df_sale_ppo,
        df_sale_grain,
        df_rules_raw,
        df_sales_model,
        df_rules_high_quartile_dealer_lvl,
        df_rules_lowest_quartile_dealer_lvl,
        df_rules_no_quartile_dealer_lvl,
        df_rules_lowest_quartile,
        df_rules_low_quartile,
        df_rules_medium_quartile,
        df_rules_high_quartile,
    ) = get_historical_rules(
        df_joined,
        df_quartiles_dealer_list,
        iter_corr_df,
        aggregation_level,
        target_month_min,
        param_dict,
    )

    expected_result_1 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "quartile": ["high", "low", "lowest", "lowest", "medium"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "accessory_code": ["EE", "CC", "AA", "BB", "DD"],
            "dealer_number_latest": [40, 20, 10, 10, 30],
            "correlation_category": ["None", "None", "None", "None", "None"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
        }
    )
    expected_result_2 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "quartile": ["high", "low", "lowest", "medium"],
            "model_number": [1000, 1000, 1000, 1000],
            "dealer_number_latest": [40, 20, 10, 30],
            "correlation_category": ["None", "None", "None", "None"],
            "quantity_retail_grain": [1, 1, 1, 1],
            "correl": [0.2, 0.2, 0.2, 0.2],
        }
    )
    expected_result_3 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "quartile": ["high", "low", "lowest", "lowest", "medium"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "accessory_code": ["EE", "CC", "AA", "BB", "DD"],
            "dealer_number_latest": [40, 20, 10, 10, 30],
            "correlation_category": ["None", "None", "None", "None", "None"],
            "quantity_retail_ppo": [1, 1, 1, 1, 1],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
            "quantity_retail_grain_quartile": [1, 1, 1, 1, 1],
        }
    )
    expected_result_4 = pd.DataFrame.from_dict(
        {
            "series_name": ["A"],
            param_dict["cluster_col"]: [0],
            "quartile": ["high"],
            "model_number": [1000],
            "accessory_code": ["EE"],
            "dealer_number_latest": [40],
            "correlation_category": ["None"],
            "quartile_quantity_retail_ppo": [1],
            "correl": [0.2],
            "quantity_retail_grain_quartile": [1],
            "quartile_quantity_retail_grain": [1],
            "rec_retail_installation_rate": [1.0],
        }
    )
    expected_result_5 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A"],
            param_dict["cluster_col"]: [0, 0],
            "quartile": ["lowest", "lowest"],
            "model_number": [1000, 1000],
            "accessory_code": ["AA", "BB"],
            "dealer_number_latest": [10, 10],
            "correlation_category": ["None", "None"],
            "quartile_quantity_retail_ppo": [1, 1],
            "correl": [0.2, 0.2],
            "quantity_retail_grain_quartile": [1, 1],
            "quartile_quantity_retail_grain": [1, 1],
            "rec_retail_installation_rate": [1.0, 1.0],
        }
    )
    expected_result_6 = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A"],
            param_dict["cluster_col"]: [0, 0],
            "accessory_code": ["AA", "BB"],
            "model_number": [1000, 1000],
            "quartile_quantity_retail_ppo": [1, 1],
            "quartile_quantity_retail_grain": [1.0, 1.0],
            "rec_retail_installation_rate": [1.0, 1.0],
        }
    )
    expected_result_7 = pd.DataFrame.from_dict(
        {
            "series_name": ["A"],
            param_dict["cluster_col"]: [0],
            "accessory_code": ["CC"],
            "model_number": [1000],
            "quartile_quantity_retail_ppo": [1],
            "quartile_quantity_retail_grain": [1.0],
            "rec_retail_installation_rate": [1.0],
        }
    )
    expected_result_8 = pd.DataFrame.from_dict(
        {
            "series_name": ["A"],
            param_dict["cluster_col"]: [0],
            "accessory_code": ["DD"],
            "model_number": [1000],
            "quartile_quantity_retail_ppo": [1],
            "quartile_quantity_retail_grain": [1.0],
            "rec_retail_installation_rate": [1.0],
        }
    )
    expected_result_9 = pd.DataFrame.from_dict(
        {
            "series_name": ["A"],
            param_dict["cluster_col"]: [0],
            "accessory_code": ["EE"],
            "model_number": [1000],
            "quartile_quantity_retail_ppo": [1],
            "quartile_quantity_retail_grain": [1.0],
            "rec_retail_installation_rate": [1.0],
        }
    )

    pd.testing.assert_frame_equal(
        df_sale_ppo.reset_index(drop=True),
        expected_result_1.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_sale_grain.reset_index(drop=True),
        expected_result_2.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_raw.reset_index(drop=True),
        expected_result_3.reset_index(drop=True),
    )
    assert df_sales_model.empty == True
    pd.testing.assert_frame_equal(
        df_rules_high_quartile_dealer_lvl.reset_index(drop=True),
        expected_result_4.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_lowest_quartile_dealer_lvl.reset_index(drop=True),
        expected_result_5.reset_index(drop=True),
    )
    assert df_rules_no_quartile_dealer_lvl.empty == True
    pd.testing.assert_frame_equal(
        df_rules_lowest_quartile.reset_index(drop=True),
        expected_result_6.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_low_quartile.reset_index(drop=True),
        expected_result_7.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_medium_quartile.reset_index(drop=True),
        expected_result_8.reset_index(drop=True),
    )
    pd.testing.assert_frame_equal(
        df_rules_high_quartile.reset_index(drop=True),
        expected_result_9.reset_index(drop=True),
    )


def test_merge_quartile_correlation_getsudo():
    param_dict = {"cluster_col": "label"}
    aggregation_level = "model"
    getsudo_new_month_df = pd.DataFrame.from_dict(
        {
            "region_code": [160, 160, 160, 160, 160],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "dealer_number_latest": [10, 20, 30, 40, 50],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
        }
    )

    df_quartiles_dealer_list = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0, 0, 0, 0],
            "dealer_number_latest": [10, 20, 30, 40],
            "model_number": [1000, 1000, 1000, 1000],
            "quartile": ["lowest", "low", "medium", "high"],
        }
    )

    iter_corr_df = pd.DataFrame.from_dict(
        {
            param_dict["cluster_col"]: [0],
            "model_number": [1000],
            "correl": [0.2],
            "correlation_category": ["None"],
        }
    )

    df_results_dealer = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "dealer_number_latest": [10, 20, 30, 40, 50],
            "model_number": [1000, 1000, 1000, 1000, 2000],
            "msrp_ppo_list_dealer": [100, 200, 300, 400, 100],
            "sa_ratio_daeler_weighted": [1, 1, 1, 1, 1],
            "quantity_retail_dealer": [10, 10, 10, 10, 10],
            "quartile": ["lowest", "low", "medium", "high", "medium"],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": ["None", "None", "None", "None", "None"],
        }
    )

    dealer_grain_corr_quartile_df = merge_quartile_correlation_getsudo(
        getsudo_new_month_df,
        df_quartiles_dealer_list,
        iter_corr_df,
        df_results_dealer,
        aggregation_level,
        param_dict,
    )

    expected_result = pd.DataFrame.from_dict(
        {
            "region_code": [160, 160, 160, 160, 160],
            "business_month": [202201, 202201, 202201, 202201, 202201],
            "series_name": ["A", "A", "A", "A", "A"],
            "model_number": [1000, 1000, 1000, 1000, 1000],
            "dealer_number_latest": [10, 20, 30, 40, 50],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": ["None", "None", "None", "None", "None"],
            "quartile": ["lowest", "low", "medium", "high", "medium"],
            "no_quartile_new_grain": ["No", "No", "No", "No", "Yes"],
        }
    )
    pd.testing.assert_frame_equal(
        dealer_grain_corr_quartile_df.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_assign_quartile_new_grain():
    param_dict = {"cluster_col": "label"}
    getsudo_quartile_corr_df = pd.DataFrame.from_dict(
        {
            "region_code": [160],
            "business_month": [202201],
            "series_name": ["A"],
            "model_number": [1000],
            "dealer_number_latest": [10],
            param_dict["cluster_col"]: [0],
            "correl": [0.2],
            "correlation_category": ["None"],
            "quartile": [np.nan],
            "no_quartile_new_grain": ["Yes"],
        }
    )

    df_results_dealer = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A", "A", "A"],
            param_dict["cluster_col"]: [0, 0, 0, 0, 0],
            "dealer_number_latest": [10, 10, 10, 10, 10],
            "model_number": [2000, 3000, 4000, 5000, 6000],
            "msrp_ppo_list_dealer": [100, 200, 300, 400, 100],
            "sa_ratio_daeler_weighted": [1, 1, 1, 1, 1],
            "quantity_retail_dealer": [10, 20, 30, 40, 50],
            "quartile": ["lowest", "low", "medium", "high", "medium"],
            "correl": [0.2, 0.2, 0.2, 0.2, 0.2],
            "correlation_category": ["None", "None", "None", "None", "None"],
        }
    )

    getsudo_quartile_corr_df = assign_quartile_new_grain(
        getsudo_quartile_corr_df, df_results_dealer
    )
    expected_result = pd.DataFrame.from_dict(
        {
            "region_code": [160],
            "business_month": [202201],
            "series_name": ["A"],
            "model_number": [1000],
            "dealer_number_latest": [10],
            param_dict["cluster_col"]: [0],
            "correl": [0.2],
            "correlation_category": ["None"],
            "quartile": ["medium"],
            "no_quartile_new_grain": ["Yes"],
        }
    )
    pd.testing.assert_frame_equal(
        getsudo_quartile_corr_df.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )

    # test when dealer did not get any other model
    getsudo_quartile_corr_df = pd.DataFrame.from_dict(
        {
            "region_code": [160],
            "business_month": [202201],
            "series_name": ["A"],
            "model_number": [1000],
            "dealer_number_latest": [10],
            param_dict["cluster_col"]: [0],
            "correl": [0.2],
            "correlation_category": ["None"],
            "quartile": [np.nan],
            "no_quartile_new_grain": ["Yes"],
        }
    )
    df_results_dealer = pd.DataFrame.from_dict(
        {
            "series_name": [None],
            param_dict["cluster_col"]: [None],
            "dealer_number_latest": [None],
            "model_number": [None],
            "msrp_ppo_list_ealer": [None],
            "sa_ratio_daeler_weighted": [None],
            "quantity_retail_dealer": [None],
            "quartile": [None],
            "correl": [None],
            "correlation_category": [None],
        }
    )

    getsudo_quartile_corr_df = assign_quartile_new_grain(
        getsudo_quartile_corr_df, df_results_dealer
    )
    expected_result = pd.DataFrame.from_dict(
        {
            "region_code": [160],
            "business_month": [202201],
            "series_name": ["A"],
            "model_number": [1000],
            "dealer_number_latest": [10],
            param_dict["cluster_col"]: [0],
            "correl": [0.2],
            "correlation_category": ["None"],
            "quartile": ["low"],
            "no_quartile_new_grain": ["Yes"],
        }
    )
    pd.testing.assert_frame_equal(
        getsudo_quartile_corr_df.reset_index(drop=True),
        expected_result.reset_index(drop=True),
    )


def test_find_most_common_quartile():
    benchmark_grain = pd.DataFrame.from_dict(
        {
            "series_name": ["A", "A", "A"],
            "label": [2, 2, 2],
            "dealer_number_latest": [7012, 7012, 7012],
            "model_number": [8664, 8668, 8671],
            "msrp_ppo_list_dealer": [544, 590.25, 673],
            "sa_ratio_dealer_weighted": [1, 1, 1],
            "quantity_retail_dealer": [1, 4, 1],
            "quartile": ["low", "low", "medium"],
            "correl": [0.02, -0.003, -0.001],
            "correlation_category": ["None", "None", "None"],
        }
    )
    corr_cat = "None"
    most_common_quartile = find_most_common_quartile(benchmark_grain, corr_cat)

    assert most_common_quartile == "low"


def test_apply_grade_level_recommendation_heuristic():
    """
    This is a unit test for the apply_grade_level_recommendation_heuristic function.
    This is to test the standard output which has less columns than the special output

    There are two test cases in this test

    Input:
        - Test#1 (first 2 rows) tests two different models in the same grade that have the same accessory_code

        - Test#2 (last 3 rows) tests two different models in the same grade that have one accessory_code in common and
        one accessory_code only belongs to one model

    Expected output:
        - Test#1 to return a new rec_retail_installation_rate for the same accessory_code (2T) for two different models
        in the same grade.

        - Test#2 to return a new rec_retailed_installation_rate for 2T since both models have 2T recommendation at
        model-level.Model 9624 is expected to get rec_retailed_installation_rate for 3M alsosince it's in the same grade
        with model 9423

    """

    df_input = pd.DataFrame.from_dict(
        {
            "series_name": {
                0: "LX 600",
                1: "LX 600",
                2: "LX 600",
                3: "LX 600",
                4: "LX 600",
            },
            "label": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "accessory_code": {
                0: "2T",
                1: "2T",
                2: "2T",
                3: "2T",
                4: "3M",
            },
            "model_number": {0: 9621, 1: 9622, 2: 9623, 3: 9624, 4: 9623},
            "quartile_quantity_retail_ppo": {0: 1.0, 1: 5.0, 2: 7.0, 3: 2.0, 4: 2.0},
            "quartile_quantity_retail_grain": {
                0: 5.0,
                1: 15.0,
                2: 20.0,
                3: 3.0,
                4: 20.0,
            },
            "rec_retail_installation_rate": {
                0: 0.2,
                1: 0.3333333333333333,
                2: 0.35,
                3: 0.6666666666666666,
                4: 0.1,
            },
            "grade": {0: "GRADE1", 1: "GRADE1", 2: "GRADE2", 3: "GRADE2", 4: "GRADE2"},
        }
    )

    df_expected = pd.DataFrame.from_dict(
        {
            "series_name": {
                0: "LX 600",
                1: "LX 600",
                2: "LX 600",
                3: "LX 600",
                4: "LX 600",
                5: "LX 600",
            },
            "label": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
            "accessory_code": {0: "2T", 1: "2T", 2: "2T", 3: "3M", 4: "2T", 5: "3M"},
            "model_number": {0: 9621, 1: 9622, 2: 9623, 3: 9623, 4: 9624, 5: 9624},
            "quartile_quantity_retail_ppo": {
                0: 1.0,
                1: 5.0,
                2: 7.0,
                3: 2.0,
                4: 2.0,
                5: 0.0,
            },
            "quartile_quantity_retail_grain": {
                0: 5.0,
                1: 15.0,
                2: 20.0,
                3: 20.0,
                4: 3.0,
                5: 3.0,
            },
            "rec_retail_installation_rate": {
                0: 0.29999975,
                1: 0.29999975,
                2: 0.391304391,
                3: 0.1,
                4: 0.391304391,
                5: 0.1,
            },
            "grade": {
                0: "GRADE1",
                1: "GRADE1",
                2: "GRADE2",
                3: "GRADE2",
                4: "GRADE2",
                5: "GRADE2",
            },
        }
    )
    df_actual = apply_grade_level_recommendation_heuristic(df_input)

    pd.testing.assert_frame_equal(
        df_actual.sort_index(axis=1).reset_index(drop=True),
        df_expected.sort_index(axis=1).reset_index(drop=True),
    )


def test_apply_grade_level_recommendation_heuristic2():
    """
    This is another unit test for the apply_grade_level_recommendation_heuristic function where it has addtional
    columns such as correl, dealer_latest_number, etc

    There are two test cases within in this test

    Input:
        - Test#1 (first 2 rows): tests two different dealers that have 2 different models in the same grade and
        have the same accessory_code

        - Test#2 (last 3 rows): tests two different dealers that have two different models in the same grade and
        have one accessory_code in common and one accessory_code only belongs to one model, not the other.

    Expected output:
        - Test#1 to return a new rec_retail_installation_rate for the same accessory_code (2T)
        for two different models in the same grade for each dealer.

        - Test#2 to return a new rec_retailed_installation_rate for 2T since both models have 2T recommendation at
        model-level. Model 9624 is expected to get rec_retailed_installation_rate for 3T also since it's in the same
        grade with model 9421
    """

    df_input = pd.DataFrame.from_dict(
        {
            "series_name": {
                0: "LX 600",
                1: "LX 600",
                2: "LX 600",
                3: "LX 600",
                4: "LX 600",
            },
            "label": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "quartile": {0: "high", 1: "high", 2: "high", 3: "high", 4: "high"},
            "model_number": {0: 9621, 1: 9622, 2: 9621, 3: 9621, 4: 9624},
            "accessory_code": {0: "2T", 1: "2T", 2: "2T", 3: "3T", 4: "2T"},
            "dealer_number_latest": {0: 63106, 1: 63113, 2: 63705, 3: 63705, 4: 63106},
            "correlation_category": {
                0: "None",
                1: "None",
                2: "None",
                3: "None",
                4: "None",
            },
            "quartile_quantity_retail_ppo": {0: 1.0, 1: 1.0, 2: 1.0, 3: 1.0, 4: 4.0},
            "correl": {
                0: 0.114112,
                1: 0.114112,
                2: 0.114112,
                3: 0.114112,
                4: 0.114111,
            },
            "quantity_retail_grain_quartile": {0: 9.0, 1: 9.0, 2: 9.0, 3: 9.0, 4: 10.0},
            "quartile_quantity_retail_grain": {0: 4.0, 1: 3.0, 2: 1.0, 3: 1.0, 4: 4.0},
            "rec_retail_installation_rate": {
                0: 0.25,
                1: 0.3333333333333333,
                2: 0.9,
                3: 0.8,
                4: 0.7,
            },
            "grade": {0: "GRADE1", 1: "GRADE1", 2: "GRADE2", 3: "GRADE2", 4: "GRADE2"},
        }
    )

    df_expected = pd.DataFrame.from_dict(
        {
            "series_name": {
                0: "LX 600",
                1: "LX 600",
                2: "LX 600",
                3: "LX 600",
                4: "LX 600",
                5: "LX 600",
            },
            "label": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
            "quartile": {
                0: "high",
                1: "high",
                2: "high",
                3: "high",
                4: "high",
                5: "high",
            },
            "model_number": {0: 9621, 1: 9622, 2: 9621, 3: 9621, 4: 9624, 5: 9624},
            "accessory_code": {0: "2T", 1: "2T", 2: "2T", 3: "3T", 4: "2T", 5: "3T"},
            "dealer_number_latest": {
                0: 63106,
                1: 63113,
                2: 63705,
                3: 63705,
                4: 63106,
                5: 63106,
            },
            "correlation_category": {
                0: "None",
                1: "None",
                2: "None",
                3: "None",
                4: "None",
                5: "None",
            },
            "quartile_quantity_retail_ppo": {
                0: 1.0,
                1: 1.0,
                2: 1.0,
                3: 1.0,
                4: 4.0,
                5: 0.0,
            },
            "correl": {
                0: 0.114112,
                1: 0.114112,
                2: 0.114112,
                3: 0.114112,
                4: 0.114111,
                5: 0.114111,
            },
            "quantity_retail_grain_quartile": {
                0: 9.0,
                1: 9.0,
                2: 9.0,
                3: 9.0,
                4: 10.0,
                5: 10.0,
            },
            "quartile_quantity_retail_grain": {
                0: 4.0,
                1: 3.0,
                2: 1.0,
                3: 1.0,
                4: 4.0,
                5: 4.0,
            },
            "rec_retail_installation_rate": {
                0: 0.285714143,
                1: 0.285714143,
                2: 0.74,
                3: 0.8,
                4: 0.74,
                5: 0.8,
            },
            "grade": {
                0: "GRADE1",
                1: "GRADE1",
                2: "GRADE2",
                3: "GRADE2",
                4: "GRADE2",
                5: "GRADE2",
            },
        }
    )

    df_actual = apply_grade_level_recommendation_heuristic(df_input)

    pd.testing.assert_frame_equal(
        df_actual.sort_index(axis=1).reset_index(drop=True),
        df_expected.sort_index(axis=1).reset_index(drop=True),
    )


def test_apply_grade_level_recommendation_heuristic3():
    """
    This is another unit test for the apply_grade_level_recommendation_heuristic function where multiple labels(segments)
    exist in the input.

    There are two test cases within in this test

    Input:
        - Test#1 (first 3 rows): tests 3 different dealers that have 2 different models in the same grade and
        combination of accessory recommendation. These three records are in 3 different label (segment)

        - Test#2 (last 2 rows): tests two different dealers that have two different models in the same grade
        have different accessory in the same segment.
         This is to also test zero recommendation_rate case as well as division by zero case

    Expected output:
        - Test#1 to return a new rec_retail_installation_rate for each dealer and model_number in different
          label (segment) even though they have the same grade

        - Test#2 to return a rec_retail_installation_rate of zero and introduce it across other models in the
          same grade. The values for quartile_quantity_retail_ppo should be zero for newly introduced accessory_code.
          This column gets used in an edge case in the recommendation section where the quartile above has no sales
          of its model/series. Null values are imputed by 0's and this is consistent with how the recommendation section
          handles nulls

    """
    df_input = pd.DataFrame.from_dict(
        {
            "series_name": {
                0: "LX 600",
                1: "LX 600",
                2: "LX 600",
                3: "LX 600",
                4: "LX 600",
            },
            "label": {0: 0, 1: 1, 2: 2, 3: 3, 4: 3},
            "quartile": {0: "high", 1: "high", 2: "high", 3: "high", 4: "high"},
            "model_number": {0: 9621, 1: 9621, 2: 9623, 3: 9621, 4: 9622},
            "accessory_code": {0: "2T", 1: "3T", 2: "2T", 3: "2T", 4: "3T"},
            "dealer_number_latest": {0: 63705, 1: 60505, 2: 63106, 3: 63805, 4: 60805},
            "correlation_category": {
                0: "None",
                1: "None",
                2: "None",
                3: "None",
                4: "None",
            },
            "quartile_quantity_retail_ppo": {0: 1.0, 1: 1.0, 2: 4.0, 3: 1.0, 4: 1.0},
            "correl": {0: 0.114112, 1: 0.114112, 2: 0.114112, 3: 0.114112, 4: 0.114112},
            "quantity_retail_grain_quartile": {0: 9.0, 1: 9.0, 2: 9.0, 3: 9.0, 4: 0.0},
            "quartile_quantity_retail_grain": {0: 1.0, 1: 1.0, 2: 4.0, 3: 1.0, 4: 0.0},
            "rec_retail_installation_rate": {0: 0.6, 1: 0.7, 2: 0.8, 3: 0.0, 4: 0.8},
            "grade": {0: "GRADE1", 1: "GRADE1", 2: "GRADE1", 3: "GRADE2", 4: "GRADE2"},
        }
    )

    df_expected = pd.DataFrame.from_dict(
        {
            "series_name": {
                0: "LX 600",
                1: "LX 600",
                2: "LX 600",
                3: "LX 600",
                4: "LX 600",
                5: "LX 600",
                6: "LX 600",
            },
            "label": {0: 0, 1: 1, 2: 2, 3: 3, 4: 3, 5: 3, 6: 3},
            "quartile": {
                0: "high",
                1: "high",
                2: "high",
                3: "high",
                4: "high",
                5: "high",
                6: "high",
            },
            "model_number": {
                0: 9621,
                1: 9621,
                2: 9623,
                3: 9621,
                4: 9621,
                5: 9622,
                6: 9622,
            },
            "accessory_code": {
                0: "2T",
                1: "3T",
                2: "2T",
                3: "2T",
                4: "3T",
                5: "2T",
                6: "3T",
            },
            "dealer_number_latest": {
                0: 63705,
                1: 60505,
                2: 63106,
                3: 63805,
                4: 63805,
                5: 60805,
                6: 60805,
            },
            "correlation_category": {
                0: "None",
                1: "None",
                2: "None",
                3: "None",
                4: "None",
                5: "None",
                6: "None",
            },
            "quartile_quantity_retail_ppo": {
                0: 1.0,
                1: 1.0,
                2: 4.0,
                3: 1.0,
                4: 0.0,
                5: 0.0,
                6: 1.0,
            },
            "correl": {
                0: 0.114112,
                1: 0.114112,
                2: 0.114112,
                3: 0.114112,
                4: 0.114112,
                5: 0.114112,
                6: 0.114112,
            },
            "quantity_retail_grain_quartile": {
                0: 9.0,
                1: 9.0,
                2: 9.0,
                3: 9.0,
                4: 9.0,
                5: 0.0,
                6: 0.0,
            },
            "quartile_quantity_retail_grain": {
                0: 1.0,
                1: 1.0,
                2: 4.0,
                3: 1.0,
                4: 1.0,
                5: 0.0,
                6: 0.0,
            },
            "rec_retail_installation_rate": {
                0: 0.6,
                1: 0.7,
                2: 0.8,
                3: 0.0,
                4: 0.0,
                5: 0.0,
                6: 0.0,
            },
            "grade": {
                0: "GRADE1",
                1: "GRADE1",
                2: "GRADE1",
                3: "GRADE2",
                4: "GRADE2",
                5: "GRADE2",
                6: "GRADE2",
            },
        }
    )

    df_actual = apply_grade_level_recommendation_heuristic(df_input)

    pd.testing.assert_frame_equal(
        df_actual.sort_index(axis=1).reset_index(drop=True),
        df_expected.sort_index(axis=1).reset_index(drop=True),
    )


def test_apply_grade_level_recommendation_heuristic4():
    """
    This is an additional unit test for the apply_grade_level_recommendation_heuristic function
    where there are multiple labels (segments) and grades in the input

    Input:
        - Test#1 (first 2 rows): tests two different dealers who are in the same label(segment) and
          have the same models but different accessory codes.
          If a dealer has never had a recommendation for certain model_numberfor a specific accessory,
          they will be introduced the recommendation from other dealer in the same segment.


        - Test#2 (third row): to test case where a single grade in the same segment with other another grade.

        - Test#3 (row 4&5) : To test two different model_number from different dealers in the same grade

    Expected output:
        - Test#1 to return a new rec_retail_installation_rate for each dealer and model_number in different
          label (segment) even though they have the same grade

        - Test#2 to return original rec_retail_installation_rate to itself because it's a standalone grade in
          the label (segment)

        - Test#3 to return new rec_retail_installation_rate to each dealer, model_number
    """
    df_input = pd.DataFrame.from_dict(
        {
            "series_name": {
                0: "TACOMA",
                1: "TACOMA",
                2: "TACOMA",
                3: "TACOMA",
                4: "TACOMA",
            },
            "label": {0: 1, 1: 1, 2: 2, 3: 2, 4: 2},
            "quartile": {0: "high", 1: "high", 2: "high", 3: "high", 4: "high"},
            "model_number": {0: 9621, 1: 9621, 2: 9623, 3: 9621, 4: 9622},
            "accessory_code": {0: "2T", 1: "3T", 2: "2T", 3: "59", 4: "CF"},
            "dealer_number_latest": {0: 63705, 1: 60505, 2: 63106, 3: 63805, 4: 60805},
            "correlation_category": {
                0: "None",
                1: "None",
                2: "None",
                3: "None",
                4: "None",
            },
            "quartile_quantity_retail_ppo": {0: 1.0, 1: 1.0, 2: 4.0, 3: 1.0, 4: 2.0},
            "correl": {0: 0.114112, 1: 0.114112, 2: 0.114112, 3: 0.114112, 4: 0.11526},
            "quantity_retail_grain_quartile": {0: 9.0, 1: 9.0, 2: 9.0, 3: 9.0, 4: 7.0},
            "quartile_quantity_retail_grain": {0: 1.0, 1: 1.0, 2: 4.0, 3: 1.0, 4: 2.0},
            "rec_retail_installation_rate": {0: 0.6, 1: 0.5, 2: 0.8, 3: 0.0, 4: 0.8},
            "grade": {0: "SR", 1: "SR", 2: "SR", 3: "SR5", 4: "SR5"},
        }
    )

    df_expected = pd.DataFrame.from_dict(
        {
            "label": {0: 1, 1: 1, 2: 1, 3: 1, 4: 2, 5: 2, 6: 2, 7: 2, 8: 2},
            "series_name": {
                0: "TACOMA",
                1: "TACOMA",
                2: "TACOMA",
                3: "TACOMA",
                4: "TACOMA",
                5: "TACOMA",
                6: "TACOMA",
                7: "TACOMA",
                8: "TACOMA",
            },
            "grade": {
                0: "SR",
                1: "SR",
                2: "SR",
                3: "SR",
                4: "SR",
                5: "SR5",
                6: "SR5",
                7: "SR5",
                8: "SR5",
            },
            "model_number": {
                0: 9621,
                1: 9621,
                2: 9621,
                3: 9621,
                4: 9623,
                5: 9621,
                6: 9621,
                7: 9622,
                8: 9622,
            },
            "dealer_number_latest": {
                0: 63705,
                1: 63705,
                2: 60505,
                3: 60505,
                4: 63106,
                5: 63805,
                6: 63805,
                7: 60805,
                8: 60805,
            },
            "accessory_code": {
                0: "2T",
                1: "3T",
                2: "2T",
                3: "3T",
                4: "2T",
                5: "59",
                6: "CF",
                7: "59",
                8: "CF",
            },
            "rec_retail_installation_rate": {
                0: 0.6,
                1: 0.5,
                2: 0.6,
                3: 0.5,
                4: 0.8,
                5: 0.0,
                6: 0.8,
                7: 0.0,
                8: 0.8,
            },
            "correl": {
                0: 0.114112,
                1: 0.114112,
                2: 0.114112,
                3: 0.114112,
                4: 0.114112,
                5: 0.114112,
                6: 0.114112,
                7: 0.11526,
                8: 0.11526,
            },
            "correlation_category": {
                0: "None",
                1: "None",
                2: "None",
                3: "None",
                4: "None",
                5: "None",
                6: "None",
                7: "None",
                8: "None",
            },
            "quantity_retail_grain_quartile": {
                0: 9.0,
                1: 9.0,
                2: 9.0,
                3: 9.0,
                4: 9.0,
                5: 9.0,
                6: 9.0,
                7: 7.0,
                8: 7.0,
            },
            "quartile": {
                0: "high",
                1: "high",
                2: "high",
                3: "high",
                4: "high",
                5: "high",
                6: "high",
                7: "high",
                8: "high",
            },
            "quartile_quantity_retail_grain": {
                0: 1.0,
                1: 1.0,
                2: 1.0,
                3: 1.0,
                4: 4.0,
                5: 1.0,
                6: 1.0,
                7: 2.0,
                8: 2.0,
            },
            "quartile_quantity_retail_ppo": {
                0: 1.0,
                1: 0.0,
                2: 0.0,
                3: 1.0,
                4: 4.0,
                5: 1.0,
                6: 0.0,
                7: 0.0,
                8: 2.0,
            },
        }
    )

    df_actual = apply_grade_level_recommendation_heuristic(df_input)

    pd.testing.assert_frame_equal(
        df_actual.sort_index(axis=1).reset_index(drop=True),
        df_expected.sort_index(axis=1).reset_index(drop=True),
    )
