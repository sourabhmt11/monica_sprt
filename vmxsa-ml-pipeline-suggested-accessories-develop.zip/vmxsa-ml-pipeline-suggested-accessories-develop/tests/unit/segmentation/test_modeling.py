import numpy as np

from src.vmx_ppo.segmentation.modeling import train_segmentation_model

import pandas as pd


def test_train_segmentation_model():
    base_parameters = {"n_clusters": 6, "random_state": 42}
    segmentation_model_input_df = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [1, 2, 3, 4, 5, 6],
            "AGE_young_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "AGE_middle_aged_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "AGE_seniors_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "INCOME_rich_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "INCOME_upper_middle_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "INCOME_lower_middle_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "LOC_urban_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "LOC_sub_urban_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "ppo_select_pct": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_tavg_ab_32": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_tavg_bl_0": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_snow_day": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_rain_day": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "drivetrain_4WD_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "lease_pct": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "apr_pct": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
        }
    )
    result_df, segmentation_model = train_segmentation_model(
        segmentation_model_input_df, base_parameters
    )

    expected_result_df = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [1, 2, 3, 4, 5, 6],
            "AGE_young_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "AGE_middle_aged_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "AGE_seniors_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "INCOME_rich_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "INCOME_upper_middle_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "INCOME_lower_middle_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "LOC_urban_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "LOC_sub_urban_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "ppo_select_pct": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_tavg_ab_32": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_tavg_bl_0": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_snow_day": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "weather_rain_day": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "drivetrain_4WD_perc": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "lease_pct": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "apr_pct": [-1.0, -0.6, -0.4, 0, 0.5, 1.0],
            "label": [2, 5, 4, 0, 3, 1],
        }
    )
    expected_result_df["label"] = expected_result_df["label"].astype(np.int32)

    # TODO: Solution for the fact that different seeds on different OS produce different values
    # pd.testing.assert_frame_equal(
    #     result_df.reset_index(drop=True),
    #     expected_result_df.reset_index(drop=True),
    # )
