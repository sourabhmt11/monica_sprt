from src.vmx_ppo.segmentation.preprocess import preprocess_segmentation_data
import pandas as pd
from dask.dataframe import from_pandas


def test_preprocess_segmentation_data():
    segmentation_raw_df = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [1, 2],
            "AGE_young_perc": [0.3, 0.5],
            "AGE_middle_aged_perc": [0.3, 0.5],
            "AGE_seniors_perc": [0.3, 0.5],
            "INCOME_rich_perc": [0.3, 0.5],
            "INCOME_upper_middle_perc": [0.3, 0.5],
            "INCOME_lower_middle_perc": [0.3, 0.5],
            "LOC_urban_perc": [0.3, 0.5],
            "LOC_sub_urban_perc": [0.3, 0.5],
            "weather_tavg_ab_32": [0.3, 0.5],
            "weather_tavg_bl_0": [0.3, 0.5],
            "weather_snow_day": [0.3, 0.5],
            "weather_rain_day": [0.3, 0.5],
            "drivetrain_4WD_perc": [0.3, 0.5],
            "lease_pct": [0.3, 0.5],
            "apr_pct": [0.3, 0.5],
            "none_pct": [0.3, 0.5],
            "other_column": [2, 3],
        }
    )
    segmentation_raw_df = from_pandas(segmentation_raw_df, npartitions=3)
    result_df = preprocess_segmentation_data(segmentation_raw_df, "toyota")
    expected_result_df = pd.DataFrame.from_dict(
        {
            "dealer_number_latest": [1, 2],
            "AGE_young_perc": [-1.0, 1.0],
            "AGE_middle_aged_perc": [-1.0, 1.0],
            "AGE_seniors_perc": [-1.0, 1.0],
            "INCOME_rich_perc": [-1.0, 1.0],
            "INCOME_upper_middle_perc": [-1.0, 1.0],
            "INCOME_lower_middle_perc": [-1.0, 1.0],
            "LOC_urban_perc": [-1.0, 1.0],
            "LOC_sub_urban_perc": [-1.0, 1.0],
            "weather_tavg_ab_32": [-1.0, 1.0],
            "weather_tavg_bl_0": [-1.0, 1.0],
            "weather_snow_day": [-1.0, 1.0],
            "weather_rain_day": [-1.0, 1.0],
            "drivetrain_4WD_perc": [-1.0, 1.0],
            "lease_pct": [-1.0, 1.0],
            "apr_pct": [-1.0, 1.0],
            "none_pct": [-1.0, 1.0],
        }
    )
    pd.testing.assert_frame_equal(
        result_df.reset_index(drop=True),
        expected_result_df.reset_index(drop=True),
    )
